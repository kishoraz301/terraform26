﻿# Phase 08: Application Gateways (WAF_v2) â€” LLD v1.2 aligned
# WE: SI-DMZ-WE-APPGW-01 | NE: SI-CIDMZ-NE-APPGW-51
#
# DEPLOYMENT NOTES:
# 1. Rewritten from AVM module to direct azurerm_application_gateway resources
#    (AVM module requires azure/azapi + azure/modtm providers unavailable here).
# 2. AppGW names differ from existing state â€” destroy+recreate on first apply (~20-30 min each).
#    Confirm with architect before applying â€” causes downtime.
# 3. Key Vaults (SI-Core-Vault-WE-01 / SI-Core-Vault-NE-51) are created by this phase.
#    Apply in two stages: (a) apply KV+PE+identities first, (b) upload certs, (c) full apply.
# 4. AppGW RGs (si-dmz-appgw-we-01-rg / si-dmz-appgw-ne-01-rg) are created by this phase.
# 5. NE private frontend IP: pending NE IP plan â€” currently dynamic from subnet.
#    Set var.ne_appgw_private_frontend_ip once confirmed (WE = 10.200.11.170).
# 6. Per-listener WAF policies (WAF-LMS, WAF-HSBCPAPI) auto-assigned by hostname regex in locals.

terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.primary_subscription_id
  features {}
}

provider "azurerm" {
  alias           = "secondary"
  subscription_id = var.secondary_subscription_id
  features {}
}

# ============================================================================
# LOCALS â€” Listener and routing rule lists built from per-domain variables
# ============================================================================

locals {
  # SSL cert maps come from certs.tfvars (apply -var-file=certs.tfvars once certs are in KV).
  we_ssl_certs = var.we_cert_map
  ne_ssl_certs = var.ne_cert_map

  # Combined HTTP (redirect) + HTTPS listener objects for WE
  we_all_listeners = concat(
    # HTTPS listeners â€” only for domains whose cert is present in we_cert_map
    [for l in var.we_https_listeners : {
      key       = "https-${l.hostname}"
      name      = "https-${replace(l.hostname, ".", "-")}"
      port_name = "port-443"
      protocol  = "Https"
      hostname  = l.hostname
      ssl_cert  = l.cert_name
      sni       = true
      waf_id = (
        can(regex("^sendvaluer", lower(l.hostname))) ? azurerm_web_application_firewall_policy.we_lms_policy.id :
        can(regex("^ecot|^devecot", lower(l.hostname))) ? azurerm_web_application_firewall_policy.we_hsbcpapi_policy.id :
        null
      )
    } if contains(keys(var.we_cert_map), l.cert_name)],
    # HTTP redirect listeners â€” only for domains that have an HTTPS listener
    [for l in var.we_https_listeners : {
      key       = "http-${l.hostname}"
      name      = "http-${replace(l.hostname, ".", "-")}"
      port_name = "port-80"
      protocol  = "Http"
      hostname  = l.hostname
      ssl_cert  = null
      sni       = false
      waf_id    = null
    } if contains(keys(var.we_cert_map), l.cert_name)]
  )

  # Combined routing rules for WE: HTTPS â†’ NGINX backend + HTTP â†’ 301 redirect
  we_routing_rules = concat(
    [for l in var.we_https_listeners : {
      key              = "https-${l.hostname}"
      name             = "rule-https-${replace(l.hostname, ".", "-")}"
      listener_name    = "https-${replace(l.hostname, ".", "-")}"
      backend_pool     = "SI-DMZ-WE-NGINX-BP-01"
      backend_settings = "SI-DMZ-WE-HTTPS-Settings"
      redirect         = null
      priority         = l.priority
    } if contains(keys(var.we_cert_map), l.cert_name)],
    [for l in var.we_https_listeners : {
      key              = "redirect-${l.hostname}"
      name             = "rule-http-redirect-${replace(l.hostname, ".", "-")}"
      listener_name    = "http-${replace(l.hostname, ".", "-")}"
      backend_pool     = null
      backend_settings = null
      redirect         = "redirect-${replace(l.hostname, ".", "-")}"
      priority         = l.priority + 200
    } if contains(keys(var.we_cert_map), l.cert_name)]
  )

  # Mirror for NE
  ne_all_listeners = concat(
    # HTTPS listeners â€” only for domains whose cert is present in ne_cert_map
    [for l in var.ne_https_listeners : {
      key       = "https-${l.hostname}"
      name      = "https-${replace(l.hostname, ".", "-")}"
      port_name = "port-443"
      protocol  = "Https"
      hostname  = l.hostname
      ssl_cert  = l.cert_name
      sni       = true
      waf_id = (
        can(regex("^sendvaluer", lower(l.hostname))) ? azurerm_web_application_firewall_policy.ne_lms_policy.id :
        can(regex("^ecot|^devecot", lower(l.hostname))) ? azurerm_web_application_firewall_policy.ne_hsbcpapi_policy.id :
        null
      )
    } if contains(keys(var.ne_cert_map), l.cert_name)],
    # HTTP redirect listeners â€” only for domains that have an HTTPS listener
    [for l in var.ne_https_listeners : {
      key       = "http-${l.hostname}"
      name      = "http-${replace(l.hostname, ".", "-")}"
      port_name = "port-80"
      protocol  = "Http"
      hostname  = l.hostname
      ssl_cert  = null
      sni       = false
      waf_id    = null
    } if contains(keys(var.ne_cert_map), l.cert_name)]
  )

  ne_routing_rules = concat(
    [for l in var.ne_https_listeners : {
      key              = "https-${l.hostname}"
      name             = "rule-https-${replace(l.hostname, ".", "-")}"
      listener_name    = "https-${replace(l.hostname, ".", "-")}"
      backend_pool     = "SI-DMZ-NE-NGINX-BP-51"
      backend_settings = "SI-DMZ-NE-HTTPS-Settings"
      redirect         = null
      priority         = l.priority
    } if contains(keys(var.ne_cert_map), l.cert_name)],
    [for l in var.ne_https_listeners : {
      key              = "redirect-${l.hostname}"
      name             = "rule-http-redirect-${replace(l.hostname, ".", "-")}"
      listener_name    = "http-${replace(l.hostname, ".", "-")}"
      backend_pool     = null
      backend_settings = null
      redirect         = "redirect-${replace(l.hostname, ".", "-")}"
      priority         = l.priority + 200
    } if contains(keys(var.ne_cert_map), l.cert_name)]
  )
}

# ============================================================================
# DATA SOURCES
# ============================================================================

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

data "azurerm_subnet" "we_cidmz_appgw_snet" {
  name                 = "MIP-SI-WE-ciDMZ-AppGW-snet"
  virtual_network_name = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name  = data.azurerm_resource_group.we.name
}

data "azurerm_subnet" "ne_cidmz_appgw_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-AppGW-snet"
  virtual_network_name = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name  = data.azurerm_resource_group.ne.name
}

data "azurerm_public_ip" "we_appgw_pip" {
  name                = "MIP-SI-WE-AppGW-frontend-pip"
  resource_group_name = data.azurerm_resource_group.we.name
}

data "azurerm_public_ip" "ne_appgw_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-AppGW-frontend-pip"
  resource_group_name = data.azurerm_resource_group.ne.name
}

data "azurerm_virtual_network" "we_cidmz" {
  name                = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.we.name
}

data "azurerm_virtual_network" "ne_cidmz" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.ne.name
}

data "azurerm_subscription" "primary_sub" {}

# ============================================================================
# DEDICATED AppGW RESOURCE GROUPS â€” LLD section 4.3.9
# ============================================================================

data "azurerm_resource_group" "we_appgw_rg" {
  name = "si-dmz-appgw-we-01-rg"
}

data "azurerm_resource_group" "ne_appgw_rg" {
  provider = azurerm.secondary
  name     = "si-dmz-appgw-ne-01-rg"
}

# ============================================================================
# WAF POLICIES â€” Gateway-level (OWASP CRS 3.2) + Listener-level (WAF-LMS / WAF-HSBCPAPI)
# ============================================================================

resource "azurerm_web_application_firewall_policy" "we_waf_policy" {
  name                = "SI-DMZ-WAFPLCY-01"
  resource_group_name = data.azurerm_resource_group.we_appgw_rg.name
  location            = data.azurerm_resource_group.we_appgw_rg.location

  policy_settings {
    enabled                     = true
    mode                        = "Prevention"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  # CVE-2025-55182 custom WAF rules (LLD 4.3.9)
  custom_rules {
    name      = "cve202555182"
    priority  = 1
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2"
    priority  = 2
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182nextaction"
    priority  = 4
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2rsaction"
    priority  = 5
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "Rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182bodymultipart"
    priority  = 6
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "content-type"
      }
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
    }
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }
  }

  tags = var.tags
}

resource "azurerm_web_application_firewall_policy" "ne_waf_policy" {
  provider            = azurerm.secondary
  name                = "SI-DMZ-WAFPLCY-51"
  resource_group_name = data.azurerm_resource_group.ne_appgw_rg.name
  location            = data.azurerm_resource_group.ne_appgw_rg.location

  policy_settings {
    enabled                     = true
    mode                        = "Detection"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  # CVE-2025-55182 custom WAF rules (LLD 4.3.9)
  custom_rules {
    name      = "cve202555182"
    priority  = 1
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2"
    priority  = 2
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182nextaction"
    priority  = 4
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2rsaction"
    priority  = 5
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "Rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182bodymultipart"
    priority  = 6
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "content-type"
      }
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
    }
  }

  # Rate limit rule (LLD 4.3.9) — 64724 req / 5 min per client IP
  custom_rules {
    name                 = "RateLimitPerClientIP"
    priority             = 10
    rule_type            = "RateLimitRule"
    action               = "Block"
    rate_limit_duration  = "FiveMins"
    rate_limit_threshold = 64724
    group_rate_limit_by  = "ClientAddr"

    match_conditions {
      match_variables {
        variable_name = "RemoteAddr"
      }
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }
  }

  tags = var.tags
}

# WAF-LMS â€” sendvaluerupdate.* FQDNs
resource "azurerm_web_application_firewall_policy" "we_lms_policy" {
  name                = "WAF-LMS"
  resource_group_name = data.azurerm_resource_group.we_appgw_rg.name
  location            = data.azurerm_resource_group.we_appgw_rg.location

  policy_settings {
    enabled                     = true
    mode                        = "Prevention"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  # CVE-2025-55182 custom WAF rules (LLD 4.3.9)
  custom_rules {
    name      = "cve202555182"
    priority  = 1
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2"
    priority  = 2
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182nextaction"
    priority  = 4
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2rsaction"
    priority  = 5
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "Rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182bodymultipart"
    priority  = 6
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "content-type"
      }
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
    }
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }
  }

  tags = var.tags
}

# WAF-HSBCPAPI â€” ecot* / devecot* FQDNs
resource "azurerm_web_application_firewall_policy" "we_hsbcpapi_policy" {
  name                = "WAF-HSBCPAPI"
  resource_group_name = data.azurerm_resource_group.we_appgw_rg.name
  location            = data.azurerm_resource_group.we_appgw_rg.location

  policy_settings {
    enabled                     = true
    mode                        = "Prevention"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  # CVE-2025-55182 custom WAF rules (LLD 4.3.9)
  custom_rules {
    name      = "cve202555182"
    priority  = 1
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2"
    priority  = 2
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182nextaction"
    priority  = 4
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2rsaction"
    priority  = 5
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "Rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182bodymultipart"
    priority  = 6
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "content-type"
      }
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
    }
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }
  }

  tags = var.tags
}

resource "azurerm_web_application_firewall_policy" "ne_lms_policy" {
  provider            = azurerm.secondary
  name                = "WAF-LMS"
  resource_group_name = data.azurerm_resource_group.ne_appgw_rg.name
  location            = data.azurerm_resource_group.ne_appgw_rg.location

  policy_settings {
    enabled                     = true
    mode                        = "Detection"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  # CVE-2025-55182 custom WAF rules (LLD 4.3.9)
  custom_rules {
    name      = "cve202555182"
    priority  = 1
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2"
    priority  = 2
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182nextaction"
    priority  = 4
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2rsaction"
    priority  = 5
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "Rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182bodymultipart"
    priority  = 6
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "content-type"
      }
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
    }
  }

  # Rate limit rule (LLD 4.3.9) — 64724 req / 5 min per client IP
  custom_rules {
    name                 = "RateLimitPerClientIP"
    priority             = 10
    rule_type            = "RateLimitRule"
    action               = "Block"
    rate_limit_duration  = "FiveMins"
    rate_limit_threshold = 64724
    group_rate_limit_by  = "ClientAddr"

    match_conditions {
      match_variables {
        variable_name = "RemoteAddr"
      }
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }
  }

  tags = var.tags
}

resource "azurerm_web_application_firewall_policy" "ne_hsbcpapi_policy" {
  provider            = azurerm.secondary
  name                = "WAF-HSBCPAPI"
  resource_group_name = data.azurerm_resource_group.ne_appgw_rg.name
  location            = data.azurerm_resource_group.ne_appgw_rg.location

  policy_settings {
    enabled                     = true
    mode                        = "Detection"
    request_body_check          = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb = 128
  }

  # CVE-2025-55182 custom WAF rules (LLD 4.3.9)
  custom_rules {
    name      = "cve202555182"
    priority  = 1
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2"
    priority  = 2
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode"]
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182nextaction"
    priority  = 4
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "next-action"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182ver2rsaction"
    priority  = 5
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "Rsc-action-id"
      }
      operator           = "Any"
      negation_condition = false
    }
  }

  custom_rules {
    name      = "cve202555182bodymultipart"
    priority  = 6
    rule_type = "MatchRule"
    action    = "Log"

    match_conditions {
      match_variables {
        variable_name = "PostArgs"
      }
      operator           = "Contains"
      negation_condition = false
      transforms         = ["Lowercase", "UrlDecode", "RemoveNulls"]
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
    }

    match_conditions {
      match_variables {
        variable_name = "RequestHeaders"
        selector      = "content-type"
      }
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
    }
  }

  # Rate limit rule (LLD 4.3.9) — 64724 req / 5 min per client IP
  custom_rules {
    name                 = "RateLimitPerClientIP"
    priority             = 10
    rule_type            = "RateLimitRule"
    action               = "Block"
    rate_limit_duration  = "FiveMins"
    rate_limit_threshold = 64724
    group_rate_limit_by  = "ClientAddr"

    match_conditions {
      match_variables {
        variable_name = "RemoteAddr"
      }
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }
  }

  tags = var.tags
}

# ============================================================================
# MANAGED IDENTITIES â€” AppGW Key Vault certificate access
# Role assignments (Key Vault Secrets User) are created as Terraform resources below.
# ============================================================================

data "azurerm_user_assigned_identity" "we_appgw_identity" {
  name                = "SI-DMZ-WE-APPGW-01-mi"
  resource_group_name = data.azurerm_resource_group.we_appgw_rg.name
}

data "azurerm_user_assigned_identity" "ne_appgw_identity" {
  provider            = azurerm.secondary
  name                = "SI-CIDMZ-NE-APPGW-51-mi"
  resource_group_name = data.azurerm_resource_group.ne_appgw_rg.name
}

# ============================================================================
# WEST EUROPE â€” Application Gateway (SI-DMZ-WE-APPGW-01)
# LLD: WAF_v2, Prevention, zonal (zone 1), autoscale 2-4, private IP 10.200.11.170
# Backend: SI-DMZ-WE-NGINX-BP-01 â†’ 10.200.11.25 / 10.200.11.26 (HTTPS/443)
# ============================================================================

resource "azurerm_application_gateway" "we_appgw" {
  name                = "SI-DMZ-WE-APPGW-01"
  resource_group_name = data.azurerm_resource_group.we_appgw_rg.name
  location            = data.azurerm_resource_group.we_appgw_rg.location
  zones               = ["1"]
  firewall_policy_id  = azurerm_web_application_firewall_policy.we_waf_policy.id

  identity {
    type         = "UserAssigned"
    identity_ids = [data.azurerm_user_assigned_identity.we_appgw_identity.id]
  }

  sku {
    name = "WAF_v2"
    tier = "WAF_v2"
  }

  autoscale_configuration {
    min_capacity = 2
    max_capacity = 4
  }

  gateway_ip_configuration {
    name      = "SI-DMZ-WE-APPGW-01-ipconfig"
    subnet_id = data.azurerm_subnet.we_cidmz_appgw_snet.id
  }

  # Public frontend â€” receives traffic exclusively from Azure Front Door
  frontend_ip_configuration {
    name                 = "SI-DMZ-WE-APPGW-01-public-frontend"
    public_ip_address_id = data.azurerm_public_ip.we_appgw_pip.id
  }

  # Private frontend â€” LLD: 10.200.11.170 static (MIP-SI-WE-AppGW-snet /27)
  frontend_ip_configuration {
    name                          = "SI-DMZ-WE-APPGW-01-private-frontend"
    subnet_id                     = data.azurerm_subnet.we_cidmz_appgw_snet.id
    private_ip_address            = "10.200.11.170"
    private_ip_address_allocation = "Static"
  }

  frontend_port {
    name = "port-443"
    port = 443
  }

  frontend_port {
    name = "port-80"
    port = 80
  }

  backend_address_pool {
    name         = "SI-DMZ-WE-NGINX-BP-01"
    ip_addresses = ["10.200.11.25", "10.200.11.26"]
  }

  # HTTPS backend: AppGW â†’ NGINX on port 443.
  # No host_name override â€” AppGW forwards the original listener Host header to NGINX (SNI routing).
  backend_http_settings {
    name                                = "SI-DMZ-WE-HTTPS-Settings"
    cookie_based_affinity               = "Disabled"
    port                                = 443
    protocol                            = "Https"
    request_timeout                     = 60
    pick_host_name_from_backend_address = false
    probe_name                          = "SI-DMZ-WE-HTTPS-Probe"
  }

  # Health probe: HTTPS/443 to a known FQDN (NGINX has all 9 app certs installed).
  probe {
    name                                      = "SI-DMZ-WE-HTTPS-Probe"
    protocol                                  = "Https"
    host                                      = "notifyadvresultready.intermediaries.hsbc.co.uk"
    path                                      = "/health"
    interval                                  = 30
    timeout                                   = 30
    unhealthy_threshold                       = 3
    port                                      = 443
    pick_host_name_from_backend_http_settings = false
    match {
      status_code = ["200-399"]
    }
  }

  # SSL certificates: one block per unique cert from Key Vault.
  # Requires identity with Key Vault Secrets User role on SI-Core-Vault-WE-01.
  # TODO: populate var.we_https_listeners in terraform.tfvars (~8-10 domains).
  dynamic "ssl_certificate" {
    for_each = local.we_ssl_certs
    content {
      name                = ssl_certificate.key
      key_vault_secret_id = ssl_certificate.value
    }
  }

  # HTTPS listeners (one per domain, SNI-based multi-site) +
  # HTTP listeners (one per domain, solely for 301 redirect enforcement)
  dynamic "http_listener" {
    for_each = { for l in local.we_all_listeners : l.key => l }
    content {
      name                           = http_listener.value.name
      frontend_ip_configuration_name = "SI-DMZ-WE-APPGW-01-public-frontend"
      frontend_port_name             = http_listener.value.port_name
      protocol                       = http_listener.value.protocol
      host_name                      = http_listener.value.hostname
      ssl_certificate_name           = http_listener.value.ssl_cert
      require_sni                    = http_listener.value.sni
      firewall_policy_id             = http_listener.value.waf_id
    }
  }

  # 301 permanent redirect: HTTP listener â†’ matching HTTPS listener per domain
  dynamic "redirect_configuration" {
    for_each = { for l in var.we_https_listeners : l.hostname => l if contains(keys(var.we_cert_map), l.cert_name) }
    content {
      name                 = "redirect-${replace(redirect_configuration.key, ".", "-")}"
      redirect_type        = "Permanent"
      target_listener_name = "https-${replace(redirect_configuration.key, ".", "-")}"
      include_path         = true
      include_query_string = true
    }
  }

  # Routing rules: HTTPS â†’ SI-DMZ-WE-NGINX-BP-01 + HTTP â†’ redirect (combined)
  dynamic "request_routing_rule" {
    for_each = { for r in local.we_routing_rules : r.key => r }
    content {
      name                        = request_routing_rule.value.name
      rule_type                   = "Basic"
      http_listener_name          = request_routing_rule.value.listener_name
      backend_address_pool_name   = request_routing_rule.value.backend_pool
      backend_http_settings_name  = request_routing_rule.value.backend_settings
      redirect_configuration_name = request_routing_rule.value.redirect
      priority                    = request_routing_rule.value.priority
    }
  }

  # TLS 1.2+ with strong ciphers (AppGwSslPolicy20220101S = TLS_1_2 min, ECDHE preferred)
  ssl_policy {
    policy_type = "Predefined"
    policy_name = "AppGwSslPolicy20220101S"
  }

  tags = var.tags
}

# ============================================================================
# NORTH EUROPE â€” Application Gateway (SI-CIDMZ-NE-APPGW-51)
# LLD: WAF_v2, Detection (Day-1), zonal (zone 1), autoscale 2-4
# Backend: SI-DMZ-NE-NGINX-BP-51 â†’ 10.200.12.25 / 10.200.12.26 (HTTPS/443)
# ============================================================================

resource "azurerm_application_gateway" "ne_appgw" {
  provider            = azurerm.secondary
  name                = "SI-CIDMZ-NE-APPGW-51"
  resource_group_name = data.azurerm_resource_group.ne_appgw_rg.name
  location            = data.azurerm_resource_group.ne_appgw_rg.location
  zones               = ["1"]
  firewall_policy_id  = azurerm_web_application_firewall_policy.ne_waf_policy.id

  identity {
    type         = "UserAssigned"
    identity_ids = [data.azurerm_user_assigned_identity.ne_appgw_identity.id]
  }

  sku {
    name = "WAF_v2"
    tier = "WAF_v2"
  }

  autoscale_configuration {
    min_capacity = 2
    max_capacity = 4
  }

  gateway_ip_configuration {
    name      = "SI-CIDMZ-NE-APPGW-51-ipconfig"
    subnet_id = data.azurerm_subnet.ne_cidmz_appgw_snet.id
  }

  # Public frontend â€” receives traffic from Azure Front Door
  frontend_ip_configuration {
    name                 = "SI-CIDMZ-NE-APPGW-51-public-frontend"
    public_ip_address_id = data.azurerm_public_ip.ne_appgw_pip.id
  }

  # Private frontend â€” NE IP pending architect confirmation (var.ne_appgw_private_frontend_ip)
  dynamic "frontend_ip_configuration" {
    for_each = var.ne_appgw_private_frontend_ip != null ? [1] : []
    content {
      name                          = "SI-CIDMZ-NE-APPGW-51-private-frontend"
      subnet_id                     = data.azurerm_subnet.ne_cidmz_appgw_snet.id
      private_ip_address            = var.ne_appgw_private_frontend_ip
      private_ip_address_allocation = "Static"
    }
  }

  frontend_port {
    name = "port-443"
    port = 443
  }

  frontend_port {
    name = "port-80"
    port = 80
  }

  backend_address_pool {
    name         = "SI-DMZ-NE-NGINX-BP-51"
    ip_addresses = ["10.200.12.25", "10.200.12.26"]
  }

  # HTTPS backend: AppGW â†’ NGINX on port 443.
  # No host_name override â€” AppGW forwards the original listener Host header to NGINX (SNI routing).
  backend_http_settings {
    name                                = "SI-DMZ-NE-HTTPS-Settings"
    cookie_based_affinity               = "Disabled"
    port                                = 443
    protocol                            = "Https"
    request_timeout                     = 60
    pick_host_name_from_backend_address = false
    probe_name                          = "SI-DMZ-NE-HTTPS-Probe"
  }

  probe {
    name                                      = "SI-DMZ-NE-HTTPS-Probe"
    protocol                                  = "Https"
    host                                      = "notifyadvresultready.intermediaries.hsbc.co.uk"
    path                                      = "/health"
    interval                                  = 30
    timeout                                   = 30
    unhealthy_threshold                       = 3
    port                                      = 443
    pick_host_name_from_backend_http_settings = false
    match {
      status_code = ["200-399"]
    }
  }

  # SSL certificates from Key Vault SI-Core-Vault-NE-51
  dynamic "ssl_certificate" {
    for_each = local.ne_ssl_certs
    content {
      name                = ssl_certificate.key
      key_vault_secret_id = ssl_certificate.value
    }
  }

  dynamic "http_listener" {
    for_each = { for l in local.ne_all_listeners : l.key => l }
    content {
      name                           = http_listener.value.name
      frontend_ip_configuration_name = "SI-CIDMZ-NE-APPGW-51-public-frontend"
      frontend_port_name             = http_listener.value.port_name
      protocol                       = http_listener.value.protocol
      host_name                      = http_listener.value.hostname
      ssl_certificate_name           = http_listener.value.ssl_cert
      require_sni                    = http_listener.value.sni
      firewall_policy_id             = http_listener.value.waf_id
    }
  }

  dynamic "redirect_configuration" {
    for_each = { for l in var.ne_https_listeners : l.hostname => l if contains(keys(var.ne_cert_map), l.cert_name) }
    content {
      name                 = "redirect-${replace(redirect_configuration.key, ".", "-")}"
      redirect_type        = "Permanent"
      target_listener_name = "https-${replace(redirect_configuration.key, ".", "-")}"
      include_path         = true
      include_query_string = true
    }
  }

  dynamic "request_routing_rule" {
    for_each = { for r in local.ne_routing_rules : r.key => r }
    content {
      name                        = request_routing_rule.value.name
      rule_type                   = "Basic"
      http_listener_name          = request_routing_rule.value.listener_name
      backend_address_pool_name   = request_routing_rule.value.backend_pool
      backend_http_settings_name  = request_routing_rule.value.backend_settings
      redirect_configuration_name = request_routing_rule.value.redirect
      priority                    = request_routing_rule.value.priority
    }
  }

  ssl_policy {
    policy_type = "Predefined"
    policy_name = "AppGwSslPolicy20220101S"
  }

  tags = var.tags
}

# ============================================================================
# KEY VAULTS â€” SI-Core-Vault-WE-01 / SI-Core-Vault-NE-51
# Private-only (PE in AppGW subnet). RBAC model. Soft-delete + purge-protection.
# Certs must be uploaded to each vault before AppGW listeners can serve HTTPS.
# Staged apply: (a) KV+PE+identities, (b) upload certs, (c) full apply.
# ============================================================================

data "azurerm_key_vault" "we_kv" {
  name                = "SI-Core-Vault-WE-01"
  resource_group_name = "SI-Core-WE-01-rg"
}

data "azurerm_key_vault" "ne_kv" {
  provider            = azurerm.secondary
  name                = "SI-Core-Vault-NE-51"
  resource_group_name = "SI-Core-NE-51-rg"
}

# ============================================================================
# PRIVATE DNS ZONE â€” privatelink.vaultcore.azure.net
# ============================================================================

data "azurerm_private_dns_zone" "kv_dns" {
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = data.azurerm_resource_group.we.name
}

resource "azurerm_private_dns_zone_virtual_network_link" "we_kv_dns_link" {
  name                  = "we-cidmz-kv-dns-link"
  resource_group_name   = data.azurerm_resource_group.we.name
  private_dns_zone_name = data.azurerm_private_dns_zone.kv_dns.name
  virtual_network_id    = data.azurerm_virtual_network.we_cidmz.id
  registration_enabled  = false
  tags                  = var.tags
}

resource "azurerm_private_dns_zone_virtual_network_link" "ne_kv_dns_link" {
  name                  = "ne-cidmz-kv-dns-link"
  resource_group_name   = data.azurerm_resource_group.we.name
  private_dns_zone_name = data.azurerm_private_dns_zone.kv_dns.name
  virtual_network_id    = data.azurerm_virtual_network.ne_cidmz.id
  registration_enabled  = false
  tags                  = var.tags
}

# ============================================================================
# PRIVATE ENDPOINTS â€” Key Vault (AppGW subnet â†’ KV)
# ============================================================================

resource "azurerm_private_endpoint" "we_kv_pe" {
  name                = "SI-Core-Vault-WE-01-pe"
  resource_group_name = data.azurerm_resource_group.we_appgw_rg.name
  location            = data.azurerm_resource_group.we_appgw_rg.location
  subnet_id           = data.azurerm_subnet.we_cidmz_appgw_snet.id

  private_service_connection {
    name                           = "SI-Core-Vault-WE-01-psc"
    private_connection_resource_id = data.azurerm_key_vault.we_kv.id
    subresource_names              = ["vault"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "kv-dns-group"
    private_dns_zone_ids = [data.azurerm_private_dns_zone.kv_dns.id]
  }

  tags = var.tags
}

resource "azurerm_private_endpoint" "ne_kv_pe" {
  provider            = azurerm.secondary
  name                = "SI-Core-Vault-NE-51-pe"
  resource_group_name = data.azurerm_resource_group.ne_appgw_rg.name
  location            = data.azurerm_resource_group.ne_appgw_rg.location
  subnet_id           = data.azurerm_subnet.ne_cidmz_appgw_snet.id

  private_service_connection {
    name                           = "SI-Core-Vault-NE-51-psc"
    private_connection_resource_id = data.azurerm_key_vault.ne_kv.id
    subresource_names              = ["vault"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "kv-dns-group"
    private_dns_zone_ids = [data.azurerm_private_dns_zone.kv_dns.id]
  }

  tags = var.tags
}

# ============================================================================
# KEY VAULT ACCESS POLICIES — Get + List (Secret + Certificate) for AppGW MIs
# KVs use Access Policies model (not RBAC).
# AppGW managed identities need Get+List on Secrets and Certificates to
# retrieve KV-referenced SSL certificates at provisioning and renewal time.
# Access policies granted manually in portal; these blocks keep state in sync.
# ============================================================================

resource "azurerm_key_vault_access_policy" "we_appgw_kv" {
  key_vault_id = data.azurerm_key_vault.we_kv.id
  tenant_id    = data.azurerm_subscription.primary_sub.tenant_id
  object_id    = data.azurerm_user_assigned_identity.we_appgw_identity.principal_id

  secret_permissions      = ["Get", "List"]
  certificate_permissions = ["Get", "List"]
}

resource "azurerm_key_vault_access_policy" "ne_appgw_kv" {
  key_vault_id = data.azurerm_key_vault.ne_kv.id
  tenant_id    = data.azurerm_subscription.primary_sub.tenant_id
  object_id    = data.azurerm_user_assigned_identity.ne_appgw_identity.principal_id

  secret_permissions      = ["Get", "List"]
  certificate_permissions = ["Get", "List"]
}

