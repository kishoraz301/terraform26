# Phase 11: Azure Front Door (SI-WEB-AFD-01) — LLD v1.2 aligned
# Profile: SI-WEB-AFD-01 | Premium SKU | Global ingress
# 2 Endpoints (WE active, NE standby) | 1 Origin Group | 3 WAF Policies | 10 Custom Domains
# Deploy after Phase 08: Application Gateways

terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.primary_subscription_id
  features {}
}

provider "azurerm" {
  alias           = "secondary"
  subscription_id = var.secondary_subscription_id
  features {}
}

# ============================================================================
# DATA SOURCES
# ============================================================================

# AFD profile lives in si-cedmz-we-01-rg per LLD 4.3.8
data "azurerm_resource_group" "afd_rg" {
  name = var.afd_resource_group_name
}

# AppGW PIPs are in the AppGW resource groups (created by phase-08)
data "azurerm_public_ip" "we_appgw_pip" {
  name                = "MIP-SI-WE-AppGW-frontend-pip"
  resource_group_name = var.we_appgw_resource_group_name
}

data "azurerm_public_ip" "ne_appgw_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-AppGW-frontend-pip"
  resource_group_name = var.ne_appgw_resource_group_name
}

data "azurerm_log_analytics_workspace" "loga_we" {
  name                = "LogA-WE"
  resource_group_name = "la-we-rg"
}

# ============================================================================
# AZURE FRONT DOOR PROFILE — LLD 4.3.8: SI-WEB-AFD-01, Premium
# ============================================================================

resource "azurerm_cdn_frontdoor_profile" "global_frontdoor" {
  name                = "SI-WEB-AFD-01"
  resource_group_name = data.azurerm_resource_group.afd_rg.name
  sku_name            = var.frontdoor_sku
  tags                = var.tags
}

# ============================================================================
# ENDPOINTS — LLD: WE (active) + NE (cold standby)
# ============================================================================

resource "azurerm_cdn_frontdoor_endpoint" "we_endpoint" {
  name                     = "SI-WEB-AFD-WE-EP-01"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  tags                     = var.tags
}

resource "azurerm_cdn_frontdoor_endpoint" "ne_endpoint" {
  name                     = "SI-WEB-AFD-NE-EP-01"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  tags                     = var.tags
}

# NOTE: Private Link AFD → AppGW was removed from LLD (amendment 15 May 2026).
# Origins connect via public IP of the AppGW frontend PIP.

# ============================================================================
# ORIGIN GROUP — LLD: SI-WEB-OG-01 | WE priority=1 active, NE priority=2 standby
# ============================================================================

resource "azurerm_cdn_frontdoor_origin_group" "app_origins" {
  name                     = "SI-WEB-OG-01"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  session_affinity_enabled = false

  load_balancing {
    sample_size                        = 4
    successful_samples_required        = 3
    additional_latency_in_milliseconds = 50
  }

  health_probe {
    interval_in_seconds = 30
    path                = "/healthz"
    protocol            = "Https"
    request_type        = "GET"
  }
}

resource "azurerm_cdn_frontdoor_origin" "we_origin" {
  name                           = "SI-DMZ-WE-APPGW-01"
  cdn_frontdoor_origin_group_id  = azurerm_cdn_frontdoor_origin_group.app_origins.id
  enabled                        = true
  host_name                      = data.azurerm_public_ip.we_appgw_pip.ip_address
  http_port                      = 80
  https_port                     = 443
  priority                       = 1
  weight                         = 500
  certificate_name_check_enabled = true
}

resource "azurerm_cdn_frontdoor_origin" "ne_origin" {
  name                           = "SI-DMZ-NE-APPGW-51"
  cdn_frontdoor_origin_group_id  = azurerm_cdn_frontdoor_origin_group.app_origins.id
  enabled                        = true
  host_name                      = data.azurerm_public_ip.ne_appgw_pip.ip_address
  http_port                      = 80
  https_port                     = 443
  priority                       = 2
  weight                         = 500
  certificate_name_check_enabled = true
}

# ============================================================================
# WAF POLICIES — LLD 4.3.8
# All policies: Microsoft_DefaultRuleSet 2.1 (OWASP CRS equivalent) + BotManager
#               OWASP rule overrides per LLD + CVE-2025-55182 custom rules
# Priority scheme: 1=AllowDAST, 2=AllowSource, 5=CVE1, 6=CVE2, 10=RateLimit
# Mode: var.waf_mode (Detection for Day-1, Prevention for steady state)
# ============================================================================

# ---- WAF-ADV — NotifyAdvResultReady FQDNs ----
# NOTE: WAF-ADV is not explicitly named in LLD 4.3.8 (which only lists WAF-LMS + WAF-HSBC-PAPI)
# but NotifyAdvResultReady FQDNs are in the custom domain list — confirm with architect.
resource "azurerm_cdn_frontdoor_firewall_policy" "waf_adv" {
  name                = "WAFADV"
  resource_group_name = data.azurerm_resource_group.afd_rg.name
  sku_name            = var.frontdoor_sku
  enabled             = true
  mode                = var.waf_mode

  custom_rule {
    name     = "AllowHSBCCyberDAST"
    enabled  = true
    priority = 1
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["52.18.33.124/32", "52.210.241.58/32"]
    }
  }

  custom_rule {
    name     = "AllowADVSource"
    enabled  = true
    priority = 2
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values = [
        "91.214.4.0/24", "91.214.5.0/26", "91.214.5.64/28", "91.214.5.80/30",
        "91.214.5.84/31", "91.214.5.88/29", "91.214.5.96/27", "91.214.5.128/25",
        "91.214.6.0/23", "193.108.72.0/22", "193.108.76.0/26", "193.108.76.64/28",
        "193.108.76.80/30", "193.108.76.84/31", "193.108.76.88/29", "193.108.76.96/27",
        "193.108.76.128/25", "193.108.77.0/24", "193.108.78.0/23", "161.113.224.0/19"
      ]
    }
  }

  custom_rule {
    name                           = "cve202555182"
    enabled                        = true
    priority                       = 5
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2"
    enabled                        = true
    priority                       = 6
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "BlockLargePostBody"
    enabled                        = true
    priority                       = 8
    type                           = "MatchRule"
    action                         = "Block"
    match_condition {
      match_variable     = "RequestMethod"
      operator           = "Equal"
      negation_condition = false
      match_values       = ["POST"]
    }
    match_condition {
      match_variable     = "PostArgs"
      selector           = "Content-Length"
      operator           = "GreaterThan"
      negation_condition = false
      match_values       = ["131072"]
    }
  }

  custom_rule {
    name                           = "RateLimit"
    enabled                        = true
    priority                       = 10
    type                           = "RateLimitRule"
    action                         = "Block"
    rate_limit_duration_in_minutes = 5
    rate_limit_threshold           = 64724
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rule {
    type    = "Microsoft_DefaultRuleSet"
    version = "2.1"
    action  = "Block"
    override {
      rule_group_name = "PROTOCOL-ENFORCEMENT"
      rule {
        rule_id = "920420"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920430"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920440"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920450"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920480"
        enabled = false
        action  = "Block"
      }
    }
    override {
      rule_group_name = "PHP"
      rule {
        rule_id = "933151"
        enabled = false
        action  = "Block"
      }
    }
  }

  managed_rule {
    type    = "Microsoft_BotManagerRuleSet"
    version = "1.0"
    action  = "Block"
  }

  tags = var.tags
}

# ---- WAF-LMS — SendValuerUpdate FQDNs ----
resource "azurerm_cdn_frontdoor_firewall_policy" "waf_lms" {
  name                = "WAFLMS"
  resource_group_name = data.azurerm_resource_group.afd_rg.name
  sku_name            = var.frontdoor_sku
  enabled             = true
  mode                = var.waf_mode

  custom_rule {
    name     = "AllowHSBCCyberDAST"
    enabled  = true
    priority = 1
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["52.18.33.124/32", "52.210.241.58/32"]
    }
  }

  custom_rule {
    name     = "AllowLMSSource"
    enabled  = true
    priority = 2
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["91.207.110.0/23", "91.102.7.0/24", "154.59.136.0/24"]
    }
  }

  custom_rule {
    name                           = "cve202555182"
    enabled                        = true
    priority                       = 5
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2"
    enabled                        = true
    priority                       = 6
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "BlockLargePostBody"
    enabled                        = true
    priority                       = 8
    type                           = "MatchRule"
    action                         = "Block"
    match_condition {
      match_variable     = "RequestMethod"
      operator           = "Equal"
      negation_condition = false
      match_values       = ["POST"]
    }
    match_condition {
      match_variable     = "PostArgs"
      selector           = "Content-Length"
      operator           = "GreaterThan"
      negation_condition = false
      match_values       = ["131072"]
    }
  }

  custom_rule {
    name                           = "RateLimit"
    enabled                        = true
    priority                       = 10
    type                           = "RateLimitRule"
    action                         = "Block"
    rate_limit_duration_in_minutes = 5
    rate_limit_threshold           = 64724
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rule {
    type    = "Microsoft_DefaultRuleSet"
    version = "2.1"
    action  = "Block"
    override {
      rule_group_name = "PROTOCOL-ENFORCEMENT"
      rule {
        rule_id = "920420"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920430"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920440"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920450"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920480"
        enabled = false
        action  = "Block"
      }
    }
    override {
      rule_group_name = "PHP"
      rule {
        rule_id = "933151"
        enabled = false
        action  = "Block"
      }
    }
  }

  managed_rule {
    type    = "Microsoft_BotManagerRuleSet"
    version = "1.0"
    action  = "Block"
  }

  tags = var.tags
}

# ---- WAF-HSBCPAPI — ECOT / devECOT FQDNs ----
resource "azurerm_cdn_frontdoor_firewall_policy" "waf_hsbcpapi" {
  name                = "WAFHSBCPAPI"
  resource_group_name = data.azurerm_resource_group.afd_rg.name
  sku_name            = var.frontdoor_sku
  enabled             = true
  mode                = var.waf_mode

  custom_rule {
    name     = "AllowHSBCCyberDAST"
    enabled  = true
    priority = 1
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["52.18.33.124/32", "52.210.241.58/32"]
    }
  }

  custom_rule {
    name     = "AllowHSBCPAPISource"
    enabled  = true
    priority = 2
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values = [
        "99.81.103.225/32", "108.128.74.220/32", "54.194.204.117/32",
        "34.251.60.187/32", "54.217.8.240/32", "54.73.152.196/32"
      ]
    }
  }

  custom_rule {
    name                           = "cve202555182"
    enabled                        = true
    priority                       = 5
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2"
    enabled                        = true
    priority                       = 6
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "BlockLargePostBody"
    enabled                        = true
    priority                       = 8
    type                           = "MatchRule"
    action                         = "Block"
    match_condition {
      match_variable     = "RequestMethod"
      operator           = "Equal"
      negation_condition = false
      match_values       = ["POST"]
    }
    match_condition {
      match_variable     = "PostArgs"
      selector           = "Content-Length"
      operator           = "GreaterThan"
      negation_condition = false
      match_values       = ["131072"]
    }
  }

  custom_rule {
    name                           = "RateLimit"
    enabled                        = true
    priority                       = 10
    type                           = "RateLimitRule"
    action                         = "Block"
    rate_limit_duration_in_minutes = 5
    rate_limit_threshold           = 64724
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rule {
    type    = "Microsoft_DefaultRuleSet"
    version = "2.1"
    action  = "Block"
    override {
      rule_group_name = "PROTOCOL-ENFORCEMENT"
      rule {
        rule_id = "920420"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920430"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920440"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920450"
        enabled = false
        action  = "Block"
      }
      rule {
        rule_id = "920480"
        enabled = false
        action  = "Block"
      }
    }
    override {
      rule_group_name = "PHP"
      rule {
        rule_id = "933151"
        enabled = false
        action  = "Block"
      }
    }
  }

  managed_rule {
    type    = "Microsoft_BotManagerRuleSet"
    version = "1.0"
    action  = "Block"
  }

  tags = var.tags
}

# ============================================================================
# CUSTOM DOMAINS — LLD 4.3.8: 10 FQDNs, AFD-managed TLS certs (ManagedCertificate)
# TLS provisioning requires CNAME validation by HSBC DNS team before cert activates.
# ============================================================================

# --- WAF-ADV domains (NotifyAdvResultReady) ---
resource "azurerm_cdn_frontdoor_custom_domain" "notifyadvresultready_prod" {
  name                     = "notifyadvresultready-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "notifyadvresultready.intermediaries.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "notifyadvresultready_sit1" {
  name                     = "notifyadvresultready-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "notifyadvresultready.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "notifyadvresultready_st4_sit2" {
  name                     = "notifyadvresultready-st4-sit2"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "notifyadvresultready-st4.intermediaries-sit2.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

# --- WAF-LMS domains (SendValuerUpdate) ---
resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_prod" {
  name                     = "sendvaluerupdate-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_sit1" {
  name                     = "sendvaluerupdate-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_uat" {
  name                     = "sendvaluerupdate-uat"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries-uat.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

# --- WAF-HSBCPAPI domains (ECOT / devECOT) ---
resource "azurerm_cdn_frontdoor_custom_domain" "ecotgetpropertydetails_prod" {
  name                     = "ecotgetpropertydetails-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "ecotgetpropertydetails.intermediaries.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "ecotnotifypaymentsanction_prod" {
  name                     = "ecotnotifypaymentsanction-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "ecotnotifypaymentsanction.intermediaries.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "devecotgetpropertydetails_sit1" {
  name                     = "devecotgetpropertydetails-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "devecotgetpropertydetails.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "devecotnotifypaymentsanction_sit1" {
  name                     = "devecotnotifypaymentsanction-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "devecotnotifypaymentsanction.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type    = "ManagedCertificate"
    minimum_tls_version = "TLS12"
  }
}

# ============================================================================
# SECURITY POLICIES — Associates WAF policies to custom domain groups
# ============================================================================

resource "azurerm_cdn_frontdoor_security_policy" "adv_security" {
  name                     = "security-waf-adv"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  security_policies {
    firewall {
      cdn_frontdoor_firewall_policy_id = azurerm_cdn_frontdoor_firewall_policy.waf_adv.id
      association {
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_prod.id }
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_sit1.id }
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_st4_sit2.id }
        patterns_to_match = ["/*"]
      }
    }
  }
}

resource "azurerm_cdn_frontdoor_security_policy" "lms_security" {
  name                     = "security-waf-lms"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  security_policies {
    firewall {
      cdn_frontdoor_firewall_policy_id = azurerm_cdn_frontdoor_firewall_policy.waf_lms.id
      association {
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_prod.id }
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_sit1.id }
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_uat.id }
        patterns_to_match = ["/*"]
      }
    }
  }
}

resource "azurerm_cdn_frontdoor_security_policy" "hsbcpapi_security" {
  name                     = "security-waf-hsbcpapi"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  security_policies {
    firewall {
      cdn_frontdoor_firewall_policy_id = azurerm_cdn_frontdoor_firewall_policy.waf_hsbcpapi.id
      association {
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.ecotgetpropertydetails_prod.id }
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.ecotnotifypaymentsanction_prod.id }
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.devecotgetpropertydetails_sit1.id }
        domain { cdn_frontdoor_domain_id = azurerm_cdn_frontdoor_custom_domain.devecotnotifypaymentsanction_sit1.id }
        patterns_to_match = ["/*"]
      }
    }
  }
}

# ============================================================================
# ROUTE — LLD: SI-WEB-RT-HTTPS-01 | HTTPS only | All 10 custom domains → WE endpoint
# ============================================================================

resource "azurerm_cdn_frontdoor_route" "https_route" {
  name                          = "SI-WEB-RT-HTTPS-01"
  cdn_frontdoor_endpoint_id     = azurerm_cdn_frontdoor_endpoint.we_endpoint.id
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.app_origins.id
  cdn_frontdoor_origin_ids = [
    azurerm_cdn_frontdoor_origin.we_origin.id,
    azurerm_cdn_frontdoor_origin.ne_origin.id
  ]
  cdn_frontdoor_custom_domain_ids = [
    azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_prod.id,
    azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_sit1.id,
    azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_st4_sit2.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_prod.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_sit1.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_uat.id,
    azurerm_cdn_frontdoor_custom_domain.ecotgetpropertydetails_prod.id,
    azurerm_cdn_frontdoor_custom_domain.ecotnotifypaymentsanction_prod.id,
    azurerm_cdn_frontdoor_custom_domain.devecotgetpropertydetails_sit1.id,
    azurerm_cdn_frontdoor_custom_domain.devecotnotifypaymentsanction_sit1.id,
  ]
  supported_protocols    = ["Https"]
  patterns_to_match      = ["/*"]
  forwarding_protocol    = "HttpsOnly"
  https_redirect_enabled = true
  link_to_default_domain = true
  enabled                = true
}

# ============================================================================
# DIAGNOSTIC SETTINGS — LLD: Logs + Metrics → LogA-WE
# ============================================================================

resource "azurerm_monitor_diagnostic_setting" "afd_diag" {
  name                       = "SI-WEB-AFD-01-diag"
  target_resource_id         = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.loga_we.id

  enabled_log { category = "FrontDoorAccessLog" }
  enabled_log { category = "FrontDoorHealthProbeLog" }
  enabled_log { category = "FrontDoorWebApplicationFirewallLog" }
  enabled_metric { category = "AllMetrics" }
}

