# Phase 16: VM Cloning Outputs

output "cloned_vms_summary" {
  value = {
    ne_54 = {
      name       = azurerm_linux_virtual_machine.clone_ne_54.name
      id         = azurerm_linux_virtual_machine.clone_ne_54.id
      private_ip = azurerm_network_interface.clone_ne_54_nic.private_ip_address
      rg         = azurerm_linux_virtual_machine.clone_ne_54.resource_group_name
    }
    ne_55 = {
      name       = azurerm_linux_virtual_machine.clone_ne_55.name
      id         = azurerm_linux_virtual_machine.clone_ne_55.id
      private_ip = azurerm_network_interface.clone_ne_55_nic.private_ip_address
      rg         = azurerm_linux_virtual_machine.clone_ne_55.resource_group_name
    }
    we_05 = {
      name       = azurerm_linux_virtual_machine.clone_we_05.name
      id         = azurerm_linux_virtual_machine.clone_we_05.id
      private_ip = azurerm_network_interface.clone_we_05_nic.private_ip_address
      rg         = azurerm_linux_virtual_machine.clone_we_05.resource_group_name
    }
    we_06 = {
      name       = azurerm_linux_virtual_machine.clone_we_06.name
      id         = azurerm_linux_virtual_machine.clone_we_06.id
      private_ip = azurerm_network_interface.clone_we_06_nic.private_ip_address
      rg         = azurerm_linux_virtual_machine.clone_we_06.resource_group_name
    }
    we_04 = {
      name       = azurerm_linux_virtual_machine.clone_we_04.name
      id         = azurerm_linux_virtual_machine.clone_we_04.id
      private_ip = azurerm_network_interface.clone_we_04_nic.private_ip_address
      rg         = azurerm_linux_virtual_machine.clone_we_04.resource_group_name
    }
  }
  description = "Summary of all 5 cloned VMs"
}

output "cloned_vms_ips" {
  value = {
    ne_54 = azurerm_network_interface.clone_ne_54_nic.private_ip_address
    ne_55 = azurerm_network_interface.clone_ne_55_nic.private_ip_address
    we_05 = azurerm_network_interface.clone_we_05_nic.private_ip_address
    we_06 = azurerm_network_interface.clone_we_06_nic.private_ip_address
    we_04 = azurerm_network_interface.clone_we_04_nic.private_ip_address
  }
  description = "New private IPs of cloned VMs"
}

output "snapshots_created" {
  value = {
    ne_54 = azurerm_snapshot.source_ne_54_os_snapshot.name
    ne_55 = azurerm_snapshot.source_ne_55_os_snapshot.name
    we_05 = azurerm_snapshot.source_we_05_os_snapshot.name
    we_06 = azurerm_snapshot.source_we_06_os_snapshot.name
    we_04 = azurerm_snapshot.source_we_04_os_snapshot.name
  }
  description = "OS disk snapshots created"
}

output "managed_disks_created" {
  value = {
    ne_54 = azurerm_managed_disk.clone_ne_54_os_disk.name
    ne_55 = azurerm_managed_disk.clone_ne_55_os_disk.name
    we_05 = azurerm_managed_disk.clone_we_05_os_disk.name
    we_06 = azurerm_managed_disk.clone_we_06_os_disk.name
    we_04 = azurerm_managed_disk.clone_we_04_os_disk.name
  }
  description = "Managed disks created from snapshots"
}

output "availability_sets" {
  value = {
    ne_avset = {
      name = azurerm_availability_set.ne_avset.name
      id   = azurerm_availability_set.ne_avset.id
      vms  = ["SI-RPRXY-DMZ-VM-54", "SI-RPRXY-DMZ-VM-55"]
    }
    we_avset = {
      name = azurerm_availability_set.we_avset.name
      id   = azurerm_availability_set.we_avset.id
      vms  = ["SI-RPRXY-DMZ-VM-05", "SI-RPRXY-DMZ-VM-06"]
    }
    we_04_standalone = {
      name = "SI-RPRXY-DMZ-VM-04 (No Availability Set)"
      note = "Non-Prod VM without HA requirement"
    }
  }
  description = "Availability sets and VM assignments"
}
