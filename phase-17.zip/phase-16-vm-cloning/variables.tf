# Phase 16: VM Cloning Variables

variable "primary_subscription_id" {
  type        = string
  sensitive   = true
  description = "Azure subscription ID for primary region"
}

variable "secondary_subscription_id" {
  type        = string
  sensitive   = true
  description = "Azure subscription ID for secondary region"
}

variable "source_vms" {
  type = list(object({
    existing_name      = string  # Source VM name
    new_name           = string  # Cloned VM name
    old_rg             = string  # Source resource group
    new_rg             = string  # Target resource group
    location           = string  # Azure region
    vm_size            = string  # VM SKU (e.g., Standard_D2s_v2)
    old_private_ip     = string  # Source private IP
    new_private_ip     = string  # Target private IP (in new VNet)
    old_vnet           = string  # Source VNet
    new_vnet           = string  # Target VNet
    old_subnet         = string  # Source subnet
    new_subnet         = string  # Target subnet
    os_disk_type       = string  # Storage account type (Premium_LRS, Standard_LRS, etc.)
    is_prod            = bool    # Is production environment
  }))
  
  description = "Source VMs to clone with target configuration"
}

variable "admin_username" {
  type        = string
  default     = "azureuser"
  description = "Admin username for Linux VMs"
}

variable "admin_password" {
  type        = string
  sensitive   = true
  description = "Admin password for Linux VMs (must meet Azure complexity requirements)"
}
