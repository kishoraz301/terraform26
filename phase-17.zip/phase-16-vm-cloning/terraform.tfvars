# Phase 16: VM Cloning Configuration
# Data from architect - 5 NGINX proxy VMs to clone from old RGs to new DMZ RGs

primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"

admin_username = "azureuser"
# Password must contain uppercase, lowercase, number, and special character
admin_password = "Hsbc@DmzNginx2026!Secure"  # Change this to your desired password

source_vms = [
  {
    # NE Region - VM 54 (Prod: Yes)
    existing_name   = "SI-RPRXY-VM-54"
    new_name        = "SI-RPRXY-DMZ-VM-54"
    old_rg          = "si-rprxy-ne-rg"
    new_rg          = "si-dmz-rprxy-ne-01-rg"
    location        = "northeurope"
    vm_size         = "Standard_D2s_v2"
    old_private_ip  = "10.150.253.6"
    new_private_ip  = "10.200.12.2"
    old_vnet        = "MIP-SI-NE-vnet"
    new_vnet        = "MIP-SI-NE-ciDMZ-vnet"
    old_subnet      = "MIP-SI-NE-NGINX-snet"
    new_subnet      = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"
    os_disk_type    = "Standard_LRS"
    is_prod         = true
  },
  {
    # NE Region - VM 55 (Prod: Yes)
    existing_name   = "SI-RPRXY-VM-55"
    new_name        = "SI-RPRXY-DMZ-VM-55"
    old_rg          = "si-rprxy-ne-rg"
    new_rg          = "si-dmz-rprxy-ne-01-rg"
    location        = "northeurope"
    vm_size         = "Standard_D2s_v2"
    old_private_ip  = "10.150.253.7"
    new_private_ip  = "10.200.12.3"
    old_vnet        = "MIP-SI-NE-vnet"
    new_vnet        = "MIP-SI-NE-ciDMZ-vnet"
    old_subnet      = "MIP-SI-NE-NGINX-snet"
    new_subnet      = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"
    os_disk_type    = "Standard_LRS"
    is_prod         = true
  },
  {
    # WE Region - VM 05 (Prod: Yes)
    existing_name   = "SI-RPRXY-VM-05"
    new_name        = "SI-RPRXY-DMZ-VM-05"
    old_rg          = "si-rprxy-we-rg"
    new_rg          = "si-dmz-rprxy-we-01-rg"
    location        = "westeurope"
    vm_size         = "Standard_D2s_v2"
    old_private_ip  = "10.100.253.9"
    new_private_ip  = "10.200.11.2"
    old_vnet        = "MIP-SI-WE-vnet"
    new_vnet        = "MIP-SI-WE-ciDMZ-vnet"
    old_subnet      = "MIP-SI-WE-NGINX-snet"
    new_subnet      = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
    os_disk_type    = "Standard_LRS"
    is_prod         = true
  },
  {
    # WE Region - VM 06 (Prod: Yes)
    existing_name   = "SI-RPRXY-VM-06"
    new_name        = "SI-RPRXY-DMZ-VM-06"
    old_rg          = "si-rprxy-we-rg"
    new_rg          = "si-dmz-rprxy-we-01-rg"
    location        = "westeurope"
    vm_size         = "Standard_D2s_v2"
    old_private_ip  = "10.100.253.10"
    new_private_ip  = "10.200.11.3"
    old_vnet        = "MIP-SI-WE-vnet"
    new_vnet        = "MIP-SI-WE-ciDMZ-vnet"
    old_subnet      = "MIP-SI-WE-NGINX-snet"
    new_subnet      = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
    os_disk_type    = "Standard_LRS"
    is_prod         = true
  },
  {
    # WE Region - VM 04 (Prod: No)
    existing_name   = "SI-RPRXY-VM-04"
    new_name        = "SI-RPRXY-DMZ-VM-04"
    old_rg          = "si-rprxy-we-rg"
    new_rg          = "si-dmz-rprxy-we-01-rg"
    location        = "westeurope"
    vm_size         = "Standard_D2s_v2"
    old_private_ip  = "10.100.253.8"
    new_private_ip  = "10.200.11.8"
    old_vnet        = "MIP-SI-WE-vnet"
    new_vnet        = "MIP-SI-WE-ciDMZ-vnet"
    old_subnet      = "MIP-SI-WE-NGINX-snet"
    new_subnet      = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
    os_disk_type    = "Standard_LRS"
    is_prod         = false
  },
]
