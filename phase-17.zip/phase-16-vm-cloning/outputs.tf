# Phase 16: VM Cloning Outputs

output "cloned_vms_summary" {
  value = {
    ne_54 = {
      name       = azurerm_virtual_machine.clone_ne_54.name
      id         = azurerm_virtual_machine.clone_ne_54.id
      private_ip = azurerm_network_interface.clone_ne_54_nic.private_ip_address
      rg         = azurerm_virtual_machine.clone_ne_54.resource_group_name
    }
    ne_55 = {
      name       = azurerm_virtual_machine.clone_ne_55.name
      id         = azurerm_virtual_machine.clone_ne_55.id
      private_ip = azurerm_network_interface.clone_ne_55_nic.private_ip_address
      rg         = azurerm_virtual_machine.clone_ne_55.resource_group_name
    }
    we_05 = {
      name       = azurerm_virtual_machine.clone_we_05.name
      id         = azurerm_virtual_machine.clone_we_05.id
      private_ip = azurerm_network_interface.clone_we_05_nic.private_ip_address
      rg         = azurerm_virtual_machine.clone_we_05.resource_group_name
    }
    we_06 = {
      name       = azurerm_virtual_machine.clone_we_06.name
      id         = azurerm_virtual_machine.clone_we_06.id
      private_ip = azurerm_network_interface.clone_we_06_nic.private_ip_address
      rg         = azurerm_virtual_machine.clone_we_06.resource_group_name
    }
    we_04 = {
      name       = azurerm_virtual_machine.clone_we_04.name
      id         = azurerm_virtual_machine.clone_we_04.id
      private_ip = azurerm_network_interface.clone_we_04_nic.private_ip_address
      rg         = azurerm_virtual_machine.clone_we_04.resource_group_name
    }
  }
  description = "Summary of all 5 cloned VMs"
}

output "cloned_vms_ips" {
  value = {
    ne_54 = azurerm_network_interface.clone_ne_54_nic.private_ip_address
    ne_55 = azurerm_network_interface.clone_ne_55_nic.private_ip_address
    we_05 = azurerm_network_interface.clone_we_05_nic.private_ip_address
    we_06 = azurerm_network_interface.clone_we_06_nic.private_ip_address
    we_04 = azurerm_network_interface.clone_we_04_nic.private_ip_address
  }
  description = "New private IPs of cloned VMs"
}

output "availability_sets" {
  value = {
    ne_avset = {
      name = azurerm_availability_set.ne_avset.name
      vms  = ["SI-RPRXY-DMZ-VM-54", "SI-RPRXY-DMZ-VM-55"]
    }
    we_avset = {
      name = azurerm_availability_set.we_avset.name
      vms  = ["SI-RPRXY-DMZ-VM-05", "SI-RPRXY-DMZ-VM-06"]
    }
    we_04 = "Standalone (No Availability Set)"
  }
  description = "Availability sets and VM assignments"
}
