# Azure Subscription Configuration
primary_subscription_id   = "b3179146-e675-480d-aa38-23ec90529400"
secondary_subscription_id = "b3179146-e675-480d-aa38-23ec90529400"

# Region Configuration
primary_region   = "westeurope"
secondary_region = "northeurope"

# Resource Group Names
primary_rg_name   = "MIP-SI-WE-RG"
secondary_rg_name = "MIP-SI-NE-RG"

# VNet Names
cedmz_vnet_we = "MIP-SI-WE-ceDMZ-vnet"
cedmz_vnet_ne = "MIP-SI-NE-ceDMZ-vnet"
cidmz_vnet_we = "MIP-SI-WE-ciDMZ-vnet"
cidmz_vnet_ne = "MIP-SI-NE-ciDMZ-vnet"

# Firewall Subnet Names
cedmz_fw_subnet_we = "AzureFirewallSubnet"
cedmz_fw_subnet_ne = "AzureFirewallSubnet"
cidmz_fw_subnet_we = "AzureFirewallSubnet"
cidmz_fw_subnet_ne = "AzureFirewallSubnet"
