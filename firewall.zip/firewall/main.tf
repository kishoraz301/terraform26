terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.primary_subscription_id
  features {
    virtual_machine {
    }
  }
}

provider "azurerm" {
  alias           = "secondary"
  subscription_id = var.secondary_subscription_id
  features {
    virtual_machine {
    }
  }
}

# ============================================================================
# Data Sources
# ============================================================================

# Primary Region Resources
data "azurerm_resource_group" "primary" {
  name = var.primary_rg_name
}

data "azurerm_virtual_network" "cedmz_primary" {
  name                = var.cedmz_vnet_we
  resource_group_name = data.azurerm_resource_group.primary.name
}

data "azurerm_virtual_network" "cidmz_primary" {
  name                = var.cidmz_vnet_we
  resource_group_name = data.azurerm_resource_group.primary.name
}

data "azurerm_subnet" "cedmz_fw_primary" {
  name                 = var.cedmz_fw_subnet_we
  virtual_network_name = data.azurerm_virtual_network.cedmz_primary.name
  resource_group_name  = data.azurerm_resource_group.primary.name
}

data "azurerm_subnet" "cidmz_fw_primary" {
  name                 = var.cidmz_fw_subnet_we
  virtual_network_name = data.azurerm_virtual_network.cidmz_primary.name
  resource_group_name  = data.azurerm_resource_group.primary.name
}

# Secondary Region Resources
data "azurerm_resource_group" "secondary" {
  provider = azurerm.secondary
  name     = var.secondary_rg_name
}

data "azurerm_virtual_network" "cedmz_secondary" {
  provider            = azurerm.secondary
  name                = var.cedmz_vnet_ne
  resource_group_name = data.azurerm_resource_group.secondary.name
}

data "azurerm_virtual_network" "cidmz_secondary" {
  provider            = azurerm.secondary
  name                = var.cidmz_vnet_ne
  resource_group_name = data.azurerm_resource_group.secondary.name
}

data "azurerm_subnet" "cedmz_fw_secondary" {
  provider             = azurerm.secondary
  name                 = var.cedmz_fw_subnet_ne
  virtual_network_name = data.azurerm_virtual_network.cedmz_secondary.name
  resource_group_name  = data.azurerm_resource_group.secondary.name
}

data "azurerm_subnet" "cidmz_fw_secondary" {
  provider             = azurerm.secondary
  name                 = var.cidmz_fw_subnet_ne
  virtual_network_name = data.azurerm_virtual_network.cidmz_secondary.name
  resource_group_name  = data.azurerm_resource_group.secondary.name
}

# ============================================================================
# CE DMZ Azure Firewall Premium - West Europe
# ============================================================================

resource "azurerm_public_ip" "cedmz_fw_pip_we" {
  name                = "SI-CEDMZ-WE-FW-01-PIP"
  location            = var.primary_region
  resource_group_name = data.azurerm_resource_group.primary.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1"]
}

resource "azurerm_firewall_policy" "cedmz_policy_we" {
  name                = "SI-CEDMZ-FWPLCY-01"
  location            = var.primary_region
  resource_group_name = data.azurerm_resource_group.primary.name
  sku                 = "Premium"
}

module "cedmz_we" {
  source  = "Azure/avm-res-network-azurefirewall/azurerm"
  version = "0.4.0"

  name                = "SI-CEDMZ-WE-FW-01"
  location            = var.primary_region
  resource_group_name = data.azurerm_resource_group.primary.name

  firewall_sku_name  = "AZFW_VNet"
  firewall_sku_tier  = "Premium"
  firewall_policy_id = azurerm_firewall_policy.cedmz_policy_we.id
  firewall_zones     = ["1"]

  ip_configurations = {
    configuration = {
      name                 = "configuration"
      subnet_id            = data.azurerm_subnet.cedmz_fw_primary.id
      public_ip_address_id = azurerm_public_ip.cedmz_fw_pip_we.id
    }
  }
}

# ============================================================================
# CE DMZ Azure Firewall Premium - North Europe
# ============================================================================

resource "azurerm_public_ip" "cedmz_fw_pip_ne" {
  provider            = azurerm.secondary
  name                = "SI-CEDMZ-NE-FW-51-PIP"
  location            = var.secondary_region
  resource_group_name = data.azurerm_resource_group.secondary.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1"]
}

resource "azurerm_firewall_policy" "cedmz_policy_ne" {
  provider            = azurerm.secondary
  name                = "SI-CEDMZ-FWPLCY-51"
  location            = var.secondary_region
  resource_group_name = data.azurerm_resource_group.secondary.name
  sku                 = "Premium"
}

module "cedmz_ne" {
  source  = "Azure/avm-res-network-azurefirewall/azurerm"
  version = "0.4.0"

  providers = {
    azurerm = azurerm.secondary
  }

  name                = "SI-CEDMZ-NE-FW-51"
  location            = var.secondary_region
  resource_group_name = data.azurerm_resource_group.secondary.name

  firewall_sku_name  = "AZFW_VNet"
  firewall_sku_tier  = "Premium"
  firewall_policy_id = azurerm_firewall_policy.cedmz_policy_ne.id
  firewall_zones     = ["1"]

  ip_configurations = {
    configuration = {
      name                 = "configuration"
      subnet_id            = data.azurerm_subnet.cedmz_fw_secondary.id
      public_ip_address_id = azurerm_public_ip.cedmz_fw_pip_ne.id
    }
  }
}

# ============================================================================
# CI DMZ Azure Firewall Standard - West Europe
# ============================================================================

resource "azurerm_public_ip" "cidmz_fw_pip_we" {
  name                = "SI-CIDMZ-WE-FWSTD-01-PIP"
  location            = var.primary_region
  resource_group_name = data.azurerm_resource_group.primary.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1"]
}

resource "azurerm_firewall_policy" "cidmz_policy_we" {
  name                = "SI-CIDMZ-FWPLCY-WE-STD"
  location            = var.primary_region
  resource_group_name = data.azurerm_resource_group.primary.name
  sku                 = "Standard"
}

module "cidmz_we" {
  source  = "Azure/avm-res-network-azurefirewall/azurerm"
  version = "0.4.0"

  name                = "SI-DMZ-WE-FWSTD-01"
  location            = var.primary_region
  resource_group_name = data.azurerm_resource_group.primary.name

  firewall_sku_name  = "AZFW_VNet"
  firewall_sku_tier  = "Standard"
  firewall_policy_id = azurerm_firewall_policy.cidmz_policy_we.id
  firewall_zones     = ["1"]

  ip_configurations = {
    configuration = {
      name                 = "configuration"
      subnet_id            = data.azurerm_subnet.cidmz_fw_primary.id
      public_ip_address_id = azurerm_public_ip.cidmz_fw_pip_we.id
    }
  }
}

# ============================================================================
# CI DMZ Azure Firewall Standard - North Europe
# ============================================================================

resource "azurerm_public_ip" "cidmz_fw_pip_ne" {
  provider            = azurerm.secondary
  name                = "SI-CIDMZ-NE-FWSTD-51-PIP"
  location            = var.secondary_region
  resource_group_name = data.azurerm_resource_group.secondary.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1"]
}

resource "azurerm_firewall_policy" "cidmz_policy_ne" {
  provider            = azurerm.secondary
  name                = "SI-CIDMZ-FWPLCY-NE-STD"
  location            = var.secondary_region
  resource_group_name = data.azurerm_resource_group.secondary.name
  sku                 = "Standard"
}

module "cidmz_ne" {
  source  = "Azure/avm-res-network-azurefirewall/azurerm"
  version = "0.4.0"

  providers = {
    azurerm = azurerm.secondary
  }

  name                = "SI-DMZ-NE-FWSTD-51"
  location            = var.secondary_region
  resource_group_name = data.azurerm_resource_group.secondary.name

  firewall_sku_name  = "AZFW_VNet"
  firewall_sku_tier  = "Standard"
  firewall_policy_id = azurerm_firewall_policy.cidmz_policy_ne.id
  firewall_zones     = ["1"]

  ip_configurations = {
    configuration = {
      name                 = "configuration"
      subnet_id            = data.azurerm_subnet.cidmz_fw_secondary.id
      public_ip_address_id = azurerm_public_ip.cidmz_fw_pip_ne.id
    }
  }
}
