output "cedmz_firewall_we" {
  description = "CE DMZ Firewall Premium - West Europe details"
  value = {
    id       = module.cedmz_we.resource_id
    name     = module.cedmz_we.resource.name
    sku_tier = module.cedmz_we.resource.sku_tier
    pip      = azurerm_public_ip.cedmz_fw_pip_we.ip_address
  }
}

output "cedmz_firewall_ne" {
  description = "CE DMZ Firewall Premium - North Europe details"
  value = {
    id       = module.cedmz_ne.resource_id
    name     = module.cedmz_ne.resource.name
    sku_tier = module.cedmz_ne.resource.sku_tier
    pip      = azurerm_public_ip.cedmz_fw_pip_ne.ip_address
  }
}

output "cidmz_firewall_we" {
  description = "CI DMZ Firewall Standard - West Europe details"
  value = {
    id       = module.cidmz_we.resource_id
    name     = module.cidmz_we.resource.name
    sku_tier = module.cidmz_we.resource.sku_tier
  }
}

output "cidmz_firewall_ne" {
  description = "CI DMZ Firewall Standard - North Europe details"
  value = {
    id       = module.cidmz_ne.resource_id
    name     = module.cidmz_ne.resource.name
    sku_tier = module.cidmz_ne.resource.sku_tier
  }
}

output "cedmz_policy_we_id" {
  description = "CE DMZ Firewall Policy (WE) ID"
  value       = azurerm_firewall_policy.cedmz_policy_we.id
}

output "cedmz_policy_ne_id" {
  description = "CE DMZ Firewall Policy (NE) ID"
  value       = azurerm_firewall_policy.cedmz_policy_ne.id
}

output "cidmz_policy_we_id" {
  description = "CI DMZ Firewall Policy (WE) ID"
  value       = azurerm_firewall_policy.cidmz_policy_we.id
}

output "cidmz_policy_ne_id" {
  description = "CI DMZ Firewall Policy (NE) ID"
  value       = azurerm_firewall_policy.cidmz_policy_ne.id
}
