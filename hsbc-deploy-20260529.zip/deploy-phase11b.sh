#!/bin/bash
# deploy-phase11b.sh
# Imports existing AFD WAF policies (if they were previously in phase-11),
# then applies security policy associations.
#
# Run from: ~/landing-zone-deploy/phase-11b-waf-policies
# Usage:    bash ~/deploy-phase11b.sh

set -euo pipefail

SUB="9bde6346-5250-49f9-a010-3ac07609cb70"
RG="si-cedmz-we-01-rg"

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
header() { echo -e "\n${CYAN}=== $1 ===${NC}\n"; }
ok()     { echo -e "${GREEN}[OK]${NC} $1"; }
skip()   { echo -e "${YELLOW}[SKIP]${NC} $1 — not found in Azure, will be created"; }

header "Step 1 — Init"
terraform init -upgrade -input=false

header "Step 2 — Import existing AFD WAF policies (if present from phase-11)"

for POLICY in WAFADV WAFLMS WAFHSBCPAPI; do
  TF_ADDR=""
  case "$POLICY" in
    WAFADV)     TF_ADDR="azurerm_cdn_frontdoor_firewall_policy.waf_adv" ;;
    WAFLMS)     TF_ADDR="azurerm_cdn_frontdoor_firewall_policy.waf_lms" ;;
    WAFHSBCPAPI) TF_ADDR="azurerm_cdn_frontdoor_firewall_policy.waf_hsbcpapi" ;;
  esac

  POLICY_ID=$(az network front-door waf-policy show \
    --name "$POLICY" --resource-group "$RG" \
    --subscription "$SUB" --query id -o tsv 2>/dev/null || true)

  if [[ -n "$POLICY_ID" ]]; then
    terraform import "$TF_ADDR" "$POLICY_ID" \
      && ok "Imported $TF_ADDR" || ok "$TF_ADDR already in state"
  else
    skip "$POLICY"
  fi
done

header "Step 3 — Plan"
terraform plan -out=phase11b.tfplan

header "Step 4 — Apply"
terraform apply -auto-approve phase11b.tfplan

echo -e "\n${GREEN}Phase 11b deployment complete.${NC}\n"
