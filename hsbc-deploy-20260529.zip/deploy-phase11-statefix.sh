#!/bin/bash
# deploy-phase11-statefix.sh
# Removes WAF resources moved to phase-11b from phase-11 state.
# No new resources are deployed — phase-11 itself is already fully deployed.
#
# Run from: ~/landing-zone-deploy/phase-11-front-door
# Usage:    bash ~/deploy-phase11-statefix.sh

set -euo pipefail

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
header() { echo -e "\n${CYAN}=== $1 ===${NC}\n"; }
ok()     { echo -e "${GREEN}[OK]${NC} $1"; }
skip()   { echo -e "${YELLOW}[SKIP]${NC} $1 — not in state"; }

header "Phase 11 — State cleanup (WAF resources moved to phase-11b)"

terraform init -upgrade -input=false

RESOURCES_TO_REMOVE=(
  "azurerm_cdn_frontdoor_firewall_policy.waf_adv"
  "azurerm_cdn_frontdoor_firewall_policy.waf_lms"
  "azurerm_cdn_frontdoor_firewall_policy.waf_hsbcpapi"
  "azurerm_cdn_frontdoor_security_policy.adv_security"
  "azurerm_cdn_frontdoor_security_policy.lms_security"
  "azurerm_cdn_frontdoor_security_policy.hsbcpapi_security"
)

for res in "${RESOURCES_TO_REMOVE[@]}"; do
  if terraform state list 2>/dev/null | grep -q "^${res}$"; then
    terraform state rm "$res"
    ok "Removed $res"
  else
    skip "$res"
  fi
done

echo -e "\n${GREEN}Phase 11 state cleanup complete. Ready to deploy phase-11b.${NC}\n"
