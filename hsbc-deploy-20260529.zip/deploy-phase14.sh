#!/bin/bash
# deploy-phase14.sh
# Deploys Backup Private Endpoints for WE and NE.
# Imports existing private endpoints if already present.
#
# Run from: ~/landing-zone-deploy/phase-14-waf-policies
# Usage:    bash ~/deploy-phase14.sh

set -euo pipefail

SUB="9bde6346-5250-49f9-a010-3ac07609cb70"
WE_PE_RG="SI-OPS-WE-01-rg"
NE_PE_RG="SI-OPS-NE-01-rg"

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
header() { echo -e "\n${CYAN}=== $1 ===${NC}\n"; }
ok()     { echo -e "${GREEN}[OK]${NC} $1"; }
skip()   { echo -e "${YELLOW}[SKIP]${NC} $1 — not found in Azure, will be created"; }

header "Step 1 — Init"
terraform init -upgrade -input=false

header "Step 2 — Import existing private endpoints (if present)"

WE_PE_ID=$(az network private-endpoint show \
  --name "SI-PEP-WE-RSV" --resource-group "$WE_PE_RG" \
  --subscription "$SUB" --query id -o tsv 2>/dev/null || true)

if [[ -n "$WE_PE_ID" ]]; then
  terraform import azurerm_private_endpoint.we_backup_pe "$WE_PE_ID" \
    && ok "Imported we_backup_pe" || ok "we_backup_pe already in state"
else
  skip "SI-PEP-WE-RSV"
fi

NE_PE_ID=$(az network private-endpoint show \
  --name "SI-PEP-NE-RSV" --resource-group "$NE_PE_RG" \
  --subscription "$SUB" --query id -o tsv 2>/dev/null || true)

if [[ -n "$NE_PE_ID" ]]; then
  terraform import azurerm_private_endpoint.ne_backup_pe "$NE_PE_ID" \
    && ok "Imported ne_backup_pe" || ok "ne_backup_pe already in state"
else
  skip "SI-PEP-NE-RSV"
fi

header "Step 3 — Plan"
terraform plan -out=phase14.tfplan

header "Step 4 — Apply"
terraform apply -auto-approve phase14.tfplan

echo -e "\n${GREEN}Phase 14 deployment complete.${NC}\n"
