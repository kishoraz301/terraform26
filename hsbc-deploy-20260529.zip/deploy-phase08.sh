#!/bin/bash
# deploy-phase08.sh
# Imports existing AppGWs (the only resources that will conflict),
# then applies everything else — WAF policies, KV access, diagnostics, etc.
#
# Run from: ~/landing-zone-deploy/phase-08-application-gateways
# Usage:    bash ~/deploy-phase08.sh

set -euo pipefail

SUB="9bde6346-5250-49f9-a010-3ac07609cb70"
WE_RG="si-dmz-appgw-we-01-rg"
NE_RG="si-dmz-appgw-ne-01-rg"

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
header() { echo -e "\n${CYAN}=== $1 ===${NC}\n"; }
ok()     { echo -e "${GREEN}[OK]${NC} $1"; }
skip()   { echo -e "${YELLOW}[SKIP]${NC} $1 — not found in Azure, will be created by Terraform"; }

header "Step 1 — Import existing Application Gateways"

# WE AppGW
WE_EXISTS=$(az network application-gateway show \
  --name "SI-DMZ-WE-APPGW-01" --resource-group "$WE_RG" \
  --subscription "$SUB" --query id -o tsv 2>/dev/null || true)

if [[ -n "$WE_EXISTS" ]]; then
  terraform import azurerm_application_gateway.we_appgw "$WE_EXISTS" \
    && ok "Imported we_appgw" || ok "we_appgw already in state"
else
  skip "SI-DMZ-WE-APPGW-01"
fi

# NE AppGW
NE_EXISTS=$(az network application-gateway show \
  --name "SI-CIDMZ-NE-APPGW-51" --resource-group "$NE_RG" \
  --subscription "$SUB" --query id -o tsv 2>/dev/null || true)

if [[ -n "$NE_EXISTS" ]]; then
  terraform import azurerm_application_gateway.ne_appgw "$NE_EXISTS" \
    && ok "Imported ne_appgw" || ok "ne_appgw already in state"
else
  skip "SI-CIDMZ-NE-APPGW-51"
fi

header "Step 2 — Plan"
terraform plan -var-file=certs.tfvars -out=phase08.tfplan

header "Step 3 — Apply"
terraform apply -auto-approve phase08.tfplan

echo -e "\n${GREEN}Phase 08 deployment complete.${NC}\n"
