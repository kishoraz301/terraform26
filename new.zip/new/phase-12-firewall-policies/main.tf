# Phase 12: Azure Firewall Policies (NAT, Network, Application Rules)
# Deploy after Phase 06: Azure Firewalls

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# ============================================================================
# WEST EUROPE - Firewall Policies
# ============================================================================

# Common rule collection for both firewalls
resource "azurerm_firewall_policy" "we_firewall_policy" {
  name                = "MIP-SI-WE-FW-Policy"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  sku                 = "Standard"

  threat_intelligence_allowlist {
    ip_addresses = []
    fqdns        = []
  }
}

# NAT rule collection - inbound HTTP/HTTPS
resource "azurerm_firewall_policy_rule_collection_group" "we_nat_rules" {
  name               = "MIP-SI-WE-NAT-Rules"
  firewall_policy_id = azurerm_firewall_policy.we_firewall_policy.id
  priority           = 100

  nat_rule_collection {
    name     = "AllowInboundHTTP-HTTPS"
    priority = 100
    action   = "Dnat"

    rule {
      name                = "Allow-HTTP"
      protocols           = ["TCP"]
      source_addresses    = ["*"]
      destination_address = "0.0.0.0/0"
      destination_ports   = ["80"]
      translated_address  = "10.200.11.20"
      translated_port     = "80"
    }

    rule {
      name                = "Allow-HTTPS"
      protocols           = ["TCP"]
      source_addresses    = ["*"]
      destination_address = "0.0.0.0/0"
      destination_ports   = ["443"]
      translated_address  = "10.200.11.20"
      translated_port     = "443"
    }
  }
}

# Network rule collection - internal connectivity
resource "azurerm_firewall_policy_rule_collection_group" "we_network_rules" {
  name               = "MIP-SI-WE-Network-Rules"
  firewall_policy_id = azurerm_firewall_policy.we_firewall_policy.id
  priority           = 200

  network_rule_collection {
    name     = "AllowInternal"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "Allow-DNS"
      protocols             = ["UDP"]
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["8.8.8.8", "8.8.4.4"]
      destination_ports     = ["53"]
    }

    rule {
      name                  = "Allow-NTP"
      protocols             = ["UDP"]
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["0.0.0.0/0"]
      destination_ports     = ["123"]
    }

    rule {
      name                  = "Allow-Internal-Traffic"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["10.0.0.0/8"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "DenyAll"
    priority = 200
    action   = "Deny"

    rule {
      name                  = "Deny-All"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["0.0.0.0/0"]
      destination_addresses = ["0.0.0.0/0"]
      destination_ports     = ["*"]
    }
  }
}

# Application rule collection - Azure services
resource "azurerm_firewall_policy_rule_collection_group" "we_app_rules" {
  name               = "MIP-SI-WE-App-Rules"
  firewall_policy_id = azurerm_firewall_policy.we_firewall_policy.id
  priority           = 300

  application_rule_collection {
    name     = "AllowAzureServices"
    priority = 100
    action   = "Allow"

    rule {
      name             = "Allow-Microsoft"
      source_addresses = ["10.0.0.0/8"]
      protocols {
        port = "443"
        type = "Https"
      }
      destination_fqdns = [
        "*.microsoftonline.com",
        "*.microsoft.com",
        "*.azure.com",
        "*.windows.net"
      ]
    }

    rule {
      name             = "Allow-Updates"
      source_addresses = ["10.0.0.0/8"]
      protocols {
        port = "443"
        type = "Https"
      }
      destination_fqdns = [
        "*.windowsupdate.com",
        "*.update.microsoft.com"
      ]
    }
  }
}

# Firewall Policy associations (would be done when firewalls are created)
# These outputs can be used to associate the policy

# ============================================================================
# NORTH EUROPE - Firewall Policies (mirrored configuration)
# ============================================================================

resource "azurerm_firewall_policy" "ne_firewall_policy" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-FW-Policy"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  sku                 = "Standard"

  threat_intelligence_allowlist {
    ip_addresses = []
    fqdns        = []
  }
}

resource "azurerm_firewall_policy_rule_collection_group" "ne_nat_rules" {
  provider           = azurerm.secondary
  name               = "MIP-SI-NE-NAT-Rules"
  firewall_policy_id = azurerm_firewall_policy.ne_firewall_policy.id
  priority           = 100

  nat_rule_collection {
    name     = "AllowInboundHTTP-HTTPS"
    priority = 100
    action   = "Dnat"

    rule {
      name                = "Allow-HTTP"
      protocols           = ["TCP"]
      source_addresses    = ["*"]
      destination_address = "0.0.0.0/0"
      destination_ports   = ["80"]
      translated_address  = "10.200.12.20"
      translated_port     = "80"
    }

    rule {
      name                = "Allow-HTTPS"
      protocols           = ["TCP"]
      source_addresses    = ["*"]
      destination_address = "0.0.0.0/0"
      destination_ports   = ["443"]
      translated_address  = "10.200.12.20"
      translated_port     = "443"
    }
  }
}

resource "azurerm_firewall_policy_rule_collection_group" "ne_network_rules" {
  provider           = azurerm.secondary
  name               = "MIP-SI-NE-Network-Rules"
  firewall_policy_id = azurerm_firewall_policy.ne_firewall_policy.id
  priority           = 200

  network_rule_collection {
    name     = "AllowInternal"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "Allow-DNS"
      protocols             = ["UDP"]
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["8.8.8.8", "8.8.4.4"]
      destination_ports     = ["53"]
    }

    rule {
      name                  = "Allow-NTP"
      protocols             = ["UDP"]
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["0.0.0.0/0"]
      destination_ports     = ["123"]
    }

    rule {
      name                  = "Allow-Internal-Traffic"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["10.0.0.0/8"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "DenyAll"
    priority = 200
    action   = "Deny"

    rule {
      name                  = "Deny-All"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["0.0.0.0/0"]
      destination_addresses = ["0.0.0.0/0"]
      destination_ports     = ["*"]
    }
  }
}

resource "azurerm_firewall_policy_rule_collection_group" "ne_app_rules" {
  provider           = azurerm.secondary
  name               = "MIP-SI-NE-App-Rules"
  firewall_policy_id = azurerm_firewall_policy.ne_firewall_policy.id
  priority           = 300

  application_rule_collection {
    name     = "AllowAzureServices"
    priority = 100
    action   = "Allow"

    rule {
      name             = "Allow-Microsoft"
      source_addresses = ["10.0.0.0/8"]
      protocols {
        port = "443"
        type = "Https"
      }
      destination_fqdns = [
        "*.microsoftonline.com",
        "*.microsoft.com",
        "*.azure.com",
        "*.windows.net"
      ]
    }

    rule {
      name             = "Allow-Updates"
      source_addresses = ["10.0.0.0/8"]
      protocols {
        port = "443"
        type = "Https"
      }
      destination_fqdns = [
        "*.windowsupdate.com",
        "*.update.microsoft.com"
      ]
    }
  }
}

