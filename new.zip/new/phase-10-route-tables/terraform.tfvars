# Azure Subscription Configuration
primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"

# Resource Group Names
we_resource_group_name = "MIP-SI-WE-RG"
ne_resource_group_name = "MIP-SI-NE-RG"
