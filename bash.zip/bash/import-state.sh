#!/bin/bash
# Terraform state import script — Phase 08 Application Gateways
# Run this in ~/phase08/ in Cloud Shell after terraform init
# Usage: bash import-state.sh

set -e
SUB="9bde6346-5250-49f9-a010-3ac07609cb70"
WE_RG="si-dmz-appgw-we-01-rg"
NE_RG="si-dmz-appgw-ne-01-rg"
BASE_WE_RG="MIP-SI-WE-RG"
WE_KV_RG="SI-Core-WE-01-rg"
NE_KV_RG="SI-Core-NE-51-rg"
WE_KV="SI-Core-Vault-WE-01"
NE_KV="SI-Core-Vault-NE-51"
DNS_ZONE="privatelink.vaultcore.azure.net"

# Object IDs of the AppGW Managed Identities (from Azure portal / az cli)
WE_MI_OID="d78e0954-bd98-497e-86ef-1511e1f27df0"
NE_MI_OID="5d05488c-5ded-4ef3-bfb6-52f2f07d2202"

echo "=== Importing WAF Policies ==="
terraform import azurerm_web_application_firewall_policy.we_waf_policy \
  "/subscriptions/${SUB}/resourceGroups/${WE_RG}/providers/Microsoft.Network/applicationGatewayWebApplicationFirewallPolicies/SI-DMZ-WAFPLCY-01"

terraform import azurerm_web_application_firewall_policy.ne_waf_policy \
  "/subscriptions/${SUB}/resourceGroups/${NE_RG}/providers/Microsoft.Network/applicationGatewayWebApplicationFirewallPolicies/SI-DMZ-WAFPLCY-51"

terraform import azurerm_web_application_firewall_policy.we_lms_policy \
  "/subscriptions/${SUB}/resourceGroups/${WE_RG}/providers/Microsoft.Network/applicationGatewayWebApplicationFirewallPolicies/WAF-LMS"

terraform import azurerm_web_application_firewall_policy.we_hsbcpapi_policy \
  "/subscriptions/${SUB}/resourceGroups/${WE_RG}/providers/Microsoft.Network/applicationGatewayWebApplicationFirewallPolicies/WAF-HSBCPAPI"

terraform import azurerm_web_application_firewall_policy.ne_lms_policy \
  "/subscriptions/${SUB}/resourceGroups/${NE_RG}/providers/Microsoft.Network/applicationGatewayWebApplicationFirewallPolicies/WAF-LMS"

terraform import azurerm_web_application_firewall_policy.ne_hsbcpapi_policy \
  "/subscriptions/${SUB}/resourceGroups/${NE_RG}/providers/Microsoft.Network/applicationGatewayWebApplicationFirewallPolicies/WAF-HSBCPAPI"

echo "=== Importing Application Gateways ==="
terraform import azurerm_application_gateway.we_appgw \
  "/subscriptions/${SUB}/resourceGroups/${WE_RG}/providers/Microsoft.Network/applicationGateways/SI-DMZ-WE-APPGW-01"

terraform import azurerm_application_gateway.ne_appgw \
  "/subscriptions/${SUB}/resourceGroups/${NE_RG}/providers/Microsoft.Network/applicationGateways/SI-CIDMZ-NE-APPGW-51"

echo "=== Importing Private DNS Zone VNet Links ==="
terraform import azurerm_private_dns_zone_virtual_network_link.we_kv_dns_link \
  "/subscriptions/${SUB}/resourceGroups/${BASE_WE_RG}/providers/Microsoft.Network/privateDnsZones/${DNS_ZONE}/virtualNetworkLinks/we-cidmz-kv-dns-link"

terraform import azurerm_private_dns_zone_virtual_network_link.ne_kv_dns_link \
  "/subscriptions/${SUB}/resourceGroups/${BASE_WE_RG}/providers/Microsoft.Network/privateDnsZones/${DNS_ZONE}/virtualNetworkLinks/ne-cidmz-kv-dns-link"

echo "=== Importing Private Endpoints ==="
terraform import azurerm_private_endpoint.we_kv_pe \
  "/subscriptions/${SUB}/resourceGroups/${WE_RG}/providers/Microsoft.Network/privateEndpoints/SI-Core-Vault-WE-01-pe"

terraform import azurerm_private_endpoint.ne_kv_pe \
  "/subscriptions/${SUB}/resourceGroups/${NE_RG}/providers/Microsoft.Network/privateEndpoints/SI-Core-Vault-NE-51-pe"

echo "=== Importing Key Vault Access Policies ==="
terraform import azurerm_key_vault_access_policy.we_appgw_kv \
  "/subscriptions/${SUB}/resourceGroups/${WE_KV_RG}/providers/Microsoft.KeyVault/vaults/${WE_KV}/objectId/${WE_MI_OID}"

terraform import azurerm_key_vault_access_policy.ne_appgw_kv \
  "/subscriptions/${SUB}/resourceGroups/${NE_KV_RG}/providers/Microsoft.KeyVault/vaults/${NE_KV}/objectId/${NE_MI_OID}"

echo "=== Importing Diagnostic Settings ==="
terraform import azurerm_monitor_diagnostic_setting.we_appgw_diag \
  "/subscriptions/${SUB}/resourceGroups/${WE_RG}/providers/Microsoft.Network/applicationGateways/SI-DMZ-WE-APPGW-01/providers/microsoft.insights/diagnosticSettings/SI-DMZ-WE-APPGW-01-diag"

terraform import azurerm_monitor_diagnostic_setting.ne_appgw_diag \
  "/subscriptions/${SUB}/resourceGroups/${NE_RG}/providers/Microsoft.Network/applicationGateways/SI-CIDMZ-NE-APPGW-51/providers/microsoft.insights/diagnosticSettings/SI-CIDMZ-NE-APPGW-51-diag"

echo "=== All 16 resources imported. Run: terraform plan -var-file=certs.tfvars ==="
