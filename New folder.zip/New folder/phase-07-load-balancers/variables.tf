variable "environment" {
  type    = string
  default = "production"
}

variable "primary_subscription_id" {
  type      = string
  sensitive = true
}

variable "secondary_subscription_id" {
  type      = string
  sensitive = true
}

variable "we_resource_group_name" {
  type    = string
  default = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  type    = string
  default = "MIP-SI-NE-RG"
}

variable "lb_probe_interval" {
  type    = number
  default = 15
}

variable "lb_probe_threshold" {
  type    = number
  default = 2
}



