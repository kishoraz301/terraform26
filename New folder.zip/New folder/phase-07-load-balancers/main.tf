# Phase 07: Load Balancers (2 total: 1 per region, Internal, Standard)
# Deploy after Phase 03, 05: Subnets, Public IPs

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

data "azurerm_subnet" "we_cidmz_proxy_snet" {
  name                 = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
  virtual_network_name = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name  = data.azurerm_resource_group.we.name
}

data "azurerm_subnet" "ne_cidmz_proxy_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"
  virtual_network_name = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name  = data.azurerm_resource_group.ne.name
}

# ============================================================================
# WEST EUROPE - Load Balancer
# ============================================================================

resource "azurerm_lb" "we_cidmz_lb" {
  name                = "MIP-SI-WE-ciDMZ-LB"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "MIP-SI-WE-LB-frontend"
    subnet_id                     = data.azurerm_subnet.we_cidmz_proxy_snet.id
    private_ip_address            = "10.200.11.10"
    private_ip_address_allocation = "Static"
  }
}

resource "azurerm_lb_backend_address_pool" "we_proxy_pool" {
  loadbalancer_id = azurerm_lb.we_cidmz_lb.id
  name            = "MIP-SI-WE-Proxy-BackendPool"
}

resource "azurerm_lb_probe" "we_proxy_probe" {
  loadbalancer_id = azurerm_lb.we_cidmz_lb.id
  name            = "MIP-SI-WE-Proxy-Probe"
  port            = 3128
  protocol        = "Http"
  request_path    = "/"
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "we_proxy_rule" {
  loadbalancer_id                = azurerm_lb.we_cidmz_lb.id
  name                           = "MIP-SI-WE-Proxy-Rule"
  protocol                       = "Tcp"
  frontend_port                  = 3128
  backend_port                   = 3128
  frontend_ip_configuration_name = "MIP-SI-WE-LB-frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.we_proxy_pool.id]
  probe_id                       = azurerm_lb_probe.we_proxy_probe.id
  idle_timeout_in_minutes        = 4
}

# ============================================================================
# NORTH EUROPE - Load Balancer
# ============================================================================

resource "azurerm_lb" "ne_cidmz_lb" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-LB"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "MIP-SI-NE-LB-frontend"
    subnet_id                     = data.azurerm_subnet.ne_cidmz_proxy_snet.id
    private_ip_address            = "10.200.12.10"
    private_ip_address_allocation = "Static"
  }
}

resource "azurerm_lb_backend_address_pool" "ne_proxy_pool" {
  provider       = azurerm.secondary
  loadbalancer_id = azurerm_lb.ne_cidmz_lb.id
  name            = "MIP-SI-NE-Proxy-BackendPool"
}

resource "azurerm_lb_probe" "ne_proxy_probe" {
  provider       = azurerm.secondary
  loadbalancer_id = azurerm_lb.ne_cidmz_lb.id
  name            = "MIP-SI-NE-Proxy-Probe"
  port            = 3128
  protocol        = "Http"
  request_path    = "/"
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "ne_proxy_rule" {
  provider                       = azurerm.secondary
  loadbalancer_id                = azurerm_lb.ne_cidmz_lb.id
  name                           = "MIP-SI-NE-Proxy-Rule"
  protocol                       = "Tcp"
  frontend_port                  = 3128
  backend_port                   = 3128
  frontend_ip_configuration_name = "MIP-SI-NE-LB-frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.ne_proxy_pool.id]
  probe_id                       = azurerm_lb_probe.ne_proxy_probe.id
  idle_timeout_in_minutes        = 4
}

