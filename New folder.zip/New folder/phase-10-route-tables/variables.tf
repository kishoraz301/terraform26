variable "primary_subscription_id" {
  type      = string
  sensitive = true
}

variable "secondary_subscription_id" {
  type      = string
  sensitive = true
}

variable "we_resource_group_name" {
  type    = string
  default = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  type    = string
  default = "MIP-SI-NE-RG"
}

