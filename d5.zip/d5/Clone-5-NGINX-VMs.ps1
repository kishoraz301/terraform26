<#
.SYNOPSIS
    Clone 5 NGINX source VMs to production targets using snapshot approach
    
.DESCRIPTION
    This script clones exactly 5 NGINX VMs from production source RGs to target RGs
    Based on tested POC Clone-VM-From-Snapshot.ps1 pattern
    
.PARAMETER SubscriptionId
    Azure subscription ID
    
.EXAMPLE
    .\Clone-5-NGINX-VMs.ps1 -SubscriptionId "b3179146-e675-480d-aa38-23ec90529400"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId
)

Set-AzContext -SubscriptionId $SubscriptionId | Out-Null

# VM Configuration - 5 NGINX VMs only
$vmCloneConfig = @(
    @{
        SourceVMName = "SI-RPRXY-VM-54"
        TargetVMName = "SI-RPRXY-VM-59"
        SourceResourceGroup = "si-rprxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.4"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-55"
        TargetVMName = "SI-RPRXY-VM-60"
        SourceResourceGroup = "si-rprxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.5"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-05"
        TargetVMName = "SI-RPRXY-VM-10"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.4"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-06"
        TargetVMName = "SI-RPRXY-VM-11"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.5"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-04"
        TargetVMName = "SI-RPRXY-VM-09"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.8"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    }
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $output = "[$timestamp] [$Level] $Message"
    
    switch ($Level) {
        "SUCCESS" { Write-Host $output -ForegroundColor Green }
        "ERROR" { Write-Host $output -ForegroundColor Red }
        "WARNING" { Write-Host $output -ForegroundColor Yellow }
        default { Write-Host $output -ForegroundColor Cyan }
    }
}

function New-VMSnapshot {
    param([string]$SnapshotName, [string]$SourceDiskId, [string]$TargetResourceGroup, [string]$Location, [string]$SourceVMName)
    
    try {
        Write-Log "Creating snapshot: $SnapshotName"
        
        # Clean up existing snapshot if it exists
        $existingSnapshot = Get-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction SilentlyContinue
        if ($existingSnapshot) {
            Write-Log "Removing existing snapshot: $SnapshotName" "WARNING"
            Remove-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 3
        }
        
        $snapshotConfig = New-AzSnapshotConfig -SourceResourceId $SourceDiskId -Location $Location -CreateOption Copy
        $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction Stop
        Write-Log "Snapshot created successfully: $($snapshot.Id)" "SUCCESS"
        return $snapshot
    }
    catch {
        Write-Log "Error creating snapshot: $_" "ERROR"
        throw
    }
}

function New-VMDiskFromSnapshot {
    param([string]$DiskName, [string]$SnapshotId, [string]$TargetResourceGroup, [string]$Location, [string]$DiskType)
    
    try {
        Write-Log "Creating managed disk from snapshot: $DiskName"
        $diskConfig = New-AzDiskConfig -SourceResourceId $SnapshotId -Location $Location -CreateOption Copy -SkuName $DiskType
        $disk = New-AzDisk -Disk $diskConfig -ResourceGroupName $TargetResourceGroup -DiskName $DiskName -ErrorAction Stop
        Write-Log "Disk created successfully: $($disk.Id)" "SUCCESS"
        
        # Verify disk is propagated
        Write-Log "Verifying disk is available..."
        $maxRetries = 15
        $retryCount = 0
        $diskFound = $false
        
        while ($retryCount -lt $maxRetries -and -not $diskFound) {
            Start-Sleep -Seconds 2
            $verifyDisk = Get-AzDisk -Name $DiskName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($verifyDisk) {
                $diskFound = $true
                Write-Log "Disk verified and available" "SUCCESS"
            }
            $retryCount++
        }
        
        if (-not $diskFound) {
            Write-Log "Disk verification timeout after $maxRetries attempts" "WARNING"
        }
        
        return $disk
    }
    catch {
        Write-Log "Error creating disk from snapshot: $_" "ERROR"
        throw
    }
}

function New-VMNetworkInterface {
    param([string]$NICName, [string]$TargetVNetName, [string]$TargetSubnetName, [string]$TargetResourceGroup, [string]$VNetResourceGroup, [string]$SourceResourceGroup, [string]$PrivateIP)
    
    try {
        Write-Log "Creating network interface: $NICName"
        
        $vnet = Get-AzVirtualNetwork -Name $TargetVNetName -ResourceGroupName $VNetResourceGroup -ErrorAction Stop
        $subnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $TargetSubnetName -ErrorAction Stop
        
        $nicConfig = New-AzNetworkInterfaceIpConfig -Name "ipconfig1" -PrivateIpAddress $PrivateIP -Subnet $subnet -Primary
        $nic = New-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -Location $vnet.Location -IpConfiguration $nicConfig -ErrorAction Stop
        
        Write-Log "Network interface created successfully: $($nic.Id)" "SUCCESS"
        
        # Verify NIC is available
        Write-Log "Verifying network interface is available..."
        $maxRetries = 10
        $retryCount = 0
        $nicFound = $false
        
        while ($retryCount -lt $maxRetries -and -not $nicFound) {
            Start-Sleep -Seconds 1
            $verifyNIC = Get-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($verifyNIC) {
                $nicFound = $true
                Write-Log "Network interface verified and available" "SUCCESS"
            }
            $retryCount++
        }
        
        if (-not $nicFound) {
            Write-Log "NIC verification timeout after $maxRetries attempts" "WARNING"
        }
        
        return $nic
    }
    catch {
        Write-Log "Error creating network interface: $_" "ERROR"
        throw
    }
}

function New-ClonedVM {
    param([string]$VMName, [string]$DiskId, [string]$NICId, [string]$TargetResourceGroup, [string]$Location, [string]$VMSize, [string]$OSType, $Plan = $null)
    
    try {
        Write-Log "Creating VM: $VMName (Size: $VMSize, OS: $OSType)"
        
        $vmConfig = New-AzVMConfig -VMName $VMName -VMSize $VMSize
        
        # Apply plan information if present (for marketplace images)
        if ($Plan) {
            Write-Log "Applying marketplace plan: Publisher=$($Plan.Publisher), Product=$($Plan.Product), Name=$($Plan.Name)"
            $vmConfig = Set-AzVMPlan -VM $vmConfig -Publisher $Plan.Publisher -Product $Plan.Product -Name $Plan.Name
        }
        
        $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $DiskId -CreateOption Attach
        
        if ($OSType -eq "Linux") {
            $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $DiskId -CreateOption Attach -Linux
        } else {
            $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $DiskId -CreateOption Attach -Windows
        }
        
        $vmConfig = Add-AzVMNetworkInterface -VM $vmConfig -Id $NICId -Primary
        $vm = New-AzVM -ResourceGroupName $TargetResourceGroup -VM $vmConfig -Location $Location -ErrorAction Stop
        
        Write-Log "VM created successfully: $($vm.Id)" "SUCCESS"
        return $vm
    }
    catch {
        Write-Log "Error creating VM: $_" "ERROR"
        throw
    }
}

# Main execution
Write-Log "========================================" "INFO"
Write-Log "NGINX VM CLONING - 5 VMs" "INFO"
Write-Log "========================================" "INFO"

$successCount = 0
$failureCount = 0

foreach ($vm in $vmCloneConfig) {
    Write-Log "" "INFO"
    Write-Log "Cloning: $($vm.SourceVMName) -> $($vm.TargetVMName)" "INFO"
    Write-Log "Source RG: $($vm.SourceResourceGroup) | Target RG: $($vm.TargetResourceGroup)" "INFO"
    
    try {
        # Get source VM and disk
        Write-Log "Getting source VM info..."
        $sourceVM = Get-AzVM -Name $vm.SourceVMName -ResourceGroupName $vm.SourceResourceGroup -ErrorAction Stop
        $osDiskId = $sourceVM.StorageProfile.OsDisk.ManagedDisk.Id
        $osType = $sourceVM.StorageProfile.OsDisk.OsType
        $vmSize = $sourceVM.HardwareProfile.VmSize
        
        # Extract and validate plan (only Publisher, Product, Name)
        $sourcePlan = $null
        if ($sourceVM.Plan -and $sourceVM.Plan.Publisher -and $sourceVM.Plan.Product -and $sourceVM.Plan.Name) {
            $sourcePlan = @{
                Publisher = $sourceVM.Plan.Publisher
                Product = $sourceVM.Plan.Product
                Name = $sourceVM.Plan.Name
            }
            Write-Log "Source VM has marketplace plan: Publisher=$($sourcePlan.Publisher), Product=$($sourcePlan.Product), Name=$($sourcePlan.Name)" "INFO"
        }
        
        Write-Log "Source VM size: $vmSize, OS: $osType" "SUCCESS"
        
        # Create snapshot
        $snapshotName = "$($vm.TargetVMName)-snap"
        $snapshot = New-VMSnapshot -SnapshotName $snapshotName -SourceDiskId $osDiskId -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -SourceVMName $vm.SourceVMName
        
        # Create disk from snapshot
        $diskName = "$($vm.TargetVMName)-osdisk"
        $disk = New-VMDiskFromSnapshot -DiskName $diskName -SnapshotId $snapshot.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -DiskType $vm.DiskType
        
        # Create NIC
        $nicName = "$($vm.TargetVMName)-nic"
        $nic = New-VMNetworkInterface -NICName $nicName -TargetVNetName $vm.TargetVNetName -TargetSubnetName $vm.TargetSubnetName -TargetResourceGroup $vm.TargetResourceGroup -VNetResourceGroup $vm.VNetResourceGroup -SourceResourceGroup $vm.SourceResourceGroup -PrivateIP $vm.TargetPrivateIP
        
        # Create VM (pass plan info if available)
        $clonedVM = New-ClonedVM -VMName $vm.TargetVMName -DiskId $disk.Id -NICId $nic.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -VMSize $vmSize -OSType $osType -Plan $sourcePlan
        
        Write-Log "SUCCESS: $($vm.TargetVMName) cloned successfully" "SUCCESS"
        $successCount++
    }
    catch {
        Write-Log "FAILED: $($vm.TargetVMName) - $_" "ERROR"
        $failureCount++
    }
}

Write-Log "" "INFO"
Write-Log "========================================" "INFO"
Write-Log "EXECUTION COMPLETE" "INFO"
Write-Log "Successfully cloned: $successCount" "SUCCESS"
Write-Log "Failed: $failureCount" $(if ($failureCount -gt 0) { "ERROR" } else { "SUCCESS" })
Write-Log "========================================" "INFO"
