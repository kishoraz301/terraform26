# Azure Load Balancer Configuration - Phase 07

## Overview

This phase deploys **6 Internal Load Balancers (ILBs)** supporting a multi-region active-passive architecture for HSBC's Cloud Infrastructure DMZ:

- **West Europe (WE)** - Active region
- **North Europe (NE)** - Standby/Failover region

Each region has **3 ILBs**:
1. **Squid Proxy - Prod** (Port 3128)
2. **Squid Proxy - Non-Prod** (Port 3128)  
3. **RDS Web Servers** (Port 80) - **CRITICAL**

---

## Load Balancer Architecture

### West Europe (WE) - Active Region

| Load Balancer | Frontend IP | Subnet | Backend Port | Backend Members | Purpose |
|---|---|---|---|---|---|
| **we_squid_prod_lb** | 10.200.11.10 | ciDMZ-Proxy-dmz-snet | 3128 | 10.200.11.35, 10.200.11.36 | Prod outbound HTTP proxy |
| **we_squid_nonprod_lb** | 10.200.11.30 | ciDMZ-Proxy-dmz-snet | 3128 | 10.200.11.43, 10.200.11.44 | Non-Prod outbound HTTP proxy |
| **we_rds_lb** | 10.200.11.80 | RDS-snet | 80 | 10.200.11.68, 10.200.11.69 | RD Web Access (CRITICAL) |

### North Europe (NE) - Standby Region

| Load Balancer | Frontend IP | Subnet | Backend Port | Backend Members | Purpose |
|---|---|---|---|---|---|
| **ne_squid_prod_lb** | 10.200.12.10 | ciDMZ-Proxy-dmz-snet | 3128 | 10.200.12.35, 10.200.12.36 | Prod outbound HTTP proxy |
| **ne_squid_nonprod_lb** | 10.200.12.30 | ciDMZ-Proxy-dmz-snet | 3128 | 10.200.12.43, 10.200.12.44 | Non-Prod outbound HTTP proxy |
| **ne_rds_lb** | 10.200.12.80 | RDS-snet | 80 | 10.200.12.68, 10.200.12.69 | RD Web Access (CRITICAL - Standby) |

---

## Critical Dependencies

### 1. RDS Web ILBs (10.200.11.80 & 10.200.12.80)
- **CRITICAL FOR FIREWALL RULES**
- Azure Premium Firewall DNAT rules point directly to these IPs
- **MUST NOT** be modified, deleted, or changed after Phase 12 deployment
- Used for inbound RDP access from external networks
- Must be preserved during all subsequent firewall policy updates

### 2. Squid Proxy ILBs (Prod & Non-Prod)
- Enable outbound internet access for workloads
- Prod and Non-Prod environments must have separate load balancers
- Can be scaled independently

### 3. Regional Failover
- WE ILBs are active during normal operation
- NE ILBs are standby with mirrored configuration
- Failover requires:
  1. Update routing tables (Phase 10) to point to NE subnets
  2. Update firewall policy DNAT rules to point to NE RDS ILP
  3. Update workload configurations to use NE Squid ILBs

---

## Configuration Parameters

### Health Probe Settings
```
Protocol:  HTTP
Interval:  15 seconds
Threshold: 2 consecutive failures = unhealthy
Path:      / (root HTTP GET)
```

### Load Balancer Settings
```
SKU:           Standard
Idle Timeout:  30 minutes
Zone Redundant: true (in applicable regions)
```

### Backend Addition
- Backend members are added **manually** via `azurerm_lb_backend_address_pool_address`
- Each backend member is a static IP address
- Supports both VMs and NIC based addressing

---

## Deployment Sequence

### Phase 07 Execution
```bash
cd phases/phase-07-load-balancers
terraform init
terraform plan
terraform apply
```

### Outputs Generated
```
we_squid_prod_lb_id          → Resource ID
we_squid_prod_lb_ip          → 10.200.11.10
we_squid_prod_backend_pool_id → Backend pool resource

we_squid_nonprod_lb_id       → Resource ID
we_squid_nonprod_lb_ip       → 10.200.11.30
we_squid_nonprod_backend_pool_id → Backend pool resource

we_rds_lb_id                 → Resource ID (CRITICAL)
we_rds_lb_ip                 → 10.200.11.80 (CRITICAL)
we_rds_backend_pool_id       → Backend pool resource (CRITICAL)

[Same for NE region with different IP addresses]
```

---

## Firewall Rule Dependencies

### Phase 12 - Firewall Policies (CRITICAL)

The RDS ILB IPs are used directly in Premium Firewall DNAT rules:

```
Inbound Rule Example:
Protocol:  TCP/443
Source:    External-Network
Destination IP: 10.200.11.80 (WE RDS ILB) or 10.200.12.80 (NE RDS ILB)
Action:    DNAT → Backend RD Web servers
```

**DO NOT** modify the RDS ILB frontend IPs after Phase 12 is complete!

---

## Post-Deployment Validation

### 1. Verify Load Balancers Created
```bash
az lb list -g MIP-SI-WE-RG --query "[].{name:name, frontendIP:frontendIpConfigurations[0].privateIpAddress}"
az lb list -g MIP-SI-NE-RG --query "[].{name:name, frontendIP:frontendIpConfigurations[0].privateIpAddress}"
```

### 2. Verify Backend Pools
```bash
az lb address-pool list -g MIP-SI-WE-RG --lb-name we_squid_prod_lb
az lb address-pool list -g MIP-SI-WE-RG --lb-name we_rds_lb
```

### 3. Verify Health Probes
```bash
az lb probe list -g MIP-SI-WE-RG --lb-name we_squid_prod_lb
```

### 4. Test Connectivity
```bash
# From a workload in each subnet, test LB connectivity
nslookup 10.200.11.10  # Squid Prod
nslookup 10.200.11.80  # RDS Web
```

---

## Network Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│ WEST EUROPE (WE) - Active Region                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ciDMZ VNet (10.200.0.0/16)                                      │
│  ├── Proxy DMZ Subnet (10.200.11.0/26)                          │
│  │   ├── we_squid_prod_lb (10.200.11.10) → Port 3128            │
│  │   ├─── Backend: 10.200.11.35, 10.200.11.36                  │
│  │   │                                                            │
│  │   └── we_squid_nonprod_lb (10.200.11.30) → Port 3128         │
│  │   └─── Backend: 10.200.11.43, 10.200.11.44                  │
│  │                                                                │
│  └── RDS Subnet (10.200.11.64/26)                               │
│      └── we_rds_lb (10.200.11.80) → Port 80 (CRITICAL)         │
│      └─── Backend: 10.200.11.68, 10.200.11.69                  │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ NORTH EUROPE (NE) - Standby Region                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ciDMZ VNet (10.200.0.0/16)                                      │
│  ├── Proxy DMZ Subnet (10.200.12.0/26)                          │
│  │   ├── ne_squid_prod_lb (10.200.12.10) → Port 3128            │
│  │   ├─── Backend: 10.200.12.35, 10.200.12.36                  │
│  │   │                                                            │
│  │   └── ne_squid_nonprod_lb (10.200.12.30) → Port 3128         │
│  │   └─── Backend: 10.200.12.43, 10.200.12.44                  │
│  │                                                                │
│  └── RDS Subnet (10.200.12.64/26)                               │
│      └── ne_rds_lb (10.200.12.80) → Port 80 (CRITICAL)         │
│      └─── Backend: 10.200.12.68, 10.200.12.69                  │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Key Security Considerations

1. **ILBs are internal only** - No public IP addresses exposed
2. **Network security via NSGs** - Firewall rules limit traffic to specific sources
3. **Health probe security** - Uses HTTP on port 3128/80 internally
4. **Backend pool isolation** - Each LB has dedicated backend servers
5. **Regional redundancy** - Active-Passive prevents single region failure

---

## Troubleshooting

### LB Creation Fails
- Check subnet exists and is correct
- Verify IP address is not already assigned
- Check NSG allows inbound on probe port
- Verify Log Analytics workspace exists

### Backend Members Show Unhealthy
- Check backend member IP is correct
- Verify backend member can respond to health probe
- Check NSG allows inbound probe traffic
- Verify application is listening on backend port

### Connectivity Issues
- Verify routing to LB subnet exists
- Check NSG rules allow traffic to LB IP
- Verify backend members are in correct availability set
- Test with tracert/traceroute from source to LB IP

---

## Related Phases

- **Phase 03-Subnets:** Creates proxy and RDS subnets
- **Phase 04-NSGs:** Creates security group rules for LB traffic
- **Phase 10-Route-Tables:** Routes traffic to correct LB subnet  
- **Phase 12-Firewall-Policies:** Uses RDS LB IPs for DNAT rules
- **Phase 13:** Final validation and go-live

---

## Change Log

| Date | Version | Change |
|---|---|---|
| 2026-04-14 | 1.0 | Initial deployment with 6 ILBs (2 regions, 3 per region) |
| | | Added Squid Non-Prod and RDS Web ILB support |
| | | Updated documentation for critical RDS ILB dependencies |
