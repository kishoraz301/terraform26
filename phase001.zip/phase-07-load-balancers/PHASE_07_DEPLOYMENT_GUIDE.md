# Phase 07 - Load Balancer Deployment Guide (Azure Cloud Shell)

## 📋 Pre-Deployment Checklist

Before you start, confirm:
- [ ] You have access to Azure Cloud Shell
- [ ] You are logged in to the correct Azure subscription
- [ ] The workspace files are accessible from Cloud Shell
- [ ] You have terraform state files from previous phases

---

## 🚀 Step-by-Step Deployment

### STEP 1: Delete Existing Load Balancers (One-Time)

**Why:** The old 2 LBs are at IPs 10.200.11.10 and 10.200.12.10. New Phase 07 will try to create ILBs at the same IPs. We must delete old ones first.

#### Option A: Using Azure CLI (Recommended)

```powershell
# Delete WE Load Balancer
az lb delete --resource-group MIP-SI-WE-RG --name MIP-SI-WE-ciDMZ-LB --yes

# Delete NE Load Balancer
az lb delete --resource-group MIP-SI-NE-RG --name MIP-SI-NE-ciDMZ-LB --yes
```

**Expected Output:**
```
(no output = success)
```

**Time:** ~2-5 minutes each

#### Option B: Azure Portal (If CLI fails)
1. Go to Azure Portal → Resource Groups
2. Select `MIP-SI-WE-RG` → Load Balancers
3. Click `MIP-SI-WE-ciDMZ-LB` → Delete
4. Repeat for NE region

---

### STEP 2: Verify Old LBs Are Deleted

```powershell
# List all LBs in WE (should show 0)
az lb list -g MIP-SI-WE-RG -o table

# List all LBs in NE (should show 0)
az lb list -g MIP-SI-NE-RG -o table
```

**Expected Output:**
```
(empty table = success)
```

---

### STEP 3: Navigate to Phase 07 Directory

```powershell
# Change to Phase 07 folder
cd /home/yourname/KM/2026/HSBC/Terraform/landing-zone/phases/phase-07-load-balancers

# OR if different path:
cd c:\KM\2026\HSBC\Terraform\landing-zone\phases\phase-07-load-balancers

# Verify you're in the right place
pwd
# Should show: .../phase-07-load-balancers
```

---

### STEP 4: Verify Files Exist

```powershell
# List all files in Phase 07
ls

# You should see:
# main.tf
# variables.tf
# terraform.tfvars
# outputs.tf
# terraform.tfstate (optional - may not exist yet)
```

---

### STEP 5: Terraform Init (First Time Only)

```powershell
# Initialize Terraform
terraform init

# Expected output:
# Terraform has been successfully configured for this backend
# ...
# Terraform has initialized successfully
```

**If you see errors:**
```
Error: Failed to download module...
```
→ Run `terraform init` again (network hiccup)

---

### STEP 6: Review Terraform Plan

```powershell
# Generate plan (shows what will be created)
terraform plan -out=tfplan

# Expected output shows 6 new resources:
# + azurerm_lb.we_squid_prod_lb
# + azurerm_lb.we_squid_nonprod_lb
# + azurerm_lb.we_rds_lb
# + azurerm_lb.ne_squid_prod_lb
# + azurerm_lb.ne_squid_nonprod_lb
# + azurerm_lb.ne_rds_lb
# + 6 backend address pools
# + 6 health probes
# + 6 load balancing rules
# Plan: 30 to add, 0 to change, 0 to destroy
```

**Review the plan carefully:**
- [ ] 6 ILBs to be created? ✓
- [ ] Correct regions (WE & NE)? ✓
- [ ] Backend pools created? ✓
- [ ] Health probes configured? ✓
- [ ] Correct IP addresses? ✓

**If something looks wrong:**
```powershell
# Cancel and check variables
terraform plan -destroy
# OR
terraform show tfplan
```

---

### STEP 7: Apply Configuration (DEPLOY!)

```powershell
# Apply the plan
terraform apply tfplan

# Expected output (takes 5-10 minutes):
# Applying configuration...
# azurerm_lb.we_squid_prod_lb: Creating...
# azurerm_lb.we_squid_nonprod_lb: Creating...
# azurerm_lb.we_rds_lb: Creating...
# [... more resources ...]
# Apply complete! Resources: 30 added, 0 changed, 0 destroyed.
```

**Wait for completion.** ☕ Take a break - this takes ~5-10 minutes.

---

### STEP 8: Capture Outputs

```powershell
# Get all outputs
terraform output

# Expected output shows 6 ILB IPs:
# all_ilb_ips = {
#   "ne_rds" = "10.200.12.80"
#   "ne_squid_nonprod" = "10.200.12.30"
#   "ne_squid_prod" = "10.200.12.10"
#   "we_rds" = "10.200.11.80"
#   "we_squid_nonprod" = "10.200.11.30"
#   "we_squid_prod" = "10.200.11.10"
# }
# we_rds_lb_ip = "10.200.11.80"
# we_rds_lb_id = "/subscriptions/.../resourceGroups/MIP-SI-WE-RG/providers/Microsoft.Network/loadBalancers/we_rds_lb"
# ... (more outputs)
```

### **CRITICAL - Save These IPs:**

```
✅ SAVE THESE FOR PHASE 12:

WE RDS ILB IP:  10.200.11.80  ← LOCKED after Phase 12
NE RDS ILB IP:  10.200.12.80  ← LOCKED after Phase 12

WE Squid Prod:   10.200.11.10
WE Squid Non-Prod: 10.200.11.30

NE Squid Prod:   10.200.12.10
NE Squid Non-Prod: 10.200.12.30
```

---

### STEP 9: Save Outputs to File

```powershell
# Export outputs to JSON file
terraform output -json > outputs.json

# Save to a text file for reference
terraform output > outputs.txt

# Download to your local machine (if needed)
# In Cloud Shell: Download the outputs.json file via portal
```

---

### STEP 10: Verify in Azure Portal

```powershell
# List all ILBs created
az lb list -g MIP-SI-WE-RG -o table

# Should show 3 new ILBs:
# NAME                    RESOURCE_GROUP    LOCATION
# we_squid_prod_lb        MIP-SI-WE-RG      westeurope
# we_squid_nonprod_lb     MIP-SI-WE-RG      westeurope
# we_rds_lb               MIP-SI-WE-RG      westeurope
```

```powershell
# List NE ILBs
az lb list -g MIP-SI-NE-RG -o table

# Should show 3 new ILBs:
# NAME                    RESOURCE_GROUP    LOCATION
# ne_squid_prod_lb        MIP-SI-NE-RG      northeurope
# ne_squid_nonprod_lb     MIP-SI-NE-RG      northeurope
# ne_rds_lb               MIP-SI-NE-RG      northeurope
```

---

### STEP 11: Verify Load Balancer IPs

```powershell
# Check WE Squid Prod LB details
az lb show -g MIP-SI-WE-RG -n we_squid_prod_lb --query "{name:name, frontendIP:frontendIpConfigurations[0].privateIpAddress, provisioningState:provisioningState}"

# Expected output:
# {
#   "frontendIP": "10.200.11.10",
#   "name": "we_squid_prod_lb",
#   "provisioningState": "Succeeded"
# }
```

```powershell
# Check WE RDS LB details
az lb show -g MIP-SI-WE-RG -n we_rds_lb --query "{name:name, frontendIP:frontendIpConfigurations[0].privateIpAddress, provisioningState:provisioningState}"

# Expected output:
# {
#   "frontendIP": "10.200.11.80",
#   "name": "we_rds_lb",
#   "provisioningState": "Succeeded"
# }
```

---

### STEP 12: Verify Terraform State

```powershell
# Verify state file is saved
ls -la terraform.tfstate

# Show state summary
terraform state list

# Should show 30 resources:
# azurerm_lb.we_squid_prod_lb
# azurerm_lb_backend_address_pool.we_squid_prod_pool
# azurerm_lb_probe.we_squid_prod_probe
# azurerm_lb_rule.we_squid_prod_rule
# [... 26 more resources ...]
```

---

## ✅ Deployment Success Checklist

Mark these off as you complete each step:

- [ ] **Step 1:** Old LBs deleted
- [ ] **Step 2:** Verified empty (no old LBs showing)
- [ ] **Step 3:** In Phase 07 directory
- [ ] **Step 4:** Files exist (main.tf, variables.tf, etc.)
- [ ] **Step 5:** Terraform initialized
- [ ] **Step 6:** Plan reviewed (30 resources)
- [ ] **Step 7:** Apply completed successfully
- [ ] **Step 8:** Outputs captured
- [ ] **Step 9:** Outputs saved to file
- [ ] **Step 10:** Portal shows 6 ILBs created
- [ ] **Step 11:** IPs verified (10.200.11.x and 10.200.12.x)
- [ ] **Step 12:** State file saved

---

## 🔴 If Something Goes Wrong

### Error: "IP address already in use"

```
Error: creating Load Balancer: 
  The private IP address (10.200.11.10) is already in use
```

**Solution:**
```powershell
# Check which resource owns the IP
az network nic ip-config list -g MIP-SI-WE-RG --query "[].{ip:privateIpAddress, nic:id}"

# Delete the blocking resource or try Step 1 again
```

---

### Error: "Backend pool member not found"

```
Error: creating Load Balancer backend pool member:
  The backend member IP is not in the correct subnet
```

**This is NORMAL** - Backend members haven't been created yet. This will be added in Phase 08/09.

---

### Error: "Terraform init failed"

```
Error: Failed to download module registry.terraform.io/...
```

**Solution:**
```powershell
# Retry (network issue)
terraform init

# OR if persistent:
terraform init -upgrade
```

---

### Error: "Subscription not authenticated"

```
Error: Cannot renew token: subscription...
```

**Solution:**
```powershell
# Re-authenticate to Azure
az login

# Verify subscription
az account show

# Set subscription if needed
az account set --subscription "SUBSCRIPTION_ID"
```

---

## ⏭️ Next Steps (After Phase 07 Succeeds)

1. ✅ **Share outputs** with your team
   - Capture the 6 ILB IPs
   - Share especially RDS ILB IPs (10.200.11.80 & 10.200.12.80) with Phase 12 team

2. ✅ **Update Phase 12 Planning**
   - Send RDS ILB IPs to architect for DNAT rule configuration
   - Phase 12 firewall rules will use these IPs

3. ✅ **Document completion**
   - Mark Phase 07 as deployed
   - Prepare for Phase 08 (App Gateways) - waiting on architect clarifications

4. ✅ **Send IPs to Architect**
   - RDS ILB IPs MUST go to architect's Phase 12 checklist
   - This unblocks Phase 12 deployment timing

---

## 📞 Need Help?

If you encounter errors during deployment:

1. **Copy the error message**
2. **Run:** `terraform show tfplan` (to see details)
3. **Check:** `terraform state list` (to verify what was created)
4. **Contact:** Infrastructure team with error details

---

## Document Control

- **Created:** 2026-04-15
- **Phase:** 07 - Load Balancers
- **Environment:** Azure Cloud Shell
- **User:** DevOps Team
- **Status:** Ready to Deploy

