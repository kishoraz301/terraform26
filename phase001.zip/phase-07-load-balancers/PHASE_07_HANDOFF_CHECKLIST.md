# Phase 07 → Phase 12 Handoff Verification Checklist

## Pre-Deployment Checklist (Before Phase 07)

- [ ] All source IP addresses are correct (backend member IPs)
- [ ] Subnet IDs are verified for both regions
- [ ] Log Analytics workspace exists in both regions
- [ ] Resource groups exist: MIP-SI-WE-RG and MIP-SI-NE-RG
- [ ] Virtual networks exist with correct CIDR blocks
- [ ] NSGs exist and have been reviewed in Phase 04
- [ ] Team consensus on failover IP strategy documented

## Phase 07 Deployment Verification

### Load Balancer Creation
- [ ] **WE Squid Prod LB** (10.200.11.10) created in MIP-SI-WE-RG
- [ ] **WE Squid Non-Prod LB** (10.200.11.30) created in MIP-SI-WE-RG
- [ ] **WE RDS Web LB** (10.200.11.80) created in MIP-SI-WE-RG ⭐ CRITICAL
- [ ] **NE Squid Prod LB** (10.200.12.10) created in MIP-SI-NE-RG
- [ ] **NE Squid Non-Prod LB** (10.200.12.30) created in MIP-SI-NE-RG
- [ ] **NE RDS Web LB** (10.200.12.80) created in MIP-SI-NE-RG ⭐ CRITICAL

### Backend Pool Configuration
- [ ] Each LB has 1 backend address pool created
- [ ] WE Squid Prod pool ready for 2 backend members (10.200.11.35, 10.200.11.36)
- [ ] WE Squid Non-Prod pool ready for 2 backend members (10.200.11.43, 10.200.11.44)
- [ ] WE RDS pool ready for 2 backend members (10.200.11.68, 10.200.11.69) ⭐ CRITICAL
- [ ] [Same for NE region]

### Health Probe Configuration
- [ ] All 6 LBs have HTTP health probes configured
- [ ] Probe protocol: HTTP (port 3128 for Squid, port 80 for RDS)
- [ ] Probe interval: 15 seconds
- [ ] Unhealthy threshold: 2 consecutive failures
- [ ] Probe path: "/" (root path)

### Load Balancing Rules
- [ ] Squid Prod LBs: TCP port 3128 enabled
- [ ] Squid Non-Prod LBs: TCP port 3128 enabled
- [ ] RDS Web LBs: TCP port 80 enabled ⭐ CRITICAL
- [ ] Floating IP disabled (not required for Squid/RDS)
- [ ] TCP reset on idle enabled (for connection cleanup)
- [ ] Idle timeout: 30 minutes

### Terraform Outputs Captured
```
Capture these outputs for Phase 10, Phase 12, and handoff documentation:

West Europe (WE):
- we_squid_prod_lb_id:           [Resource ID captured]
- we_squid_prod_lb_ip:           10.200.11.10 [verified]
- we_squid_prod_backend_pool_id: [Resource ID captured]

- we_squid_nonprod_lb_id:           [Resource ID captured]
- we_squid_nonprod_lb_ip:           10.200.11.30 [verified]
- we_squid_nonprod_backend_pool_id: [Resource ID captured]

- we_rds_lb_id:           [Resource ID captured] ⭐ CRITICAL
- we_rds_lb_ip:           10.200.11.80 [verified] ⭐ CRITICAL
- we_rds_backend_pool_id: [Resource ID captured] ⭐ CRITICAL

North Europe (NE):
- ne_squid_prod_lb_id:           [Resource ID captured]
- ne_squid_prod_lb_ip:           10.200.12.10 [verified]
- ne_squid_prod_backend_pool_id: [Resource ID captured]

- ne_squid_nonprod_lb_id:           [Resource ID captured]
- ne_squid_nonprod_lb_ip:           10.200.12.30 [verified]
- ne_squid_nonprod_backend_pool_id: [Resource ID captured]

- ne_rds_lb_id:           [Resource ID captured] ⭐ CRITICAL
- ne_rds_lb_ip:           10.200.12.80 [verified] ⭐ CRITICAL
- ne_rds_backend_pool_id: [Resource ID captured] ⭐ CRITICAL
```

## Network Connectivity Validation

### From CI_DMZ Network (Test VM in Proxy subnet)
```powershell
# Verify WE Squid Prod LB connectivity
Test-NetConnection -ComputerName 10.200.11.10 -Port 3128 -InformationLevel Quiet
# Expected: True

# Verify WE RDS Web LB connectivity
Test-NetConnection -ComputerName 10.200.11.80 -Port 80 -InformationLevel Quiet
# Expected: True
```

### From Non-Prod Network
```powershell
# Verify WE Squid Non-Prod LB connectivity
nslookup 10.200.11.30
# Expected: No immediate resolution (IP is private), but connection should work

# Test with HTTP
Invoke-WebRequest -Uri "http://10.200.11.30:3128" -TimeoutSec 5
# Expected: Connection or timeout (depends on backend health)
```

### Optional: Curl from Linux/WSL
```bash
# Test Squid Prod
curl -v http://10.200.11.10:3128 --max-time 5
# Expected: Connection or timeout

# Test RDS Web
curl -v http://10.200.11.80 --max-time 5
# Expected: Connection or HTTP response
```

## NSG Validation (Phase 04 Integration)

- [ ] NSG allows inbound TCP 3128 from proxy subnet (for health probe)
- [ ] NSG allows inbound TCP 80 from RDS subnet (for health probe)
- [ ] NSG allows inbound TCP 3128 from workload subnets to Squid Prod LB
- [ ] NSG allows inbound TCP 3128 from workload subnets to Squid Non-Prod LB
- [ ] NSG allows inbound TCP 80/443 to RDS Web LB from external FW ⭐ CRITICAL
- [ ] Outbound rules allow backend members to respond to health probes

## Firewall Rule Integration (Phase 12 Preparation)

### Critical for Phase 12 - RDS Web ILB DNAT Rules

These ILB IPs **MUST** be used in Premium Firewall DNAT rules:
- [ ] **Document Required:** WE RDS Web ILB IP: **10.200.11.80** 
- [ ] **Document Required:** NE RDS Web ILB IP: **10.200.12.80**
- [ ] **Lock Required:** These IPs cannot change after Phase 12 is complete
- [ ] **Verify Required:** Phase 12 firewall policy uses these exact IPs

### Phase 12 Firewall Policy Review
```
The following DNAT rules will use these ILB IPs:

1. External RDP Access Rule (CRITICAL)
   - Inbound Destination IP: 10.200.11.80 (or 10.200.12.80 for NE)
   - Destination Port: 443 (HTTPS frontend)
   - Translate To: RDS Web ILB
   - Translate Port: 80 (HTTP backend)
   - Purpose: Route external RDP requests to RDS Web Access servers

2. Application Access Rules (if applicable)
   - May also use RDS ILB depending on architecture
```

**⚠️ CRITICAL: These IPs must not be changed after Phase 12!**

## Post-Deployment Lock and Handoff

### Lock Phase 07 State File
- [ ] Phase 07 terraform.tfstate is backed up
- [ ] terraform.tfstate.backup exists and is verified
- [ ] Phase 07 is marked as "complete and locked"
- [ ] No further manual changes to ILBs allowed

### Phase 10 (Route Tables) Handoff
Phase 10 will configure route tables to direct traffic through these LBs:
- [ ] Routes will point to proxy subnet (containing Squid LBs)
- [ ] Routes will point to RDS subnet (containing RDS Web LBs)
- [ ] Phase 10 team has reviewed all 6 LB IPs
- [ ] Documentation captured in Phase 10 notes

### Phase 12 (Firewall Policies) Handoff - **CRITICAL**
Phase 12 will implement firewall rules using RDS Web ILB IPs:
- [ ] Phase 12 team has captured RDS Web ILB IPs: 10.200.11.80 & 10.200.12.80
- [ ] Phase 12 has documented DNAT rule dependencies on these IPs
- [ ] Phase 12 team understands IPs cannot change post-deployment
- [ ] Escalation path documented if RDS ILB needs modification

### Phase 13 (Final Validation) Handoff
- [ ] All 6 ILBs show as "Provisioning Succeeded" in Azure Portal
- [ ] All 6 backend pools show no backend members (yet)
- [ ] All 6 health probes show as "Healthy" (waiting for backends)
- [ ] Terraform plan shows 0 changes required (stable state)

## Risk Assessment and Mitigation

| Risk | Mitigation |
|-----|-----------|
| RDS ILB IP changed by accident | Lock resource with Azure Policy; document in wiki; add change control process |
| Backend members not added before Phase 12 | Add pre-check in Phase 08/09 to verify backends exist |
| Health probes failing due to NSG | Phase 04 review and early validation in Phase 07 post-deployment |
| Regional failover not tested | Add Phase 13 failover test procedure; document runbook |
| Firewall rules incorrect | Phase 12 must execute firewall rule deployment in order; add validation step |

## Sign-Off

### Phase 07 Team
- [ ] Deployment completed successfully
- [ ] All outputs captured and documented
- [ ] No errors or warnings in terraform output
- [ ] Date: ________________
- [ ] Signed Off By: ________________

### Phase 10 Team (Route Tables)
- [ ] Received and reviewed Phase 07 handoff
- [ ] Confirmed all 6 LB IPs and subnets
- [ ] Route table configuration ready
- [ ] Date: ________________
- [ ] Signed Off By: ________________

### Phase 12 Team (Firewall Policies) ⭐ CRITICAL
- [ ] Received and reviewed RDS Web ILB IPs (10.200.11.80 & 10.200.12.80)
- [ ] Understood IPs are locked and cannot change
- [ ] DNAT rules configured with correct IPs
- [ ] Firewall policy tested in non-prod first
- [ ] Date: ________________
- [ ] Signed Off By: ________________

### Phase 13 Team (Final Validation)
- [ ] All phases reviewed
- [ ] Integration tests completed
- [ ] Validated RDS Web access works through ILB
- [ ] Documented any configuration deviations
- [ ] Date: ________________
- [ ] Signed Off By: ________________

---

## Appendix: Key Contacts

- **Phase 07 Owner (Load Balancers):** [Name/Team]
- **Phase 10 Owner (Route Tables):** [Name/Team]  
- **Phase 12 Owner (Firewall Policies):** [Name/Team] ⭐ CRITICAL
- **Phase 13 Owner (Validation):** [Name/Team]
- **Firewall SME:** [Name/Contact]
- **Network SME:** [Name/Contact]
- **Emergency Contact:** [Name/Contact]

