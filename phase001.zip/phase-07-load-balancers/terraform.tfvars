# ============================================================================
# LOAD BALANCERS - SQUID PROXY & RDS WEB SERVERS
# ============================================================================
# 6 Internal Load Balancers (ILBs) for multi-region active-passive design
#
# WEST EUROPE (WE):
#   - we_squid_prod_lb    (10.200.11.10)  - Prod Squid Proxies
#   - we_squid_nonprod_lb (10.200.11.30)  - Non-Prod Squid Proxies  
#   - we_rds_lb           (10.200.11.80)  - RDS Web Servers (CRITICAL - Premium FW DNAT)
#
# NORTH EUROPE (NE):
#   - ne_squid_prod_lb    (10.200.12.10)  - Prod Squid Proxies
#   - ne_squid_nonprod_lb (10.200.12.30)  - Non-Prod Squid Proxies
#   - ne_rds_lb           (10.200.12.80)  - RDS Web Servers (CRITICAL - Premium FW DNAT)

# ============================================================================
# AZURE SUBSCRIPTION AND REGION
# ============================================================================

primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"
environment               = "production"
primary_region            = "westeurope"
secondary_region          = "northeurope"

# Resource Group Names
we_resource_group_name = "MIP-SI-WE-RG"
ne_resource_group_name = "MIP-SI-NE-RG"

# ============================================================================
# SQUID PROXY CONFIGURATION
# ============================================================================

# WE - Prod Squid
we_squid_prod_frontend_ip      = "10.200.11.10"
we_squid_prod_backend_port     = 3128
we_squid_prod_health_probe_path = "/"

# WE - Non-Prod Squid (NEW)
we_squid_nonprod_frontend_ip      = "10.200.11.30"
we_squid_nonprod_backend_port     = 3128
we_squid_nonprod_health_probe_path = "/"

# NE - Prod Squid
ne_squid_prod_frontend_ip      = "10.200.12.10"
ne_squid_prod_backend_port     = 3128
ne_squid_prod_health_probe_path = "/"

# NE - Non-Prod Squid (NEW)
ne_squid_nonprod_frontend_ip      = "10.200.12.30"
ne_squid_nonprod_backend_port     = 3128
ne_squid_nonprod_health_probe_path = "/"

# ============================================================================
# RDS WEB CONFIGURATION (CRITICAL)
# ============================================================================
# These ILBs are CRITICAL - they must be preserved during firewall rules!
# Premium FW DNAT rules point directly to these IPs.

# WE - RDS Web (CRITICAL)
we_rds_frontend_ip      = "10.200.11.80"
we_rds_backend_port     = 80
we_rds_health_probe_path = "/"

# NE - RDS Web (CRITICAL - Standby)
ne_rds_frontend_ip      = "10.200.12.80"
ne_rds_backend_port     = 80
ne_rds_health_probe_path = "/"

# ============================================================================
# COMMON LOAD BALANCER SETTINGS
# ============================================================================

lb_sku                 = "Standard"
lb_idle_timeout        = 30
lb_probe_interval      = 15
lb_probe_threshold     = 2
health_probe_protocol  = "HTTP"

# ============================================================================
# LOG ANALYTICS RESOURCE GROUP (REQUIRED)
# ============================================================================

we_log_analytics_rg_name = "la-we-rg"
ne_log_analytics_rg_name = "la-we-rg"
