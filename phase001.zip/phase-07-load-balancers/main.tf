# Phase 07: Load Balancers - UPDATED for LLD 4.3.7
# 6 Total Load Balancers: 4 Squid (Prod + Non-Prod, WE + NE) + 2 RDS Web (WE + NE)
# Deploy after Phase 03 (IP Groups), Phase 05 (Subnets), Phase 06 (Firewalls)

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

# ============================================================================
# DATA SOURCES - Resource Groups & Subnets
# ============================================================================

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# West Europe Subnets
data "azurerm_subnet" "we_proxy_snet" {
  name                 = var.we_proxy_subnet_name
  virtual_network_name = var.we_vnet_name
  resource_group_name  = data.azurerm_resource_group.we.name
}

data "azurerm_subnet" "we_rds_snet" {
  name                 = var.we_rds_subnet_name
  virtual_network_name = var.we_vnet_name
  resource_group_name  = data.azurerm_resource_group.we.name
}

# West Europe Virtual Network
data "azurerm_virtual_network" "we_vnet" {
  name                = var.we_vnet_name
  resource_group_name = data.azurerm_resource_group.we.name
}

# North Europe Subnets
data "azurerm_subnet" "ne_proxy_snet" {
  provider             = azurerm.secondary
  name                 = var.ne_proxy_subnet_name
  virtual_network_name = var.ne_vnet_name
  resource_group_name  = data.azurerm_resource_group.ne.name
}

data "azurerm_subnet" "ne_rds_snet" {
  provider             = azurerm.secondary
  name                 = var.ne_rds_subnet_name
  virtual_network_name = var.ne_vnet_name
  resource_group_name  = data.azurerm_resource_group.ne.name
}

# North Europe Virtual Network
data "azurerm_virtual_network" "ne_vnet" {
  provider            = azurerm.secondary
  name                = var.ne_vnet_name
  resource_group_name = data.azurerm_resource_group.ne.name
}

# Log Analytics Workspace References
data "azurerm_log_analytics_workspace" "we_logs" {
  name                = var.we_log_analytics_workspace_name
  resource_group_name = var.we_log_analytics_rg_name
}

data "azurerm_log_analytics_workspace" "ne_logs" {
  provider            = azurerm.secondary
  name                = var.ne_log_analytics_workspace_name
  resource_group_name = var.ne_log_analytics_rg_name
}

# ============================================================================
# WEST EUROPE - SQUID PROXY ILBs
# ============================================================================

# ===== SQUID PROD (10.200.11.10) - UPDATED =====
resource "azurerm_lb" "we_squid_prod_lb" {
  name                = "SI-DMZ-WE-SQUID-PROD-LB-01"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "SI-DMZ-WE-SQUID-PROD-Frontend"
    subnet_id                     = data.azurerm_subnet.we_proxy_snet.id
    private_ip_address            = "10.200.11.10"
    private_ip_address_allocation = "Static"
  }

  tags = merge(
    var.common_tags,
    {
      Name        = "SI-DMZ-WE-SQUID-PROD-LB-01"
      Production  = "Yes"
      Role        = "Squid-Proxy"
      Environment = "Production"
    }
  )
}

resource "azurerm_lb_backend_address_pool" "we_squid_prod_pool" {
  loadbalancer_id = azurerm_lb.we_squid_prod_lb.id
  name            = "BackendPool-Squid-WE-Prod"
}

# Add backend members to pool
resource "azurerm_lb_backend_address_pool_address" "we_squid_prod_members" {
  count                   = length(var.we_squid_prod_backend_ips)
  backend_address_pool_id = azurerm_lb_backend_address_pool.we_squid_prod_pool.id
  name                    = "squid-prod-${count.index + 1}"
  ip_address              = var.we_squid_prod_backend_ips[count.index]
  virtual_network_id      = data.azurerm_virtual_network.we_vnet.id
}

resource "azurerm_lb_probe" "we_squid_prod_probe" {
  loadbalancer_id     = azurerm_lb.we_squid_prod_lb.id
  name                = "SI-CIDMZ-WE-SQUID-PROBE-01"
  port                = 3128
  protocol            = "Tcp"  # Changed from Http to Tcp per LLD
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "we_squid_prod_ha_ports" {
  loadbalancer_id                = azurerm_lb.we_squid_prod_lb.id
  name                           = "SI-CIDMZ-WE-SQUID-ILB-RULE-01"
  protocol                       = "All"  # HA Ports enabled
  frontend_port                  = 0
  backend_port                   = 0
  frontend_ip_configuration_name = "SI-DMZ-WE-SQUID-PROD-Frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.we_squid_prod_pool.id]
  probe_id                       = azurerm_lb_probe.we_squid_prod_probe.id
  load_distribution              = "SourceIP"
  idle_timeout_in_minutes        = 4
  enable_floating_ip             = true
}

resource "azurerm_monitor_diagnostic_setting" "we_squid_prod_diagnostics" {
  name               = "SI-DMZ-WE-SQUID-ILB-01-Diagnostics"
  target_resource_id = azurerm_lb.we_squid_prod_lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.we_logs.id

  enabled_log {
    category = "LoadBalancerAlertEvent"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# ===== SQUID NON-PROD (10.200.11.30) - NEW =====
resource "azurerm_lb" "we_squid_nonprod_lb" {
  name                = "SI-DMZ-WE-SQUID-NONPROD-LB-02"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "SI-DMZ-WE-SQUID-NONPROD-Frontend"
    subnet_id                     = data.azurerm_subnet.we_proxy_snet.id
    private_ip_address            = "10.200.11.30"
    private_ip_address_allocation = "Static"
  }

  tags = merge(
    var.common_tags,
    {
      Name        = "SI-DMZ-WE-SQUID-NONPROD-LB-02"
      Production  = "No"
      Role        = "Squid-Proxy"
      Environment = "Non-Production"
    }
  )
}

resource "azurerm_lb_backend_address_pool" "we_squid_nonprod_pool" {
  loadbalancer_id = azurerm_lb.we_squid_nonprod_lb.id
  name            = "BackendPool-Squid-WE-NonProd"
}

resource "azurerm_lb_backend_address_pool_address" "we_squid_nonprod_members" {
  count                   = length(var.we_squid_nonprod_backend_ips)
  backend_address_pool_id = azurerm_lb_backend_address_pool.we_squid_nonprod_pool.id
  name                    = "squid-nonprod-${count.index + 1}"
  ip_address              = var.we_squid_nonprod_backend_ips[count.index]
  virtual_network_id      = data.azurerm_virtual_network.we_vnet.id
}

resource "azurerm_lb_probe" "we_squid_nonprod_probe" {
  loadbalancer_id     = azurerm_lb.we_squid_nonprod_lb.id
  name                = "SI-CIDMZ-WE-SQUID-PROBE-02"
  port                = 3128
  protocol            = "Tcp"
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "we_squid_nonprod_ha_ports" {
  loadbalancer_id                = azurerm_lb.we_squid_nonprod_lb.id
  name                           = "SI-CIDMZ-WE-SQUID-ILB-RULE-02"
  protocol                       = "All"  # HA Ports enabled
  frontend_port                  = 0
  backend_port                   = 0
  frontend_ip_configuration_name = "SI-DMZ-WE-SQUID-NONPROD-Frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.we_squid_nonprod_pool.id]
  probe_id                       = azurerm_lb_probe.we_squid_nonprod_probe.id
  load_distribution              = "SourceIP"
  idle_timeout_in_minutes        = 4
  enable_floating_ip             = true
}

resource "azurerm_monitor_diagnostic_setting" "we_squid_nonprod_diagnostics" {
  name               = "SI-DMZ-WE-SQUID-ILB-02-Diagnostics"
  target_resource_id = azurerm_lb.we_squid_nonprod_lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.we_logs.id

  enabled_log {
    category = "LoadBalancerAlertEvent"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# ============================================================================
# WEST EUROPE - RDS WEB ILB
# ============================================================================

# ===== RDS WEB PROD (10.200.11.80) - NEW - CRITICAL =====
resource "azurerm_lb" "we_rds_lb" {
  name                = "SI-DMZ-WE-RDS-LB-01"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "SI-DMZ-WE-RDS-Frontend"
    subnet_id                     = data.azurerm_subnet.we_rds_snet.id
    private_ip_address            = "10.200.11.80"
    private_ip_address_allocation = "Static"
  }

  tags = merge(
    var.common_tags,
    {
      Name        = "SI-DMZ-WE-RDS-LB-01"
      Production  = "Yes"
      Role        = "RDS-Web"
      Environment = "Production"
      Critical    = "Yes"
    }
  )
}

resource "azurerm_lb_backend_address_pool" "we_rds_pool" {
  loadbalancer_id = azurerm_lb.we_rds_lb.id
  name            = "BackendPool-RDSWeb"
}

resource "azurerm_lb_backend_address_pool_address" "we_rds_members" {
  count                   = length(var.we_rds_backend_ips)
  backend_address_pool_id = azurerm_lb_backend_address_pool.we_rds_pool.id
  name                    = "rdsweb-${count.index + 1}"
  ip_address              = var.we_rds_backend_ips[count.index]
  virtual_network_id      = data.azurerm_virtual_network.we_vnet.id
}

resource "azurerm_lb_probe" "we_rds_probe" {
  loadbalancer_id     = azurerm_lb.we_rds_lb.id
  name                = "SI-DMZ-WE-RDS-PROBE-01"
  port                = 443
  protocol            = "Tcp"
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "we_rds_rule" {
  loadbalancer_id                = azurerm_lb.we_rds_lb.id
  name                           = "SI-DMZ-WE-RDS-ILB-RULE-01"
  protocol                       = "Tcp"
  frontend_port                  = 443
  backend_port                   = 443
  frontend_ip_configuration_name = "SI-DMZ-WE-RDS-Frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.we_rds_pool.id]
  probe_id                       = azurerm_lb_probe.we_rds_probe.id
  idle_timeout_in_minutes        = 4
  enable_floating_ip             = false
}

resource "azurerm_monitor_diagnostic_setting" "we_rds_diagnostics" {
  name               = "SI-DMZ-WE-RDS-ILB-01-Diagnostics"
  target_resource_id = azurerm_lb.we_rds_lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.we_logs.id

  enabled_log {
    category = "LoadBalancerAlertEvent"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# ============================================================================
# NORTH EUROPE - SQUID PROXY ILBs
# ============================================================================

# ===== SQUID PROD (10.200.12.10) - UPDATED =====
resource "azurerm_lb" "ne_squid_prod_lb" {
  provider            = azurerm.secondary
  name                = "SI-DMZ-NE-SQUID-PROD-LB-01"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "SI-DMZ-NE-SQUID-PROD-Frontend"
    subnet_id                     = data.azurerm_subnet.ne_proxy_snet.id
    private_ip_address            = "10.200.12.10"
    private_ip_address_allocation = "Static"
  }

  tags = merge(
    var.common_tags,
    {
      Name        = "SI-DMZ-NE-SQUID-PROD-LB-01"
      Production  = "Yes"
      Role        = "Squid-Proxy"
      Environment = "Production"
    }
  )
}

resource "azurerm_lb_backend_address_pool" "ne_squid_prod_pool" {
  provider       = azurerm.secondary
  loadbalancer_id = azurerm_lb.ne_squid_prod_lb.id
  name            = "BackendPool-Squid-NE-Prod"
}

resource "azurerm_lb_backend_address_pool_address" "ne_squid_prod_members" {
  provider                = azurerm.secondary
  count                   = length(var.ne_squid_prod_backend_ips)
  backend_address_pool_id = azurerm_lb_backend_address_pool.ne_squid_prod_pool.id
  name                    = "squid-prod-${count.index + 1}"
  ip_address              = var.ne_squid_prod_backend_ips[count.index]
  virtual_network_id      = data.azurerm_virtual_network.ne_vnet.id
}

resource "azurerm_lb_probe" "ne_squid_prod_probe" {
  provider            = azurerm.secondary
  loadbalancer_id     = azurerm_lb.ne_squid_prod_lb.id
  name                = "SI-CIDMZ-NE-SQUID-PROBE-01"
  port                = 3128
  protocol            = "Tcp"
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "ne_squid_prod_ha_ports" {
  provider                       = azurerm.secondary
  loadbalancer_id                = azurerm_lb.ne_squid_prod_lb.id
  name                           = "SI-CIDMZ-NE-SQUID-ILB-RULE-01"
  protocol                       = "All"  # HA Ports enabled
  frontend_port                  = 0
  backend_port                   = 0
  frontend_ip_configuration_name = "SI-DMZ-NE-SQUID-PROD-Frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.ne_squid_prod_pool.id]
  probe_id                       = azurerm_lb_probe.ne_squid_prod_probe.id
  load_distribution              = "SourceIP"
  idle_timeout_in_minutes        = 4
  enable_floating_ip             = true
}

resource "azurerm_monitor_diagnostic_setting" "ne_squid_prod_diagnostics" {
  provider           = azurerm.secondary
  name               = "SI-DMZ-NE-SQUID-ILB-01-Diagnostics"
  target_resource_id = azurerm_lb.ne_squid_prod_lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.ne_logs.id

  enabled_log {
    category = "LoadBalancerAlertEvent"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# ===== SQUID NON-PROD (10.200.12.30) - NEW =====
resource "azurerm_lb" "ne_squid_nonprod_lb" {
  provider            = azurerm.secondary
  name                = "SI-DMZ-NE-SQUID-NONPROD-LB-02"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "SI-DMZ-NE-SQUID-NONPROD-Frontend"
    subnet_id                     = data.azurerm_subnet.ne_proxy_snet.id
    private_ip_address            = "10.200.12.30"
    private_ip_address_allocation = "Static"
  }

  tags = merge(
    var.common_tags,
    {
      Name        = "SI-DMZ-NE-SQUID-NONPROD-LB-02"
      Production  = "No"
      Role        = "Squid-Proxy"
      Environment = "Non-Production"
    }
  )
}

resource "azurerm_lb_backend_address_pool" "ne_squid_nonprod_pool" {
  provider       = azurerm.secondary
  loadbalancer_id = azurerm_lb.ne_squid_nonprod_lb.id
  name            = "BackendPool-Squid-NE-NonProd"
}

resource "azurerm_lb_backend_address_pool_address" "ne_squid_nonprod_members" {
  provider                = azurerm.secondary
  count                   = length(var.ne_squid_nonprod_backend_ips)
  backend_address_pool_id = azurerm_lb_backend_address_pool.ne_squid_nonprod_pool.id
  name                    = "squid-nonprod-${count.index + 1}"
  ip_address              = var.ne_squid_nonprod_backend_ips[count.index]
  virtual_network_id      = data.azurerm_virtual_network.ne_vnet.id
}

resource "azurerm_lb_probe" "ne_squid_nonprod_probe" {
  provider            = azurerm.secondary
  loadbalancer_id     = azurerm_lb.ne_squid_nonprod_lb.id
  name                = "SI-CIDMZ-NE-SQUID-PROBE-02"
  port                = 3128
  protocol            = "Tcp"
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "ne_squid_nonprod_ha_ports" {
  provider                       = azurerm.secondary
  loadbalancer_id                = azurerm_lb.ne_squid_nonprod_lb.id
  name                           = "SI-CIDMZ-NE-SQUID-ILB-RULE-02"
  protocol                       = "All"  # HA Ports enabled
  frontend_port                  = 0
  backend_port                   = 0
  frontend_ip_configuration_name = "SI-DMZ-NE-SQUID-NONPROD-Frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.ne_squid_nonprod_pool.id]
  probe_id                       = azurerm_lb_probe.ne_squid_nonprod_probe.id
  load_distribution              = "SourceIP"
  idle_timeout_in_minutes        = 4
  enable_floating_ip             = true
}

resource "azurerm_monitor_diagnostic_setting" "ne_squid_nonprod_diagnostics" {
  provider           = azurerm.secondary
  name               = "SI-DMZ-NE-SQUID-ILB-02-Diagnostics"
  target_resource_id = azurerm_lb.ne_squid_nonprod_lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.ne_logs.id

  enabled_log {
    category = "LoadBalancerAlertEvent"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# ============================================================================
# NORTH EUROPE - RDS WEB ILB
# ============================================================================

# ===== RDS WEB STANDBY (10.200.12.80) - NEW - CRITICAL =====
resource "azurerm_lb" "ne_rds_lb" {
  provider            = azurerm.secondary
  name                = "SI-DMZ-NE-RDS-LB-51"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  sku                 = "Standard"
  sku_tier            = "Regional"

  frontend_ip_configuration {
    name                          = "SI-DMZ-NE-RDS-Frontend"
    subnet_id                     = data.azurerm_subnet.ne_rds_snet.id
    private_ip_address            = "10.200.12.80"
    private_ip_address_allocation = "Static"
  }

  tags = merge(
    var.common_tags,
    {
      Name        = "SI-DMZ-NE-RDS-LB-51"
      Production  = "Yes"
      Role        = "RDS-Web"
      Environment = "DR-Standby"
      Critical    = "Yes"
    }
  )
}

resource "azurerm_lb_backend_address_pool" "ne_rds_pool" {
  provider       = azurerm.secondary
  loadbalancer_id = azurerm_lb.ne_rds_lb.id
  name            = "BackendPool-RDSWeb"
}

resource "azurerm_lb_backend_address_pool_address" "ne_rds_members" {
  provider                = azurerm.secondary
  count                   = length(var.ne_rds_backend_ips)
  backend_address_pool_id = azurerm_lb_backend_address_pool.ne_rds_pool.id
  name                    = "rdsweb-${count.index + 1}"
  ip_address              = var.ne_rds_backend_ips[count.index]
  virtual_network_id      = data.azurerm_virtual_network.ne_vnet.id
}

resource "azurerm_lb_probe" "ne_rds_probe" {
  provider            = azurerm.secondary
  loadbalancer_id     = azurerm_lb.ne_rds_lb.id
  name                = "SI-DMZ-NE-RDS-PROBE-51"
  port                = 443
  protocol            = "Tcp"
  interval_in_seconds = var.lb_probe_interval
  number_of_probes    = var.lb_probe_threshold
}

resource "azurerm_lb_rule" "ne_rds_rule" {
  provider                       = azurerm.secondary
  loadbalancer_id                = azurerm_lb.ne_rds_lb.id
  name                           = "SI-DMZ-NE-RDS-ILB-RULE-51"
  protocol                       = "Tcp"
  frontend_port                  = 443
  backend_port                   = 443
  frontend_ip_configuration_name = "SI-DMZ-NE-RDS-Frontend"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.ne_rds_pool.id]
  probe_id                       = azurerm_lb_probe.ne_rds_probe.id
  idle_timeout_in_minutes        = 4
  enable_floating_ip             = false
}

resource "azurerm_monitor_diagnostic_setting" "ne_rds_diagnostics" {
  provider           = azurerm.secondary
  name               = "SI-DMZ-NE-RDS-ILB-51-Diagnostics"
  target_resource_id = azurerm_lb.ne_rds_lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.ne_logs.id

  enabled_log {
    category = "LoadBalancerAlertEvent"
  }

  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

