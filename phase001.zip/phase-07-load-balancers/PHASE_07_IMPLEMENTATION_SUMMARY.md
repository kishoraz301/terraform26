# Phase 07 Implementation Summary - 6 Internal Load Balancers

## Executive Summary

**Phase 07** has been completely redesigned to deploy **6 Internal Load Balancers (ILBs)** supporting HSBC's Cloud Infrastructure DMZ infrastructure across two Azure regions:

### Deployment Summary
✅ **6 ILBs Configured**
- West Europe (WE): 3 ILBs 
- North Europe (NE): 3 ILBs

✅ **Backend Services**
- Squid Proxy Prod (Port 3128)
- Squid Proxy Non-Prod (Port 3128)  ← **NEW**
- RDS Web Servers (Port 80)        ← **CRITICAL for Phase 12**

✅ **Multi-Region Design**
- Active-Passive architecture (WE active, NE standby)
- Isolated non-prod and prod environments
- High availability with regional failover

---

## What Changed in Phase 07

### Previous Implementation (OLD)
- Only 2 ILBs (1 per region)
- Basic proxy load balancing only
- No separation between prod/non-prod
- No explicit RDS Web support
- Limited documentation

### New Implementation (UPDATED)
- **6 ILBs** (3 per region)
- Separate Squid Prod + Non-Prod LBs
- Dedicated RDS Web LB (CRITICAL for FW integration)
- Comprehensive documentation
- Clear handoff to Phase 12

---

## The 6 Load Balancers

### West Europe (WE) - Active Region

#### 1. **we_squid_prod_lb** (10.200.11.10)
- **Location:** MIP-SI-WE-RG / Proxy DMZ Subnet
- **Purpose:** Load balance production Squid proxy servers
- **Backend Port:** 3128
- **Backend Members:** 10.200.11.35, 10.200.11.36
- **Health Probe:** HTTP GET / (15s interval)
- **Use Case:** Production workloads requiring internet access

#### 2. **we_squid_nonprod_lb** (10.200.11.30) ⭐ NEW
- **Location:** MIP-SI-WE-RG / Proxy DMZ Subnet
- **Purpose:** Load balance non-production Squid proxy servers
- **Backend Port:** 3128
- **Backend Members:** 10.200.11.43, 10.200.11.44
- **Health Probe:** HTTP GET / (15s interval)
- **Use Case:** Non-prod/dev workloads requiring internet access
- **Security Benefit:** Isolated from production traffic

#### 3. **we_rds_lb** (10.200.11.80) ⭐ CRITICAL
- **Location:** MIP-SI-WE-RG / RDS Subnet
- **Purpose:** Load balance RD Web Access servers (remote desktop)
- **Backend Port:** 80
- **Backend Members:** 10.200.11.68, 10.200.11.69
- **Health Probe:** HTTP GET / (15s interval)
- **Use Case:** External users accessing desktops via RD Web gateway
- **Critical Dependency:** Phase 12 firewall DNAT rules point to this IP
- **⚠️ WARNING:** IP cannot change after Phase 12 deployment

### North Europe (NE) - Standby Region

#### 4. **ne_squid_prod_lb** (10.200.12.10)
- Same configuration as WE Squid Prod
- Standby for failover scenarios
- Mirrored design for disaster recovery

#### 5. **ne_squid_nonprod_lb** (10.200.12.30) ⭐ NEW
- Same configuration as WE Squid Non-Prod
- Standby for failover scenarios
- Enables full environment continuity

#### 6. **ne_rds_lb** (10.200.12.80) ⭐ CRITICAL
- Same configuration as WE RDS Web
- Standby for failover scenarios
- Must match WE configuration exactly
- Also cannot change after Phase 12

---

## IP Address Assignment Strategy

### Squid Proxy Network (Proxy DMZ Subnet)

**West Europe (10.200.11.0/26):**
```
10.200.11.0     - Network address
10.200.11.1-9   - Firewall interface (if needed)
10.200.11.10    ← we_squid_prod_lb (ILB frontend)
10.200.11.20    - Reserved
10.200.11.30    ← we_squid_nonprod_lb (ILB frontend) [NEW]
10.200.11.35-36 ← Squid Prod VMs (backend members)
10.200.11.40    - Reserved
10.200.11.43-44 ← Squid Non-Prod VMs (backend members) [NEW]
10.200.11.50-63 - Available for future expansion
```

**North Europe (10.200.12.0/26):**
```
Same pattern with 10.200.12.x addresses
10.200.12.10    ← ne_squid_prod_lb
10.200.12.30    ← ne_squid_nonprod_lb [NEW]
10.200.12.35-36 ← Squid Prod VMs
10.200.12.43-44 ← Squid Non-Prod VMs [NEW]
```

### RDS Web Network (RDS Subnet)

**West Europe (10.200.11.64/26):**
```
10.200.11.64-79  - Reserved/Firewall
10.200.11.80     ← we_rds_lb (ILB frontend) [CRITICAL]
10.200.11.65-67  - Available
10.200.11.68-69  ← RDS Web VMs (backend members)
10.200.11.70-79  - Available
10.200.11.80-127 - Reserved
```

**North Europe (10.200.12.64/26):**
```
Same pattern with 10.200.12.x addresses
10.200.12.80     ← ne_rds_lb (ILB frontend) [CRITICAL]
10.200.12.68-69  ← RDS Web VMs (backend members)
```

---

## Key Design Decisions

### 1. Internal Load Balancers Only
- **Rationale:** All ILBs are private (no public IPs exposed)
- **Security:** Reduces attack surface, traffic stays within VNet
- **Regional:** Each region has independent ILBs for failover

### 2. Separate Prod & Non-Prod Squid LBs
- **Rationale:** Isolates production and non-production traffic
- **Security:** Non-prod issues don't impact production proxy access
- **Scalability:** Each environment can have different backend member counts
- **Cost:** Can be managed/scaled independently

### 3. Dedicated RDS Web LB
- **Rationale:** RD Web Access is critical for remote desktop access
- **Integration:** Phase 12 firewall rules point directly to this LB
- **Reliability:** Separate from Squid infrastructure
- **Security:** Enables fine-grained firewall rules for RDP access

### 4. Multi-Region Active-Passive
- **Rationale:** High availability with disaster recovery
- **Active:** West Europe (primary)
- **Passive:** North Europe (standby)
- **Failover:** Requires manual or automated DNS/routing change

### 5. Standard SKU Load Balancers
- **Rationale:** Sufficient for internal DMZ traffic
- **Zone-Redundant:** Provides availability zone redundancy
- **Cost Optimized:** Standard SKU is more cost-effective than Premium

---

## Terraform Implementation Details

### File Structure
```
phases/phase-07-load-balancers/
├── main.tf               ← ILB resource definitions (NEW - redesigned)
├── outputs.tf            ← Output values for handoff (UPDATED)
├── variables.tf          ← Input variables (UPDATED with new vars)
├── terraform.tfvars      ← Configuration values (UPDATED)
├── terraform.tfstate     ← State file (will be generated)
└── README.md             ← Existing documentation
```

### Key Variables Added

**Frontend IPs:**
```terraform
we_squid_prod_frontend_ip      = "10.200.11.10"
we_squid_nonprod_frontend_ip   = "10.200.11.30"   # NEW
we_rds_frontend_ip             = "10.200.11.80"
ne_squid_prod_frontend_ip      = "10.200.12.10"
ne_squid_nonprod_frontend_ip   = "10.200.12.30"   # NEW
ne_rds_frontend_ip             = "10.200.12.80"
```

**Backend Ports:**
```terraform
Squid (Prod & Non-Prod): Port 3128
RDS Web:                 Port 80
```

**Health Probe Configuration:**
```terraform
All LBs:
- Protocol: HTTP
- Path: /
- Interval: 15 seconds
- Threshold: 2 failures = unhealthy
```

### Outputs Generated

**For Phase 10 (Route Tables):**
- All 6 LB IDs and frontend IPs
- All 6 backend pool IDs
- Route table configuration can reference these outputs

**For Phase 12 (Firewall Policies):** ⭐ CRITICAL
- RDS Web ILB IPs: 10.200.11.80 & 10.200.12.80
- These IPs are used in firewall DNAT rules
- **Must not change after Phase 12**

---

## Phase Dependencies

### Phase 07 Requires (Inputs)
```
Phase 01 → Resource Groups (MIP-SI-WE-RG, MIP-SI-NE-RG)
Phase 02 → Virtual Networks (ciDMZ vnets)
Phase 03 → Subnets (Proxy DMZ, RDS subnets)
Phase 04 → NSGs (security rules for LB traffic)
```

### Phase 07 Provides (Outputs)
```
Phase 10 → Route Table targets (LB subnets)
Phase 12 → Firewall DNAT destinations (RDS Web ILBs) ⭐ CRITICAL
Phase 13 → Integration testing & validation
```

---

## Critical Constraints and Warnings

### ⚠️ CRITICAL: RDS Web ILB IPs Are Locked

**Once Phase 12 (Firewall Policies) is deployed:**
- The RDS Web ILB IPs **cannot be changed**
- These exact IPs are hardcoded in firewall DNAT rules
- Changing them requires:
  1. Phase 12 firewall policy redesign
  2. Coordination with security team
  3. Potential downtime for RD Web Access

**IPs that are locked after Phase 12:**
- West Europe: **10.200.11.80**
- North Europe: **10.200.12.80**

### ⚠️ IMPORTANT: Backend Members Not Yet Added

Phase 07 creates the ILBs and backend pools **but does not add backend members**.

Backend members (VMs) are added in **Phase 08** (or earlier):
- WE Squid Prod: 10.200.11.35, 10.200.11.36
- WE Squid Non-Prod: 10.200.11.43, 10.200.11.44
- WE RDS Web: 10.200.11.68, 10.200.11.69
- [Same IPs for North Europe with 10.200.12.x]

### ⚠️ Regional Failover Requires Routing Change

To fail over to North Europe:
1. Update DNS or application configuration to point to NE ILBs
2. Update Phase 10 route tables to point to NE subnets
3. Update Phase 12 firewall DNAT rules to point to NE RDS ILB (10.200.12.80)
4. Verify connectivity and health probes

---

## Deployment Instructions

### Step 1: Prerequisites
```bash
# Verify all prior phases are complete
terraform state list -state=../phase-01-resource-groups/terraform.tfstate
terraform state list -state=../phase-02-virtual-networks/terraform.tfstate
terraform state list -state=../phase-03-subnets/terraform.tfstate
terraform state list -state=../phase-04-network-security-groups/terraform.tfstate
```

### Step 2: Initialize Terraform
```bash
cd phases/phase-07-load-balancers
terraform init
```

### Step 3: Review Plan
```bash
terraform plan -out=tfplan
# Review all 6 ILB resources, backend pools, health probes, rules
```

### Step 4: Apply Configuration
```bash
terraform apply tfplan
# Wait for completion (5-10 minutes typical)
```

### Step 5: Capture Outputs
```bash
terraform output -json > outputs.json
# Save and document all ILB IPs and resource IDs
```

### Step 6: Validate Deployment
```bash
# Verify all 6 LBs exist in Azure
az lb list -g MIP-SI-WE-RG -o table
az lb list -g MIP-SI-NE-RG -o table

# Verify health probes are configured
az lb probe list -g MIP-SI-WE-RG --lb-name we_squid_prod_lb
```

---

## Validation Checklist

### After Deployment
- [ ] All 6 ILBs show "Provisioning Succeeded"
- [ ] All 6 backend pools created
- [ ] All 6 health probes configured
- [ ] All 6 load balancing rules active
- [ ] Terraform state file backed up
- [ ] Outputs documented for Phase 10 & 12

### Pre-Phase 10 Handoff
- [ ] Route table team has reviewed ILB IPs
- [ ] Route table team has confirmed subnets
- [ ] Documentation complete and shared

### Pre-Phase 12 Handoff ⭐ CRITICAL
- [ ] Firewall team has RDS Web ILB IPs: 10.200.11.80 & 10.200.12.80
- [ ] Firewall team understands these IPs are locked
- [ ] DNAT rule templates prepared with these IPs
- [ ] Fallback/rollback procedure documented

---

## Common Issues and Solutions

| Issue | Solution |
|-------|----------|
| ILB Creation Fails - Invalid Subnet | Verify subnet exists and is in correct vnet |
| ILB Creation Fails - IP Already in Use | Check if IP is assigned to NIC or other resource |
| Health Probes Show Unhealthy | Backends not added yet (normal pre-Phase 08). Will resolve when backends added. |
| Backend Pool Won't Accept Members | Verify backend member IP is in same vnet and has NIC in correct subnet |
| NSG Blocks Health Probes | Add inbound rule allowing probe port (3128/80) from subnet |

---

## Success Criteria

✅ **Phase 07 is successful when:**

1. All 6 ILBs created and showing in Azure Portal
2. All backend pools created (empty until Phase 08/09)
3. All health probes configured
4. All load balancing rules active
5. Terraform outputs captured and documented
6. No errors in terraform state
7. Phase 10 team received handoff with LB IPs
8. Phase 12 team received critical RDS ILB IPs (10.200.11.80 & 10.200.12.80)

---

## Timeline & Dependencies

```
Phase 01-04 (Completed)
    ↓
Phase 07 - Load Balancers (THIS PHASE)
    ├─→ Phase 08/09 - Compute Resources (need LB backend pools)
    ├─→ Phase 10 - Route Tables (need LB frontend IPs)
    ├─→ Phase 12 - Firewall Policies (CRITICAL: needs RDS ILB IPs) ⭐
    └─→ Phase 13 - Final Validation (tests all phases together)
```

---

## Reference Documentation

- **Load Balancer Configuration Guide:** [LOAD_BALANCER_CONFIGURATION_GUIDE.md](LOAD_BALANCER_CONFIGURATION_GUIDE.md)
- **Phase 07 Handoff Checklist:** [PHASE_07_HANDOFF_CHECKLIST.md](PHASE_07_HANDOFF_CHECKLIST.md)
- **main.tf:** Full Terraform resource definitions
- **variables.tf:** All configuration variables
- **outputs.tf:** All generated outputs
- **terraform.tfvars:** Configuration values

---

## Approval and Sign-Off

### Technical Review
- [ ] Architecture reviewed and approved
- [ ] IP addressing validated
- [ ] No conflicts with adjacent phases
- [ ] Reviewed by: ________________ Date: ________________

### Deployment Authorization
- [ ] Ready to deploy to production
- [ ] All prerequisites verified
- [ ] Rollback procedure documented
- [ ] Authorized by: ________________ Date: ________________

### Phase 12 Coordination ⭐ CRITICAL
- [ ] Firewall team notified of RDS ILB IPs (10.200.11.80 & 10.200.12.80)
- [ ] DNAT rule dependency documented
- [ ] Change control ticket created for Phase 12
- [ ] Coordination by: ________________ Date: ________________

---

## Version History

| Version | Date | Author | Change |
|---------|------|--------|--------|
| 1.0 | 2026-04-14 | DevOps Team | Initial 6-ILB design for Phase 07 |
| 1.1 | 2026-04-14 | DevOps Team | Added critical Phase 12 firewall integration notes |
| | | | Added non-prod Squid LB support |
| | | | Created comprehensive documentation |

