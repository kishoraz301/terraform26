# ============================================================================
# SQUID PROXY - WE PROD
# ============================================================================

output "we_squid_prod_lb_id" {
  value       = azurerm_lb.we_squid_prod_lb.id
  description = "WE Squid Prod ILB ID (10.200.11.10)"
}

output "we_squid_prod_lb_ip" {
  value       = azurerm_lb.we_squid_prod_lb.frontend_ip_configuration[0].private_ip_address
  description = "WE Squid Prod ILB Private IP"
}

output "we_squid_prod_backend_pool_id" {
  value       = azurerm_lb_backend_address_pool.we_squid_prod_pool.id
  description = "WE Squid Prod backend pool ID"
}

# ============================================================================
# SQUID PROXY - WE NON-PROD (NEW)
# ============================================================================

output "we_squid_nonprod_lb_id" {
  value       = azurerm_lb.we_squid_nonprod_lb.id
  description = "WE Squid Non-Prod ILB ID (10.200.11.30)"
}

output "we_squid_nonprod_lb_ip" {
  value       = azurerm_lb.we_squid_nonprod_lb.frontend_ip_configuration[0].private_ip_address
  description = "WE Squid Non-Prod ILB Private IP"
}

output "we_squid_nonprod_backend_pool_id" {
  value       = azurerm_lb_backend_address_pool.we_squid_nonprod_pool.id
  description = "WE Squid Non-Prod backend pool ID"
}

# ============================================================================
# RDS WEB - WE PROD (NEW - CRITICAL)
# ============================================================================

output "we_rds_lb_id" {
  value       = azurerm_lb.we_rds_lb.id
  description = "WE RDS Web ILB ID (10.200.11.80) - CRITICAL for Premium FW DNAT"
}

output "we_rds_lb_ip" {
  value       = azurerm_lb.we_rds_lb.frontend_ip_configuration[0].private_ip_address
  description = "WE RDS Web ILB Private IP"
}

output "we_rds_backend_pool_id" {
  value       = azurerm_lb_backend_address_pool.we_rds_pool.id
  description = "WE RDS Web backend pool ID"
}

# ============================================================================
# SQUID PROXY - NE PROD
# ============================================================================

output "ne_squid_prod_lb_id" {
  value       = azurerm_lb.ne_squid_prod_lb.id
  description = "NE Squid Prod ILB ID (10.200.12.10)"
}

output "ne_squid_prod_lb_ip" {
  value       = azurerm_lb.ne_squid_prod_lb.frontend_ip_configuration[0].private_ip_address
  description = "NE Squid Prod ILB Private IP"
}

output "ne_squid_prod_backend_pool_id" {
  value       = azurerm_lb_backend_address_pool.ne_squid_prod_pool.id
  description = "NE Squid Prod backend pool ID"
}

# ============================================================================
# SQUID PROXY - NE NON-PROD (NEW)
# ============================================================================

output "ne_squid_nonprod_lb_id" {
  value       = azurerm_lb.ne_squid_nonprod_lb.id
  description = "NE Squid Non-Prod ILB ID (10.200.12.30)"
}

output "ne_squid_nonprod_lb_ip" {
  value       = azurerm_lb.ne_squid_nonprod_lb.frontend_ip_configuration[0].private_ip_address
  description = "NE Squid Non-Prod ILB Private IP"
}

output "ne_squid_nonprod_backend_pool_id" {
  value       = azurerm_lb_backend_address_pool.ne_squid_nonprod_pool.id
  description = "NE Squid Non-Prod backend pool ID"
}

# ============================================================================
# RDS WEB - NE STANDBY (NEW - CRITICAL)
# ============================================================================

output "ne_rds_lb_id" {
  value       = azurerm_lb.ne_rds_lb.id
  description = "NE RDS Web ILB ID (10.200.12.80) - CRITICAL for Premium FW DNAT"
}

output "ne_rds_lb_ip" {
  value       = azurerm_lb.ne_rds_lb.frontend_ip_configuration[0].private_ip_address
  description = "NE RDS Web ILB Private IP"
}

output "ne_rds_backend_pool_id" {
  value       = azurerm_lb_backend_address_pool.ne_rds_pool.id
  description = "NE RDS Web backend pool ID"
}

# ============================================================================
# SUMMARY
# ============================================================================

output "all_ilb_ips" {
  value = {
    we_squid_prod    = azurerm_lb.we_squid_prod_lb.frontend_ip_configuration[0].private_ip_address
    we_squid_nonprod = azurerm_lb.we_squid_nonprod_lb.frontend_ip_configuration[0].private_ip_address
    we_rds           = azurerm_lb.we_rds_lb.frontend_ip_configuration[0].private_ip_address
    ne_squid_prod    = azurerm_lb.ne_squid_prod_lb.frontend_ip_configuration[0].private_ip_address
    ne_squid_nonprod = azurerm_lb.ne_squid_nonprod_lb.frontend_ip_configuration[0].private_ip_address
    ne_rds           = azurerm_lb.ne_rds_lb.frontend_ip_configuration[0].private_ip_address
  }
  description = "All 6 ILB frontend IPs"
}

