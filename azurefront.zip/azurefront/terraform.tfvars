subscription_id        = "9bde6346-5250-49f9-a010-3ac07609cb70"
resource_group_name    = "si-cedmz-we-01-rg"
frontdoor_profile_name = "SI-WEB-AFD-01"
frontdoor_sku          = "Premium_AzureFrontDoor"
waf_mode               = "Detection"

tags = {
  Environment = "Production"
  ManagedBy   = "Terraform"
  Phase       = "11b"
}
