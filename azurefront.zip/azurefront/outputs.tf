output "waf_adv_id" {
  description = "Resource ID of the WAFADV firewall policy"
  value       = azurerm_cdn_frontdoor_firewall_policy.waf_adv.id
}

output "waf_lms_id" {
  description = "Resource ID of the WAFLMS firewall policy"
  value       = azurerm_cdn_frontdoor_firewall_policy.waf_lms.id
}

output "waf_hsbcpapi_id" {
  description = "Resource ID of the WAFHSBCPAPI firewall policy"
  value       = azurerm_cdn_frontdoor_firewall_policy.waf_hsbcpapi.id
}

output "adv_security_policy_id" {
  description = "Resource ID of the ADV security policy association"
  value       = azurerm_cdn_frontdoor_security_policy.adv_security.id
}

output "lms_security_policy_id" {
  description = "Resource ID of the LMS security policy association"
  value       = azurerm_cdn_frontdoor_security_policy.lms_security.id
}

output "hsbcpapi_security_policy_id" {
  description = "Resource ID of the HSBCPAPI security policy association"
  value       = azurerm_cdn_frontdoor_security_policy.hsbcpapi_security.id
}
