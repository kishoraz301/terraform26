variable "subscription_id" {
  description = "Azure subscription ID"
  type        = string
  default     = "9bde6346-5250-49f9-a010-3ac07609cb70"
}

variable "resource_group_name" {
  description = "Resource group containing the AFD profile and WAF policies"
  type        = string
  default     = "si-cedmz-we-01-rg"
}

variable "frontdoor_profile_name" {
  description = "Name of the existing Azure Front Door profile"
  type        = string
  default     = "SI-WEB-AFD-01"
}

variable "frontdoor_sku" {
  description = "AFD SKU - must match the deployed profile SKU"
  type        = string
  default     = "Premium_AzureFrontDoor"
}

variable "waf_mode" {
  description = "WAF mode: Detection (Day-1) or Prevention (steady state)"
  type        = string
  default     = "Detection"
  validation {
    condition     = contains(["Detection", "Prevention"], var.waf_mode)
    error_message = "waf_mode must be Detection or Prevention."
  }
}

variable "tags" {
  description = "Resource tags"
  type        = map(string)
  default     = {}
}
