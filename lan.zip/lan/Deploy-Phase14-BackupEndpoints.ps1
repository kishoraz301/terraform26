# Deploy-Phase14-BackupEndpoints.ps1
# Creates Backup Private Endpoints, DNS Zones and VNet Links for WE and NE.
# Run from local PowerShell or Cloud Shell (PowerShell mode).
# Requires: Azure CLI (az) logged in with correct subscription access.

$SUB    = "9bde6346-5250-49f9-a010-3ac07609cb70"
$WE_RG  = "MIP-SI-WE-RG"
$NE_RG  = "MIP-SI-NE-RG"
$WE_OPS = "SI-OPS-WE-01-rg"
$NE_OPS = "SI-OPS-NE-01-rg"

az account set --subscription $SUB

# ── Private DNS Zones ──────────────────────────────────────────────────────
Write-Host "Creating WE DNS zone..." -ForegroundColor Cyan
az network private-dns zone create `
  --resource-group $WE_RG `
  --name "privatelink.westeurope.backup.windowsazure.com"

Write-Host "Creating NE DNS zone..." -ForegroundColor Cyan
az network private-dns zone create `
  --resource-group $NE_RG `
  --name "privatelink.northeurope.backup.windowsazure.com"

# ── VNet Links ─────────────────────────────────────────────────────────────
Write-Host "Linking WE VNet to DNS zone..." -ForegroundColor Cyan
az network private-dns link vnet create `
  --resource-group $WE_RG `
  --zone-name "privatelink.westeurope.backup.windowsazure.com" `
  --name "cidmz-we-backup-dns-link" `
  --virtual-network "MIP-SI-WE-ciDMZ-vnet" `
  --registration-enabled false

Write-Host "Linking NE VNet to DNS zone..." -ForegroundColor Cyan
az network private-dns link vnet create `
  --resource-group $NE_RG `
  --zone-name "privatelink.northeurope.backup.windowsazure.com" `
  --name "cidmz-ne-backup-dns-link" `
  --virtual-network "MIP-SI-NE-ciDMZ-vnet" `
  --registration-enabled false

# ── Lookup RSV Resource IDs ────────────────────────────────────────────────
Write-Host "Looking up Recovery Services Vault IDs..." -ForegroundColor Cyan
$WE_RSV_ID = az resource show `
  --resource-group "SI-OPS-WE-01-rg" `
  --resource-type "Microsoft.RecoveryServices/vaults" `
  --name "SI-Recovery-v2" `
  --query id -o tsv

$NE_RSV_ID = az resource show `
  --resource-group "SI-OPS-NE-01-rg" `
  --resource-type "Microsoft.RecoveryServices/vaults" `
  --name "SI-Recovery-NE-v2" `
  --query id -o tsv

# ── Private Endpoints ──────────────────────────────────────────────────────
Write-Host "Creating WE private endpoint..." -ForegroundColor Cyan
az network private-endpoint create `
  --resource-group $WE_OPS `
  --name "SI-PEP-WE-RSV" `
  --location westeurope `
  --vnet-name "MIP-SI-WE-ciDMZ-vnet" `
  --vnet-resource-group $WE_RG `
  --subnet "MIP-SI-WE-ciDMZ-Proxy-dmz-snet" `
  --private-connection-resource-id $WE_RSV_ID `
  --group-id AzureBackup `
  --connection-name "SI-PEP-WE-RSV-psc"

Write-Host "Attaching WE DNS zone group..." -ForegroundColor Cyan
az network private-endpoint dns-zone-group create `
  --resource-group $WE_OPS `
  --endpoint-name "SI-PEP-WE-RSV" `
  --name "backup-we-dns-group" `
  --private-dns-zone "/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/privateDnsZones/privatelink.westeurope.backup.windowsazure.com" `
  --zone-name "backup-we-dns-group"

Write-Host "Creating NE private endpoint..." -ForegroundColor Cyan
az network private-endpoint create `
  --resource-group $NE_OPS `
  --name "SI-PEP-NE-RSV" `
  --location northeurope `
  --vnet-name "MIP-SI-NE-ciDMZ-vnet" `
  --vnet-resource-group $NE_RG `
  --subnet "MIP-SI-NE-ciDMZ-Proxy-dmz-snet" `
  --private-connection-resource-id $NE_RSV_ID `
  --group-id AzureBackup `
  --connection-name "SI-PEP-NE-RSV-psc"

Write-Host "Attaching NE DNS zone group..." -ForegroundColor Cyan
az network private-endpoint dns-zone-group create `
  --resource-group $NE_OPS `
  --endpoint-name "SI-PEP-NE-RSV" `
  --name "backup-ne-dns-group" `
  --private-dns-zone "/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/privateDnsZones/privatelink.northeurope.backup.windowsazure.com" `
  --zone-name "backup-ne-dns-group"

Write-Host "`nDone - all 6 resources created." -ForegroundColor Green
