<#
.SYNOPSIS
    Clone 9 Proxy VMs with Marketplace Term Acceptance - FIXED VERSION
    
.DESCRIPTION
    Clones 9 Proxy VMs from production source RGs to target RGs.
    INCLUDES: Automatic marketplace term acceptance from source VM image
    
.PARAMETER SubscriptionId
    Azure subscription ID
    
.EXAMPLE
    .\Clone-9-Proxy-VMs-MARKETPLACE-FIXED.ps1 -SubscriptionId "b3179146-e675-480d-aa38-23ec90529400"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId
)

Set-AzContext -SubscriptionId $SubscriptionId | Out-Null

# VM Configuration - 9 Proxy VMs (4 NE + 5 WE)
$vmCloneConfig = @(
    @{
        SourceVMName = "SI-proxy-vm-51"
        TargetVMName = "si-proxy-vm-56"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.35"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-52"
        TargetVMName = "si-proxy-vm-57"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.36"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-53"
        TargetVMName = "si-proxy-vm-58"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.43"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-54"
        TargetVMName = "si-proxy-vm-59"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.44"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-01"
        TargetVMName = "si-proxy-vm-06"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.35"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-02"
        TargetVMName = "si-proxy-vm-07"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.36"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-03"
        TargetVMName = "si-proxy-vm-08"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.43"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-04"
        TargetVMName = "si-proxy-vm-09"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.44"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-05"
        TargetVMName = "si-proxy-vm-10"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.45"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    }
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $output = "[$timestamp] [$Level] $Message"
    
    switch ($Level) {
        "SUCCESS" { Write-Host $output -ForegroundColor Green }
        "ERROR" { Write-Host $output -ForegroundColor Red }
        "WARNING" { Write-Host $output -ForegroundColor Yellow }
        default { Write-Host $output -ForegroundColor Cyan }
    }
}

function Accept-MarketplaceTerms {
    param([string]$Publisher, [string]$Offer, [string]$Sku, [string]$SubscriptionId)
    
    try {
        Write-Log "Accepting marketplace terms for: Publisher=$Publisher, Offer=$Offer, Sku=$Sku" "INFO"
        
        $terms = Get-AzMarketplaceTerms -Publisher $Publisher -Product $Offer -Name $Sku -ErrorAction SilentlyContinue
        
        if ($null -eq $terms) {
            Write-Log "No marketplace terms found (image may not require acceptance)" "WARNING"
            return $true
        }
        
        if ($terms.Accepted) {
            Write-Log "✓ Marketplace terms already accepted" "SUCCESS"
            return $true
        }
        
        Write-Log "Accepting marketplace terms..." "INFO"
        Set-AzMarketplaceTerms -Publisher $Publisher -Product $Offer -Name $Sku -Accept -ErrorAction Stop | Out-Null
        Write-Log "✓ Marketplace terms accepted successfully" "SUCCESS"
        return $true
    }
    catch {
        Write-Log "Warning: Could not accept marketplace terms - $_" "WARNING"
        return $false
    }
}

function New-VMSnapshot {
    param([string]$SnapshotName, [string]$SourceDiskId, [string]$TargetResourceGroup, [string]$Location, [string]$SourceVMName)
    
    try {
        Write-Log "Creating snapshot: $SnapshotName"
        
        # Remove existing snapshot if present
        $existingSnapshot = Get-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction SilentlyContinue
        if ($existingSnapshot) {
            Write-Log "Removing existing snapshot: $SnapshotName" "WARNING"
            Remove-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 3
        }
        
        $snapshotConfig = New-AzSnapshotConfig -SourceResourceId $SourceDiskId -Location $Location -CreateOption Copy
        $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction Stop
        Write-Log "Snapshot created successfully" "SUCCESS"
        return $snapshot
    }
    catch {
        Write-Log "Error creating snapshot: $_" "ERROR"
        throw
    }
}

function New-VMDiskFromSnapshot {
    param([string]$DiskName, [string]$SnapshotId, [string]$TargetResourceGroup, [string]$Location, [string]$DiskType)
    
    try {
        Write-Log "Creating managed disk: $DiskName"
        
        $diskConfig = New-AzDiskConfig -SourceResourceId $SnapshotId -Location $Location -CreateOption Copy -SkuName $DiskType
        $disk = New-AzDisk -Disk $diskConfig -ResourceGroupName $TargetResourceGroup -DiskName $DiskName -ErrorAction Stop
        Write-Log "Managed disk created successfully" "SUCCESS"
        
        # Verify disk is available
        $maxRetries = 15
        $retryCount = 0
        while ($retryCount -lt $maxRetries) {
            $chk = Get-AzDisk -Name $DiskName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($chk) {
                Write-Log "Disk verified and available" "SUCCESS"
                return $disk
            }
            Start-Sleep -Seconds 2
            $retryCount++
        }
        
        Write-Log "Disk verification timeout" "WARNING"
        return $disk
    }
    catch {
        Write-Log "Error creating disk: $_" "ERROR"
        throw
    }
}

function New-VMNetworkInterface {
    param([string]$NICName, [string]$TargetVNetName, [string]$TargetSubnetName, [string]$TargetResourceGroup, [string]$VNetResourceGroup, [string]$PrivateIP, [string]$Location)
    
    try {
        Write-Log "Creating network interface: $NICName"
        
        $vnet = Get-AzVirtualNetwork -Name $TargetVNetName -ResourceGroupName $VNetResourceGroup -ErrorAction Stop
        $subnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $TargetSubnetName -ErrorAction Stop
        
        $nicConfig = New-AzNetworkInterfaceIpConfig -Name "ipconfig1" -PrivateIpAddress $PrivateIP -Subnet $subnet -Primary
        $nic = New-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -Location $Location -IpConfiguration $nicConfig -ErrorAction Stop
        Write-Log "Network interface created successfully" "SUCCESS"
        
        # Verify NIC is available
        $maxRetries = 10
        $retryCount = 0
        while ($retryCount -lt $maxRetries) {
            $chk = Get-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($chk) {
                Write-Log "Network interface verified" "SUCCESS"
                return $nic
            }
            Start-Sleep -Seconds 1
            $retryCount++
        }
        
        Write-Log "NIC verification timeout" "WARNING"
        return $nic
    }
    catch {
        Write-Log "Error creating NIC: $_" "ERROR"
        throw
    }
}

function New-ClonedVM {
    param([string]$VMName, [string]$DiskId, [string]$NICId, [string]$TargetResourceGroup, [string]$Location, [string]$VMSize, [string]$OSType, [string]$Publisher, [string]$Product, [string]$PlanName)
    
    try {
        Write-Log "Creating VM: $VMName (Size: $VMSize, OS: $OSType)" "INFO"
        
        $vmConfig = New-AzVMConfig -VMName $VMName -VMSize $VMSize
        
        # CRITICAL: Apply marketplace plan BEFORE disk attachment
        if ($Publisher -and $Product -and $PlanName) {
            Write-Log "Applying marketplace plan: Publisher=$Publisher, Product=$Product, Name=$PlanName" "INFO"
            $vmConfig = Set-AzVMPlan -VM $vmConfig -Publisher $Publisher -Product $Product -Name $PlanName -ErrorAction Stop
            Write-Log "✓ Marketplace plan applied" "SUCCESS"
        }
        
        # Attach OS disk
        if ($OSType -eq "Linux") {
            $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $DiskId -CreateOption Attach -Linux -ErrorAction Stop
        } else {
            $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $DiskId -CreateOption Attach -Windows -ErrorAction Stop
        }
        Write-Log "OS disk attached" "SUCCESS"
        
        # Attach NIC
        $vmConfig = Add-AzVMNetworkInterface -VM $vmConfig -Id $NICId -Primary -ErrorAction Stop
        Write-Log "Network interface attached" "SUCCESS"
        
        # Create VM
        Write-Log "Submitting VM creation to Azure..." "INFO"
        $vm = New-AzVM -ResourceGroupName $TargetResourceGroup -VM $vmConfig -Location $Location -ErrorAction Stop
        
        # Verify VM was created
        Start-Sleep -Seconds 3
        $createdVM = Get-AzVM -Name $VMName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
        if ($createdVM) {
            Write-Log "✓ VM created and verified in resource group" "SUCCESS"
            Write-Log "  Provisioning State: $($createdVM.ProvisioningState)" "INFO"
            return $vm
        } else {
            throw "VM creation returned success but VM not found in resource group"
        }
    }
    catch {
        Write-Log "Error creating VM: $_" "ERROR"
        throw
    }
}

# Main execution
Write-Log "═══════════════════════════════════════════════════════" "INFO"
Write-Log "           PROXY VM CLONING - 9 VMs" "INFO"
Write-Log "    WITH MARKETPLACE TERM ACCEPTANCE" "INFO"
Write-Log "═══════════════════════════════════════════════════════" "INFO"

$successCount = 0
$failureCount = 0
$termsAcceptedCount = 0

foreach ($vm in $vmCloneConfig) {
    Write-Log "" "INFO"
    Write-Log "───────────────────────────────────────────────────────" "INFO"
    Write-Log "Cloning: $($vm.SourceVMName) → $($vm.TargetVMName)" "INFO"
    Write-Log "───────────────────────────────────────────────────────" "INFO"
    
    try {
        # Get source VM info
        Write-Log "Retrieving source VM information..."
        $sourceVM = Get-AzVM -Name $vm.SourceVMName -ResourceGroupName $vm.SourceResourceGroup -ErrorAction Stop
        $osDiskId = $sourceVM.StorageProfile.OsDisk.ManagedDisk.Id
        $osType = $sourceVM.StorageProfile.OsDisk.OsType
        $vmSize = $sourceVM.HardwareProfile.VmSize
        
        Write-Log "Source VM: Size=$vmSize, OS=$osType" "SUCCESS"
        
        # Extract marketplace plan info
        $publisher = $null
        $product = $null
        $planName = $null
        if ($sourceVM.Plan) {
            $publisher = $sourceVM.Plan.Publisher
            $product = $sourceVM.Plan.Product
            $planName = $sourceVM.Plan.Name
            Write-Log "Marketplace Plan: Publisher=$publisher, Product=$product, Name=$planName" "INFO"
            
            # Accept marketplace terms
            $termsAccepted = Accept-MarketplaceTerms -Publisher $publisher -Offer $product -Sku $planName -SubscriptionId $SubscriptionId
            if ($termsAccepted) {
                $termsAcceptedCount++
            }
        }
        
        # Create snapshot
        $snapshotName = "$($vm.TargetVMName)-snap"
        $snapshot = New-VMSnapshot -SnapshotName $snapshotName -SourceDiskId $osDiskId -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -SourceVMName $vm.SourceVMName
        
        # Create disk from snapshot
        $diskName = "$($vm.TargetVMName)-osdisk"
        $disk = New-VMDiskFromSnapshot -DiskName $diskName -SnapshotId $snapshot.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -DiskType $vm.DiskType
        
        # Create NIC
        $nicName = "$($vm.TargetVMName)-nic"
        $nic = New-VMNetworkInterface -NICName $nicName -TargetVNetName $vm.TargetVNetName -TargetSubnetName $vm.TargetSubnetName -TargetResourceGroup $vm.TargetResourceGroup -VNetResourceGroup $vm.VNetResourceGroup -PrivateIP $vm.TargetPrivateIP -Location $vm.Location
        
        # Create VM
        $clonedVM = New-ClonedVM -VMName $vm.TargetVMName -DiskId $disk.Id -NICId $nic.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -VMSize $vmSize -OSType $osType -Publisher $publisher -Product $product -PlanName $planName
        
        Write-Log "✓ SUCCESS: $($vm.TargetVMName) cloned successfully" "SUCCESS"
        $successCount++
    }
    catch {
        Write-Log "✗ FAILED: $($vm.TargetVMName)" "ERROR"
        Write-Log "Error: $_" "ERROR"
        $failureCount++
    }
}

Write-Log "" "INFO"
Write-Log "═══════════════════════════════════════════════════════" "INFO"
Write-Log "                  EXECUTION COMPLETE" "INFO"
Write-Log "═══════════════════════════════════════════════════════" "INFO"
Write-Log "Successfully cloned: $successCount" "SUCCESS"
Write-Log "Failed: $failureCount" $(if ($failureCount -gt 0) { "ERROR" } else { "SUCCESS" })
Write-Log "Marketplace terms accepted: $termsAcceptedCount" "INFO"
Write-Log "═══════════════════════════════════════════════════════" "INFO"
