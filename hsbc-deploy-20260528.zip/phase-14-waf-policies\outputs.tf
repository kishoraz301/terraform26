﻿# Phase 14: Azure Backup Private Endpoints — Outputs

output "we_backup_pe_id" {
  description = "WE Azure Backup private endpoint resource ID."
  value       = azurerm_private_endpoint.we_backup_pe.id
}

output "we_backup_pe_ip" {
  description = "WE Azure Backup private endpoint private IP address."
  value       = azurerm_private_endpoint.we_backup_pe.private_service_connection[0].private_ip_address
}

output "ne_backup_pe_id" {
  description = "NE Azure Backup private endpoint resource ID."
  value       = azurerm_private_endpoint.ne_backup_pe.id
}

output "ne_backup_pe_ip" {
  description = "NE Azure Backup private endpoint private IP address."
  value       = azurerm_private_endpoint.ne_backup_pe.private_service_connection[0].private_ip_address
}

output "backup_dns_zone_we_id" {
  description = "Private DNS zone ID for WE Azure Backup."
  value       = azurerm_private_dns_zone.backup_we.id
}

output "backup_dns_zone_ne_id" {
  description = "Private DNS zone ID for NE Azure Backup."
  value       = azurerm_private_dns_zone.backup_ne.id
}