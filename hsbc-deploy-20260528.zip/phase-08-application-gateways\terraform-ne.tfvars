# ============================================================================
# Terraform Configuration - North Europe Application Gateway
# Multi-Listener Configuration with 9 HTTPS Listeners (One Per Certificate/Domain)
# ============================================================================
# File: terraform-ne.tfvars
# Region: North Europe (NE) - Standby/DR
# Created: May 8, 2026

# ============================================================================
# Subscription & Resource Group
# ============================================================================

secondary_subscription_id = "REPLACE_WITH_NE_SUBSCRIPTION_ID"
ne_resource_group_name    = "si-dmz-appgw-ne-01-rg"

# ============================================================================
# Application Gateway Configuration
# ============================================================================

appgw_autoscale_min = 2   # Minimum instances (same as WE for parity)
appgw_autoscale_max = 4   # Maximum instances for burst

waf_mode = "Detection"    # Use "Detection" for Day-1, switch to "Prevention" after tuning

# ============================================================================
# HTTPS Listeners Configuration (9 Listeners, Identical to WE for DR Parity)
# Each listener handles HTTPS traffic for a specific domain
# IMPORTANT: Certificate names must match WE (same KV cert imports)
# ============================================================================

appgw_listeners_config = {
  # Production Domains
  "notify-adv-result-ready" = {
    fqdn            = "NotifyAdvResultReady.intermediaries.hsbc.co.uk"
    certificate_name = "notify-adv-result-ready"    # Same cert name as WE
    priority        = 100
    environment     = "production"
    backend_pool    = "nginx-primary"
  }

  "ecot-get-property-details" = {
    fqdn            = "ecotgetpropertydetails.intermediaries.hsbc.co.uk"
    certificate_name = "ecot-get-property-details"
    priority        = 110
    environment     = "production"
    backend_pool    = "nginx-primary"
  }

  "ecot-notify-payment-sanction" = {
    fqdn            = "ecotnotifypaymentsanction.intermediaries.hsbc.co.uk"
    certificate_name = "ecot-notify-payment-sanction"
    priority        = 120
    environment     = "production"
    backend_pool    = "nginx-primary"
  }

  "send-valuer-update" = {
    fqdn            = "SendValuerUpdate.intermediaries.hsbc.co.uk"
    certificate_name = "send-valuer-update"
    priority        = 130
    environment     = "production"
    backend_pool    = "nginx-primary"
  }

  # SIT1 (System Integration Test 1) Domains
  "notify-adv-result-ready-sit1" = {
    fqdn            = "NotifyAdvResultReady.intermediaries-sit1.hsbc.co.uk"
    certificate_name = "notify-adv-result-ready-sit1"
    priority        = 140
    environment     = "sit1"
    backend_pool    = "nginx-primary"
  }

  "send-valuer-update-sit1" = {
    fqdn            = "SendValuerUpdate.intermediaries-sit1.hsbc.co.uk"
    certificate_name = "send-valuer-update-sit1"
    priority        = 150
    environment     = "sit1"
    backend_pool    = "nginx-primary"
  }

  # UAT (User Acceptance Testing) Domain
  "send-valuer-update-uat" = {
    fqdn            = "SendValuerUpdate.intermediaries-uat.hsbc.co.uk"
    certificate_name = "send-valuer-update-uat"
    priority        = 160
    environment     = "uat"
    backend_pool    = "nginx-primary"
  }

  # Dev/SIT1 Domains (Prefixed with 'dev')
  "dev-ecot-get-property-details-sit1" = {
    fqdn            = "devecotgetpropertydetails.intermediaries-sit1.hsbc.co.uk"
    certificate_name = "dev-ecot-get-property-details-sit1"
    priority        = 170
    environment     = "sit1"
    backend_pool    = "nginx-primary"
  }

  "dev-ecot-notify-payment-sanction-sit1" = {
    fqdn            = "devecotnotifypaymentsanction.intermediaries-sit1.hsbc.co.uk"
    certificate_name = "dev-ecot-notify-payment-sanction-sit1"
    priority        = 180
    environment     = "sit1"
    backend_pool    = "nginx-primary"
  }

  # Add 10th listener here if needed (must match WE for DR):
  # "listener-10-name" = {
  #   fqdn            = "your-10th-domain.intermediaries.hsbc.co.uk"
  #   certificate_name = "your-10th-cert-name"
  #   priority        = 190
  #   environment     = "production"
  #   backend_pool    = "nginx-primary"
  # }
}

# ============================================================================
# Backend Pool Configuration
# All 9 listeners route to the same backend pool (NGINX servers in NE)
# NE NGINX servers have different IPs than WE (10.200.12.x range)
# ============================================================================

backend_pools_config = {
  "nginx-primary" = {
    backend_ips = [
      "10.200.12.2",    # NGINX Server 1 (NE)
      "10.200.12.3"     # NGINX Server 2 (NE)
    ]
  }
}

# ============================================================================
# Health Probe Configuration
# Probes backend NGINX servers on HTTPS /health endpoint
# ============================================================================

health_probe_config = {
  protocol  = "Https"
  path      = "/health"
  port      = 443
  interval  = 30           # seconds
  timeout   = 10           # seconds
  unhealthy_threshold = 3  # failed probes before marking unhealthy
  healthy_threshold   = 2  # successful probes before marking healthy
}

# ============================================================================
# Backend HTTP Settings
# Configuration for AppGW → NGINX backend communication
# ============================================================================

backend_http_settings_config = {
  port              = 443
  protocol          = "Https"
  timeout           = 30            # seconds
  host_name         = "nginx.internal"  # SNI hostname for backend TLS
  pick_host_name    = false
  cookie_affinity   = "Disabled"
}

# ============================================================================
# Key Vault & Certificates
# NE Key Vault is separate from WE (regional isolation)
# Must import SAME certificate names as WE for consistency
# ============================================================================

key_vault_config = {
  name                = "SI-Core-Vault-NE-51"
  resource_group_name = "si-core-kv-ne-rg"
  location            = "northeurope"
}

# ============================================================================
# WAF (Web Application Firewall) Policy
# NE gets its own WAF policy (same rules as WE for consistency)
# ============================================================================

waf_policy_config = {
  name                = "SI-DMZ-WAFPLCY-51"      # Note: -51 suffix for NE
  resource_group_name = "si-dmz-appgw-ne-01-rg"
  location            = "northeurope"
  mode                = "Detection"  # "Detection" or "Prevention"
  owasp_crs_version   = "3.2"
}

# ============================================================================
# Logging & Diagnostics
# Send AppGW logs to Log Analytics (centralized to WE workspace or regional)
# ============================================================================

log_analytics_config = {
  workspace_name      = "LogA-WE"            # Centralized logging to WE workspace
  resource_group_name = "si-monitoring-rg"
  location            = "westeurope"          # Workspace is in WE region
}

# ============================================================================
# Network Configuration
# NE subnet IPs are in 10.200.12.x range (vs. WE's 10.200.11.x)
# ============================================================================

network_config = {
  vnet_name           = "MIP-SI-DMZ-NE-vnet"
  subnet_name         = "MIP-SI-NE-AppGW-snet"
  frontend_private_ip = "10.200.12.170"  # Static IP for AppGW frontend (NE range)
  resource_group_name = "si-dmz-ne-02-rg"
  location            = "northeurope"
}

# ============================================================================
# Application Gateway Naming & Tagging
# Use -51 suffix for NE (per HSBC naming convention for DR/standby)
# ============================================================================

appgw_name = "SI-CIDMZ-NE-APPGW-51"

common_tags = {
  Project        = "HSBC-MIP"
  Environment    = "Production-DR"           # Note: DR designation
  Component      = "DMZ-AppGateway"
  Region         = "NorthEurope"
  Owner          = "Cloud-Engineering"
  CostCenter     = "HSBC-TBD"
  ManagedBy      = "Terraform"
  DeploymentDate = "2026-05-08"
  DR-Parity      = "true"                    # Mark as DR region
}

# ============================================================================
# END terraform-ne.tfvars
# ============================================================================
