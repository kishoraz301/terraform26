﻿# Phase 14: Azure Backup Private Endpoints - Locals

locals {
  namespace    = "MIP-SI"
  project_code = "HSBC"
  environment  = var.environment

  default_tags = {
    Project     = local.project_code
    Environment = local.environment
    Namespace   = local.namespace
    ManagedBy   = "Terraform"
  }
}
