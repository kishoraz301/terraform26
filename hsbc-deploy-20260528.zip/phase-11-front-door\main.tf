﻿# Phase 11: Azure Front Door (SI-WEB-AFD-01) ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â LLD v1.2 aligned
# Profile: SI-WEB-AFD-01 | Premium SKU | Global ingress
# 2 Endpoints (WE active, NE standby) | 1 Origin Group | 3 WAF Policies | 12 custom domains
# Deploy after Phase 08: Application Gateways

terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.primary_subscription_id
  features {}
}

provider "azurerm" {
  alias           = "secondary"
  subscription_id = var.secondary_subscription_id
  features {}
}

# ============================================================================
# RESOURCE GROUPS
# ============================================================================

# si-cedmz-we-01-rg does not exist yet ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â created by this phase per LLD 4.3.8
resource "azurerm_resource_group" "afd_rg" {
  name     = var.afd_resource_group_name
  location = var.location
  tags     = var.tags
}

# ============================================================================
# DATA SOURCES
# ============================================================================

# AppGW PIPs are in MIP-SI-WE-RG / MIP-SI-NE-RG (created by phase-08)
data "azurerm_public_ip" "we_appgw_pip" {
  name                = "MIP-SI-WE-AppGW-frontend-pip"
  resource_group_name = var.we_appgw_resource_group_name
}

data "azurerm_public_ip" "ne_appgw_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-AppGW-frontend-pip"
  resource_group_name = var.ne_appgw_resource_group_name
}

data "azurerm_log_analytics_workspace" "loga_we" {
  name                = "LogA-WE"
  resource_group_name = "la-we-rg"
}

# ============================================================================
# AZURE FRONT DOOR PROFILE ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â LLD 4.3.8: SI-WEB-AFD-01, Premium
# ============================================================================

resource "azurerm_cdn_frontdoor_profile" "global_frontdoor" {
  name                = "SI-WEB-AFD-01"
  resource_group_name = azurerm_resource_group.afd_rg.name
  sku_name            = var.frontdoor_sku
  tags                = var.tags
}

# ============================================================================
# ENDPOINTS ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â LLD: WE (active) + NE (cold standby)
# ============================================================================

resource "azurerm_cdn_frontdoor_endpoint" "we_endpoint" {
  name                     = "SI-WEB-AFD-WE-EP-01"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  tags                     = var.tags
}

resource "azurerm_cdn_frontdoor_endpoint" "ne_endpoint" {
  name                     = "SI-WEB-AFD-NE-EP-01"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  tags                     = var.tags
}

# NOTE: Private Link AFD ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ AppGW was removed from LLD (amendment 15 May 2026).
# Origins connect via public IP of the AppGW frontend PIP.

# ============================================================================
# ORIGIN GROUP ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â LLD: SI-WEB-OG-01 | WE priority=1 active, NE priority=2 standby
# ============================================================================

resource "azurerm_cdn_frontdoor_origin_group" "app_origins" {
  name                     = "SI-WEB-OG-01"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  session_affinity_enabled = false

  load_balancing {
    sample_size                        = 4
    successful_samples_required        = 3
    additional_latency_in_milliseconds = 50
  }

  health_probe {
    interval_in_seconds = 30
    path                = "/healthz"
    protocol            = "Https"
    request_type        = "GET"
  }
}

resource "azurerm_cdn_frontdoor_origin" "we_origin" {
  name                           = "SI-DMZ-WE-APPGW-01"
  cdn_frontdoor_origin_group_id  = azurerm_cdn_frontdoor_origin_group.app_origins.id
  enabled                        = true
  host_name                      = data.azurerm_public_ip.we_appgw_pip.ip_address
  http_port                      = 80
  https_port                     = 443
  priority                       = 1
  weight                         = 500
  certificate_name_check_enabled = false # IP-address origin ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â hostname TLS check not applicable
}

resource "azurerm_cdn_frontdoor_origin" "ne_origin" {
  name                           = "SI-DMZ-NE-APPGW-51"
  cdn_frontdoor_origin_group_id  = azurerm_cdn_frontdoor_origin_group.app_origins.id
  enabled                        = true
  host_name                      = data.azurerm_public_ip.ne_appgw_pip.ip_address
  http_port                      = 80
  https_port                     = 443
  priority                       = 2
  weight                         = 500
  certificate_name_check_enabled = false # IP-address origin ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â hostname TLS check not applicable
}

# ============================================================================
# CUSTOM DOMAINS ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â LLD 4.3.8: 10 FQDNs, AFD-managed TLS certs (ManagedCertificate)
# TLS provisioning requires CNAME validation by HSBC DNS team before cert activates.
# ============================================================================

# --- WAF-ADV domains (NotifyAdvResultReady) ---
resource "azurerm_cdn_frontdoor_custom_domain" "notifyadvresultready_prod" {
  name                     = "notifyadvresultready-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "notifyadvresultready.intermediaries.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "notifyadvresultready_sit1" {
  name                     = "notifyadvresultready-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "notifyadvresultready.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "notifyadvresultready_st4_sit2" {
  name                     = "notifyadvresultready-st4-sit2"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "notifyadvresultready-st4.intermediaries-sit2.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

# --- WAF-LMS domains (SendValuerUpdate) ---
resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_prod" {
  name                     = "sendvaluerupdate-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_sit1" {
  name                     = "sendvaluerupdate-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_uat" {
  name                     = "sendvaluerupdate-uat"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries-uat.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

# --- WAF-HSBCPAPI domains (ECOT / devECOT) ---
resource "azurerm_cdn_frontdoor_custom_domain" "ecotgetpropertydetails_prod" {
  name                     = "ecotgetpropertydetails-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "ecotgetpropertydetails.intermediaries.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "ecotnotifypaymentsanction_prod" {
  name                     = "ecotnotifypaymentsanction-prod"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "ecotnotifypaymentsanction.intermediaries.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "devecotgetpropertydetails_sit1" {
  name                     = "devecotgetpropertydetails-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "devecotgetpropertydetails.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "devecotnotifypaymentsanction_sit1" {
  name                     = "devecotnotifypaymentsanction-sit1"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "devecotnotifypaymentsanction.intermediaries-sit1.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}


# --- WAF-LMS extra environments (SIT2, NFT) ---
resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_sit2" {
  name                     = "sendvaluerupdate-sit2"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries-sit2.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

resource "azurerm_cdn_frontdoor_custom_domain" "sendvaluerupdate_nft" {
  name                     = "sendvaluerupdate-nft"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  host_name                = "sendvaluerupdate.intermediaries-nft.hsbc.co.uk"
  tls {
    certificate_type = "ManagedCertificate"
  }
}

# ============================================================================
# ROUTE ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â LLD: SI-WEB-RT-HTTPS-01 | HTTPS only | All 12 custom domains ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ WE endpoint
# ============================================================================

resource "azurerm_cdn_frontdoor_route" "https_route" {
  name                          = "SI-WEB-RT-HTTPS-01"
  cdn_frontdoor_endpoint_id     = azurerm_cdn_frontdoor_endpoint.we_endpoint.id
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.app_origins.id
  cdn_frontdoor_origin_ids = [
    azurerm_cdn_frontdoor_origin.we_origin.id,
    azurerm_cdn_frontdoor_origin.ne_origin.id
  ]
  cdn_frontdoor_custom_domain_ids = [
    azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_prod.id,
    azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_sit1.id,
    azurerm_cdn_frontdoor_custom_domain.notifyadvresultready_st4_sit2.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_prod.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_sit1.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_sit2.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_nft.id,
    azurerm_cdn_frontdoor_custom_domain.sendvaluerupdate_uat.id,
    azurerm_cdn_frontdoor_custom_domain.ecotgetpropertydetails_prod.id,
    azurerm_cdn_frontdoor_custom_domain.ecotnotifypaymentsanction_prod.id,
    azurerm_cdn_frontdoor_custom_domain.devecotgetpropertydetails_sit1.id,
    azurerm_cdn_frontdoor_custom_domain.devecotnotifypaymentsanction_sit1.id,
  ]
  supported_protocols    = ["Http", "Https"] # Both needed for https_redirect_enabled to work
  patterns_to_match      = ["/*"]
  forwarding_protocol    = "HttpsOnly"
  https_redirect_enabled = true
  link_to_default_domain = false # Custom domains are explicit; default domain not needed in production
  enabled                = true
}

# ============================================================================
# DIAGNOSTIC SETTINGS ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â LLD: Logs + Metrics ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ LogA-WE
# ============================================================================

resource "azurerm_monitor_diagnostic_setting" "afd_diag" {
  name                       = "SI-WEB-AFD-01-diag"
  target_resource_id         = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.loga_we.id

  enabled_log { category = "FrontDoorAccessLog" }
  enabled_log { category = "FrontDoorHealthProbeLog" }
  enabled_log { category = "FrontDoorWebApplicationFirewallLog" }
  enabled_metric { category = "AllMetrics" }
}

