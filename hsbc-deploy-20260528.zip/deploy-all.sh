#!/bin/bash
# deploy-all.sh
# Deploys NSG updates, AppGW WAF, AFD WAF policies, and Backup Private Endpoints in sequence.
# Run from the directory where this script lives (alongside the phase directories).
#
# Usage:
#   chmod +x deploy-all.sh
#   ./deploy-all.sh
#
# Set PHASE11_DIR if your phase-11 state lives in a different location:
#   PHASE11_DIR=~/other-path/phase-11-front-door ./deploy-all.sh

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

header() { echo -e "\n${CYAN}========================================${NC}"; echo -e "${CYAN}  $1${NC}"; echo -e "${CYAN}========================================${NC}\n"; }
ok()     { echo -e "${GREEN}[OK]${NC} $1"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $1"; }
die()    { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo -e "${YELLOW}"
echo "  Phases to deploy:"
echo "    1. phase-04  NSG rules (UPDATE - adds RDS inbound rules)"
echo "    2. phase-08  Application Gateways + WAF policies (NEW)"
echo "    3. phase-11  state cleanup only (remove WAF resources moved to 11b)"
echo "    4. phase-11b AFD WAF policies DRS 2.1 (NEW)"
echo "    5. phase-14  Backup Private Endpoints (NEW)"
echo -e "${NC}"
read -rp "Proceed with all phases? [y/N] " confirm
[[ "$confirm" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 0; }

# ─── Phase 04 — NSG (update) ────────────────────────────────────────────────
header "Phase 04 — NSG (Update)"
cd "$SCRIPT_DIR/phase-04-network-security-groups"
terraform init -upgrade -input=false
terraform plan -out=phase04.tfplan -input=false
terraform apply -auto-approve phase04.tfplan
ok "Phase 04 complete"

# ─── Phase 08 — Application Gateways + WAF ──────────────────────────────────
header "Phase 08 — Application Gateways + WAF"
cd "$SCRIPT_DIR/phase-08-application-gateways"
terraform init -upgrade -input=false
terraform plan -var-file=certs.tfvars -out=phase08.tfplan -input=false
terraform apply -auto-approve phase08.tfplan
ok "Phase 08 complete"

# ─── Phase 11 — state cleanup (remove WAF resources moved to 11b) ───────────
header "Phase 11 — State Cleanup (WAF resources moved to 11b)"
PHASE11_DIR="${PHASE11_DIR:-$SCRIPT_DIR/phase-11-front-door}"
if [[ -d "$PHASE11_DIR" ]]; then
  cd "$PHASE11_DIR"
  terraform init -upgrade -input=false
  RESOURCES_TO_REMOVE=(
    "azurerm_cdn_frontdoor_firewall_policy.waf_adv"
    "azurerm_cdn_frontdoor_firewall_policy.waf_lms"
    "azurerm_cdn_frontdoor_firewall_policy.waf_hsbcpapi"
    "azurerm_cdn_frontdoor_security_policy.adv_security"
    "azurerm_cdn_frontdoor_security_policy.lms_security"
    "azurerm_cdn_frontdoor_security_policy.hsbcpapi_security"
  )
  for res in "${RESOURCES_TO_REMOVE[@]}"; do
    if terraform state list 2>/dev/null | grep -q "^${res}$"; then
      terraform state rm "$res"
      ok "Removed $res from phase-11 state"
    else
      warn "$res not in phase-11 state (already removed or never existed)"
    fi
  done
else
  warn "Phase-11 directory not found at: $PHASE11_DIR"
  warn "Skipping state cleanup — ensure WAF resources are not in phase-11 state before phase-11b apply"
  read -rp "Continue anyway? [y/N] " cont
  [[ "$cont" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 1; }
fi

# ─── Phase 11b — AFD WAF Policies ───────────────────────────────────────────
header "Phase 11b — AFD WAF Policies (DRS 2.1)"
cd "$SCRIPT_DIR/phase-11b-waf-policies"
terraform init -upgrade -input=false
terraform plan -out=phase11b.tfplan -input=false
terraform apply -auto-approve phase11b.tfplan
ok "Phase 11b complete"

# ─── Phase 14 — Backup Private Endpoints ────────────────────────────────────
header "Phase 14 — Backup Private Endpoints"
cd "$SCRIPT_DIR/phase-14-waf-policies"
terraform init -upgrade -input=false
terraform plan -out=phase14.tfplan -input=false
terraform apply -auto-approve phase14.tfplan
ok "Phase 14 complete"

# ─── Done ────────────────────────────────────────────────────────────────────
echo -e "\n${GREEN}All phases deployed successfully.${NC}\n"
