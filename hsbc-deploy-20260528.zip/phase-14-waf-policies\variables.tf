﻿# Phase 14: Azure Backup Private Endpoints — Variables

variable "environment" {
  type        = string
  default     = "production"
  description = "Environment name."
}

variable "primary_subscription_id" {
  type        = string
  sensitive   = true
  description = "Primary (WE) Azure subscription ID."
}

variable "secondary_subscription_id" {
  type        = string
  sensitive   = true
  description = "Secondary (NE) Azure subscription ID."
}

# --------------------------------------------------------------------------
# Resource Groups
# --------------------------------------------------------------------------

variable "we_resource_group_name" {
  type        = string
  default     = "MIP-SI-WE-RG"
  description = "WE CI-DMZ resource group (VNet + subnets live here)."
}

variable "ne_resource_group_name" {
  type        = string
  default     = "MIP-SI-NE-RG"
  description = "NE CI-DMZ resource group."
}

# --------------------------------------------------------------------------
# CI-DMZ VNet & Subnet names (private endpoint placement)
# --------------------------------------------------------------------------

variable "we_cidmz_vnet_name" {
  type        = string
  default     = "MIP-SI-WE-ciDMZ-vnet"
  description = "WE CI-DMZ VNet name."
}

variable "ne_cidmz_vnet_name" {
  type        = string
  default     = "MIP-SI-NE-ciDMZ-vnet"
  description = "NE CI-DMZ VNet name."
}

variable "we_backup_pe_subnet_name" {
  type        = string
  default     = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
  description = "WE subnet for Azure Backup private endpoint (shared proxy/PE subnet in CI-DMZ)."
}

variable "ne_backup_pe_subnet_name" {
  type        = string
  default     = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"
  description = "NE subnet for Azure Backup private endpoint."
}

# --------------------------------------------------------------------------
# Recovery Services Vaults (HSBC-owned, pre-existing)
# --------------------------------------------------------------------------

variable "we_rsv_name" {
  type        = string
  description = "Name of the WE Recovery Services Vault. Provided by HSBC infrastructure team."
}

variable "ne_rsv_name" {
  type        = string
  description = "Name of the NE Recovery Services Vault. Provided by HSBC infrastructure team."
}

variable "we_rsv_resource_group" {
  type        = string
  description = "Resource group containing the WE Recovery Services Vault."
}

variable "ne_rsv_resource_group" {
  type        = string
  description = "Resource group containing the NE Recovery Services Vault."
}

variable "we_pe_resource_group_name" {
  type        = string
  default     = "SI-OPS-WE-01-rg"
  description = "Resource group where the WE backup private endpoint is created (SI-OPS-WE-01-rg per LLD)."
}

variable "ne_pe_resource_group_name" {
  type        = string
  default     = "SI-OPS-NE-01-rg"
  description = "Resource group where the NE backup private endpoint is created (SI-OPS-NE-01-rg per LLD)."
}