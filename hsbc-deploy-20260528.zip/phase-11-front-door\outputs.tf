output "frontdoor_id" {
  value = azurerm_cdn_frontdoor_profile.global_frontdoor.id
}

output "we_endpoint_fqdn" {
  value = azurerm_cdn_frontdoor_endpoint.we_endpoint.host_name
}

output "ne_endpoint_fqdn" {
  value = azurerm_cdn_frontdoor_endpoint.ne_endpoint.host_name
}

# WAF policy outputs moved to phase-11b-waf-policies
