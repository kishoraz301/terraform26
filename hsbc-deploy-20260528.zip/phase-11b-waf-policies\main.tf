# Phase 11b: Azure Front Door WAF Policies + Security Policies
# Standalone config - deploys only WAF policies and security policy associations
# Depends on phase-11 (AFD profile, endpoints, custom domains already deployed)
# LLD v1.2 section 4.3.8

terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.subscription_id
  features {}
}

# ============================================================================
# DATA SOURCES - read already-deployed AFD profile
# ============================================================================

data "azurerm_cdn_frontdoor_profile" "afd" {
  name                = var.frontdoor_profile_name
  resource_group_name = var.resource_group_name
}

# ============================================================================
# LOCALS - construct custom domain resource IDs from known naming pattern
# Format: /subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.Cdn/profiles/{profile}/customDomains/{name}
# ============================================================================

locals {
  domain_base = "/subscriptions/${var.subscription_id}/resourceGroups/${var.resource_group_name}/providers/Microsoft.Cdn/profiles/${var.frontdoor_profile_name}/customDomains"

  domains = {
    notifyadvresultready_prod         = "${local.domain_base}/notifyadvresultready-prod"
    notifyadvresultready_sit1         = "${local.domain_base}/notifyadvresultready-sit1"
    notifyadvresultready_st4_sit2     = "${local.domain_base}/notifyadvresultready-st4-sit2"
    sendvaluerupdate_prod             = "${local.domain_base}/sendvaluerupdate-prod"
    sendvaluerupdate_sit1             = "${local.domain_base}/sendvaluerupdate-sit1"
    sendvaluerupdate_sit2             = "${local.domain_base}/sendvaluerupdate-sit2"
    sendvaluerupdate_nft              = "${local.domain_base}/sendvaluerupdate-nft"
    sendvaluerupdate_uat              = "${local.domain_base}/sendvaluerupdate-uat"
    ecotgetpropertydetails_prod       = "${local.domain_base}/ecotgetpropertydetails-prod"
    ecotnotifypaymentsanction_prod    = "${local.domain_base}/ecotnotifypaymentsanction-prod"
    devecotgetpropertydetails_sit1    = "${local.domain_base}/devecotgetpropertydetails-sit1"
    devecotnotifypaymentsanction_sit1 = "${local.domain_base}/devecotnotifypaymentsanction-sit1"
  }
}

# ============================================================================
# WAF POLICIES - LLD 4.3.8
# All policies: Microsoft_DefaultRuleSet 2.1 + Microsoft_BotManagerRuleSet 1.0
# Override rules: disabled (enabled=false), action=Log (no-op for disabled rules)
# Mode: Detection (Day-1), change waf_mode to Prevention for steady state
# ============================================================================

# ---- WAF-ADV - NotifyAdvResultReady FQDNs ----
# Custom rules: ALLOW-HSBC-CYBER-DAST (p1) + ALLOW-ADV-SOURCE (p2) � LLD page 69
resource "azurerm_cdn_frontdoor_firewall_policy" "waf_adv" {
  name                = "WAFADV"
  resource_group_name = var.resource_group_name
  sku_name            = var.frontdoor_sku
  enabled             = true
  mode                = var.waf_mode

  custom_rule {
    name     = "AllowHSBCCyberDAST"
    enabled  = true
    priority = 1
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["52.18.33.124/32", "52.210.241.58/32"]
    }
  }

  custom_rule {
    name     = "AllowADVSource"
    enabled  = true
    priority = 2
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values = [
        "91.214.4.0/24", "91.214.5.0/26", "91.214.5.64/28", "91.214.5.80/30",
        "91.214.5.84/31", "91.214.5.88/29", "91.214.5.96/27", "91.214.5.128/25",
        "91.214.6.0/23", "193.108.72.0/22", "193.108.76.0/26", "193.108.76.64/28",
        "193.108.76.80/30", "193.108.76.84/31", "193.108.76.88/29", "193.108.76.96/27",
        "193.108.76.128/25", "193.108.77.0/24", "193.108.78.0/23", "161.113.224.0/19"
      ]
    }
  }

  custom_rule {
    name                           = "cve202555182"
    enabled                        = true
    priority                       = 5
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2"
    enabled                        = true
    priority                       = 6
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182nextaction"
    enabled                        = true
    priority                       = 7
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2rsaction"
    enabled                        = true
    priority                       = 8
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "Rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182bodymultipart"
    enabled                        = true
    priority                       = 9
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name     = "BlockLargePostBody"
    enabled  = true
    priority = 10
    type     = "MatchRule"
    action   = "Block"
    match_condition {
      match_variable     = "RequestMethod"
      operator           = "Equal"
      negation_condition = false
      match_values       = ["POST"]
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "Content-Length"
      operator           = "GreaterThan"
      negation_condition = false
      match_values       = ["131072"]
    }
  }

  custom_rule {
    name                           = "RateLimit"
    enabled                        = true
    priority                       = 11
    type                           = "RateLimitRule"
    action                         = "Block"
    rate_limit_duration_in_minutes = 5
    rate_limit_threshold           = 64724
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rule {
    type    = "Microsoft_DefaultRuleSet"
    version = "2.1"
    action  = "Block"
    override {
      rule_group_name = "PROTOCOL-ENFORCEMENT"
      rule {
        rule_id = "920420"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920430"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920440"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920450"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920480"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "PHP"
      rule {
        rule_id = "933151"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "METHOD-ENFORCEMENT"
      rule {
        rule_id = "911100"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "General"
      rule {
        rule_id = "200002"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "200003"
        enabled = false
        action  = "Log"
      }
    }
  }

  managed_rule {
    type    = "Microsoft_BotManagerRuleSet"
    version = "1.0"
    action  = "Log"
  }

  tags = var.tags
}

# ---- WAF-LMS - SendValuerUpdate FQDNs ----
# Custom rules: ALLOW-HSBC-CYBER-DAST (p1) + ALLOW-LMS-SOURCE (p2)
resource "azurerm_cdn_frontdoor_firewall_policy" "waf_lms" {
  name                = "WAFLMS"
  resource_group_name = var.resource_group_name
  sku_name            = var.frontdoor_sku
  enabled             = true
  mode                = var.waf_mode

  custom_rule {
    name     = "AllowHSBCCyberDAST"
    enabled  = true
    priority = 1
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["52.18.33.124/32", "52.210.241.58/32"]
    }
  }

  custom_rule {
    name     = "AllowLMSSource"
    enabled  = true
    priority = 2
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["91.207.110.0/23", "91.102.7.0/24", "154.59.136.0/24"]
    }
  }

  custom_rule {
    name                           = "cve202555182"
    enabled                        = true
    priority                       = 5
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2"
    enabled                        = true
    priority                       = 6
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182nextaction"
    enabled                        = true
    priority                       = 7
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2rsaction"
    enabled                        = true
    priority                       = 8
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "Rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182bodymultipart"
    enabled                        = true
    priority                       = 9
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name     = "BlockLargePostBody"
    enabled  = true
    priority = 10
    type     = "MatchRule"
    action   = "Block"
    match_condition {
      match_variable     = "RequestMethod"
      operator           = "Equal"
      negation_condition = false
      match_values       = ["POST"]
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "Content-Length"
      operator           = "GreaterThan"
      negation_condition = false
      match_values       = ["131072"]
    }
  }

  custom_rule {
    name                           = "RateLimit"
    enabled                        = true
    priority                       = 11
    type                           = "RateLimitRule"
    action                         = "Block"
    rate_limit_duration_in_minutes = 5
    rate_limit_threshold           = 64724
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rule {
    type    = "Microsoft_DefaultRuleSet"
    version = "2.1"
    action  = "Block"
    override {
      rule_group_name = "PROTOCOL-ENFORCEMENT"
      rule {
        rule_id = "920420"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920430"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920440"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920450"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920480"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "PHP"
      rule {
        rule_id = "933151"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "METHOD-ENFORCEMENT"
      rule {
        rule_id = "911100"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "General"
      rule {
        rule_id = "200002"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "200003"
        enabled = false
        action  = "Log"
      }
    }
  }

  managed_rule {
    type    = "Microsoft_BotManagerRuleSet"
    version = "1.0"
    action  = "Log"
  }

  tags = var.tags
}

# ---- WAF-HSBCPAPI - ECOT / devECOT FQDNs ----
# Custom rules: ALLOW-HSBC-CYBER-DAST (p1) + ALLOW-HSBC-PAPI-SOURCE (p2)
resource "azurerm_cdn_frontdoor_firewall_policy" "waf_hsbcpapi" {
  name                = "WAFHSBCPAPI"
  resource_group_name = var.resource_group_name
  sku_name            = var.frontdoor_sku
  enabled             = true
  mode                = var.waf_mode

  custom_rule {
    name     = "AllowHSBCCyberDAST"
    enabled  = true
    priority = 1
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values       = ["52.18.33.124/32", "52.210.241.58/32"]
    }
  }

  custom_rule {
    name     = "AllowHSBCPAPISource"
    enabled  = true
    priority = 2
    type     = "MatchRule"
    action   = "Allow"
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = false
      match_values = [
        "99.81.103.225/32", "108.128.74.220/32", "54.194.204.117/32",
        "34.251.60.187/32", "54.217.8.240/32", "54.73.152.196/32"
      ]
    }
  }

  custom_rule {
    name                           = "cve202555182"
    enabled                        = true
    priority                       = 5
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2"
    enabled                        = true
    priority                       = 6
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data", "application/x-www-form-urlencoded"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["constructor:", "proto", "prototype:", "_response:"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182nextaction"
    enabled                        = true
    priority                       = 7
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "next-action"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182ver2rsaction"
    enabled                        = true
    priority                       = 8
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "Rsc-action-id"
      operator           = "Any"
      negation_condition = false
      match_values       = []
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name                           = "cve202555182bodymultipart"
    enabled                        = true
    priority                       = 9
    type                           = "RateLimitRule"
    action                         = "Log"
    rate_limit_duration_in_minutes = 1
    rate_limit_threshold           = 100
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "content-type"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["multipart/form-data"]
      transforms         = ["Lowercase"]
    }
    match_condition {
      match_variable     = "RequestBody"
      operator           = "Contains"
      negation_condition = false
      match_values       = ["status:resolved_model", "$@", "constructor.constructor", "_formdata", "_chunks%2F_response_chunks"]
      transforms         = ["Lowercase", "UrlDecode"]
    }
  }

  custom_rule {
    name     = "BlockLargePostBody"
    enabled  = true
    priority = 10
    type     = "MatchRule"
    action   = "Block"
    match_condition {
      match_variable     = "RequestMethod"
      operator           = "Equal"
      negation_condition = false
      match_values       = ["POST"]
    }
    match_condition {
      match_variable     = "RequestHeader"
      selector           = "Content-Length"
      operator           = "GreaterThan"
      negation_condition = false
      match_values       = ["131072"]
    }
  }

  custom_rule {
    name                           = "RateLimit"
    enabled                        = true
    priority                       = 11
    type                           = "RateLimitRule"
    action                         = "Block"
    rate_limit_duration_in_minutes = 5
    rate_limit_threshold           = 64724
    match_condition {
      match_variable     = "RemoteAddr"
      operator           = "IPMatch"
      negation_condition = true
      match_values       = ["255.255.255.255/32"]
    }
  }

  managed_rule {
    type    = "Microsoft_DefaultRuleSet"
    version = "2.1"
    action  = "Block"
    override {
      rule_group_name = "PROTOCOL-ENFORCEMENT"
      rule {
        rule_id = "920420"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920430"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920440"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920450"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "920480"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "PHP"
      rule {
        rule_id = "933151"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "METHOD-ENFORCEMENT"
      rule {
        rule_id = "911100"
        enabled = false
        action  = "Log"
      }
    }
    override {
      rule_group_name = "General"
      rule {
        rule_id = "200002"
        enabled = false
        action  = "Log"
      }
      rule {
        rule_id = "200003"
        enabled = false
        action  = "Log"
      }
    }
  }

  managed_rule {
    type    = "Microsoft_BotManagerRuleSet"
    version = "1.0"
    action  = "Log"
  }

  tags = var.tags
}

# ============================================================================
# SECURITY POLICIES - associates WAF policies to custom domain groups on AFD
# ============================================================================

resource "azurerm_cdn_frontdoor_security_policy" "adv_security" {
  name                     = "security-waf-adv"
  cdn_frontdoor_profile_id = data.azurerm_cdn_frontdoor_profile.afd.id
  security_policies {
    firewall {
      cdn_frontdoor_firewall_policy_id = azurerm_cdn_frontdoor_firewall_policy.waf_adv.id
      association {
        domain { cdn_frontdoor_domain_id = local.domains.notifyadvresultready_prod }
        domain { cdn_frontdoor_domain_id = local.domains.notifyadvresultready_sit1 }
        domain { cdn_frontdoor_domain_id = local.domains.notifyadvresultready_st4_sit2 }
        patterns_to_match = ["/*"]
      }
    }
  }
}

resource "azurerm_cdn_frontdoor_security_policy" "lms_security" {
  name                     = "security-waf-lms"
  cdn_frontdoor_profile_id = data.azurerm_cdn_frontdoor_profile.afd.id
  security_policies {
    firewall {
      cdn_frontdoor_firewall_policy_id = azurerm_cdn_frontdoor_firewall_policy.waf_lms.id
      association {
        domain { cdn_frontdoor_domain_id = local.domains.sendvaluerupdate_prod }
        domain { cdn_frontdoor_domain_id = local.domains.sendvaluerupdate_sit1 }
        domain { cdn_frontdoor_domain_id = local.domains.sendvaluerupdate_sit2 }
        domain { cdn_frontdoor_domain_id = local.domains.sendvaluerupdate_nft }
        domain { cdn_frontdoor_domain_id = local.domains.sendvaluerupdate_uat }
        patterns_to_match = ["/*"]
      }
    }
  }
}

resource "azurerm_cdn_frontdoor_security_policy" "hsbcpapi_security" {
  name                     = "security-waf-hsbcpapi"
  cdn_frontdoor_profile_id = data.azurerm_cdn_frontdoor_profile.afd.id
  security_policies {
    firewall {
      cdn_frontdoor_firewall_policy_id = azurerm_cdn_frontdoor_firewall_policy.waf_hsbcpapi.id
      association {
        domain { cdn_frontdoor_domain_id = local.domains.ecotgetpropertydetails_prod }
        domain { cdn_frontdoor_domain_id = local.domains.ecotnotifypaymentsanction_prod }
        domain { cdn_frontdoor_domain_id = local.domains.devecotgetpropertydetails_sit1 }
        domain { cdn_frontdoor_domain_id = local.domains.devecotnotifypaymentsanction_sit1 }
        patterns_to_match = ["/*"]
      }
    }
  }
}
