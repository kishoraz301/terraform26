variable "environment" {
  type    = string
  default = "production"
}

variable "primary_subscription_id" {
  type      = string
  sensitive = true
}

variable "secondary_subscription_id" {
  type      = string
  sensitive = true
}

# Source resource groups (subnets + PIPs): existing shared RGs in each region.
# AppGW-dedicated RGs (si-dmz-appgw-we-01-rg / si-dmz-appgw-ne-01-rg) are
# created as azurerm_resource_group resources in main.tf.
variable "we_resource_group_name" {
  type    = string
  default = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  type    = string
  default = "MIP-SI-NE-RG"
}

# NE private frontend IP — pending architect confirmation of NE IP plan.
# WE is hardcoded in main.tf: 10.200.11.170 (LLD section 4.3.9).
variable "ne_appgw_private_frontend_ip" {
  type        = string
  default     = null
  description = "Static private IP for NE AppGW private frontend. Omit until NE IP plan confirmed."
}

# Per-listener WAF policies auto-assigned by hostname regex in locals (main.tf).
# priority: must be unique across all routing rules; HTTPS rules use this value,
#           HTTP redirect rules use priority + 200.
variable "we_https_listeners" {
  type = list(object({
    hostname  = string
    cert_name = string
    priority  = number
  }))
  description = "Per-domain HTTPS listener config for WE AppGW. cert_name must match a key in we_cert_map."
}

variable "ne_https_listeners" {
  type = list(object({
    hostname  = string
    cert_name = string
    priority  = number
  }))
  description = "Per-domain HTTPS listener config for NE AppGW. cert_name must match a key in ne_cert_map."
}

# Certificate maps — populated via certs.tfvars once certs are uploaded to Key Vault.
# key   = cert_name (matches cert_name in the listener objects above)
# value = https://<vault>.vault.azure.net/secrets/<cert-name>
# HTTPS listeners are only created for domains whose cert_name is present in this map.
variable "we_cert_map" {
  type        = map(string)
  default     = {}
  description = "cert_name → KV secret URI for WE AppGW SSL certificates (SI-Core-Vault-WE-01)."
}

variable "ne_cert_map" {
  type        = map(string)
  default     = {}
  description = "cert_name → KV secret URI for NE AppGW SSL certificates (SI-Core-Vault-NE-51)."
}

variable "ne_waf_mode" {
  type        = string
  default     = "Detection"
  description = "WAF mode for NE AppGW policies (LLD 4.3.9: Detection on Day-1 for NE, Prevention for WE)."
  validation {
    condition     = contains(["Detection", "Prevention"], var.ne_waf_mode)
    error_message = "ne_waf_mode must be 'Detection' or 'Prevention'."
  }
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags applied to all resources in this phase."
}

