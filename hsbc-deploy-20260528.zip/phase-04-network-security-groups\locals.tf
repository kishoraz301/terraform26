# Phase 04 Locals - Network Security Groups
# References shared variables from root configuration

locals {
  # ============================================================================
  # NAMING & IDENTITY CONSTANTS
  # ============================================================================

  namespace    = "MIP-SI"
  project_code = "HSBC"
  environment  = var.environment

  # ============================================================================
  # DEFAULT TAGS - APPLIED TO ALL RESOURCES
  # ============================================================================

  default_tags = {
    Project     = local.project_code
    Environment = local.environment
    Namespace   = local.namespace
    ManagedBy   = "Terraform"
  }
}
