﻿# Phase 14: Azure Backup Private Endpoints (LLD 4.3.10)
# Provides private connectivity from CI-DMZ to Azure Backup (Recovery Services Vault).
#
# NOTE: The three orphaned AVM WAF-policy modules that previously lived here
# (MIP-SI-WE-AppGW-WAF-Policy, MIP-SI-NE-AppGW-WAF-Policy,
#  MIP-SI-Global-FrontDoor-WAF-Policy) have been REMOVED because:
#   - They used incorrect LLD names and were never attached to any AppGW or AFD.
#   - The correct AppGW WAF policies (SI-DMZ-WAFPLCY-01/51, WAF-LMS, WAF-HSBCPAPI)
#     are deployed by phase-08 using native azurerm_web_application_firewall_policy.
#   - The AFD WAF policies are deployed by phase-11b.
# Running terraform apply after this change will DESTROY the three orphaned
# resources listed above (safe — they are unattached).

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.primary_subscription_id
  features {}
}

provider "azurerm" {
  alias           = "secondary"
  subscription_id = var.secondary_subscription_id
  features {}
}

# ============================================================================
# DATA SOURCES — Resource Groups
# ============================================================================

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# OPS resource groups — where backup private endpoints are placed (LLD 4.3.10)
data "azurerm_resource_group" "we_ops" {
  name = var.we_pe_resource_group_name
}

data "azurerm_resource_group" "ne_ops" {
  provider = azurerm.secondary
  name     = var.ne_pe_resource_group_name
}

# ============================================================================
# DATA SOURCES — CI-DMZ VNets and Proxy Subnets (backup PE placement)
# ============================================================================

data "azurerm_virtual_network" "cidmz_we" {
  name                = var.we_cidmz_vnet_name
  resource_group_name = var.we_resource_group_name
}

data "azurerm_virtual_network" "cidmz_ne" {
  provider            = azurerm.secondary
  name                = var.ne_cidmz_vnet_name
  resource_group_name = var.ne_resource_group_name
}

data "azurerm_subnet" "we_backup_pe_subnet" {
  name                 = var.we_backup_pe_subnet_name
  virtual_network_name = var.we_cidmz_vnet_name
  resource_group_name  = var.we_resource_group_name
}

data "azurerm_subnet" "ne_backup_pe_subnet" {
  provider             = azurerm.secondary
  name                 = var.ne_backup_pe_subnet_name
  virtual_network_name = var.ne_cidmz_vnet_name
  resource_group_name  = var.ne_resource_group_name
}

# ============================================================================
# DATA SOURCES — Recovery Services Vaults (HSBC-owned, pre-existing)
# ============================================================================

data "azurerm_recovery_services_vault" "we_rsv" {
  name                = var.we_rsv_name
  resource_group_name = var.we_rsv_resource_group
}

data "azurerm_recovery_services_vault" "ne_rsv" {
  provider            = azurerm.secondary
  name                = var.ne_rsv_name
  resource_group_name = var.ne_rsv_resource_group
}

# ============================================================================
# PRIVATE DNS ZONES — Azure Backup (LLD 4.3.10)
# privatelink.{region}.backup.windowsazure.com
# ============================================================================

resource "azurerm_private_dns_zone" "backup_we" {
  name                = "privatelink.westeurope.backup.windowsazure.com"
  resource_group_name = var.we_resource_group_name
}

resource "azurerm_private_dns_zone" "backup_ne" {
  provider            = azurerm.secondary
  name                = "privatelink.northeurope.backup.windowsazure.com"
  resource_group_name = var.ne_resource_group_name
}

# VNet links — CI-DMZ VNets to their respective backup DNS zones
resource "azurerm_private_dns_zone_virtual_network_link" "backup_we_link" {
  name                  = "cidmz-we-backup-dns-link"
  resource_group_name   = var.we_resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.backup_we.name
  virtual_network_id    = data.azurerm_virtual_network.cidmz_we.id
  registration_enabled  = false
}

resource "azurerm_private_dns_zone_virtual_network_link" "backup_ne_link" {
  provider              = azurerm.secondary
  name                  = "cidmz-ne-backup-dns-link"
  resource_group_name   = var.ne_resource_group_name
  private_dns_zone_name = azurerm_private_dns_zone.backup_ne.name
  virtual_network_id    = data.azurerm_virtual_network.cidmz_ne.id
  registration_enabled  = false
}

# ============================================================================
# PRIVATE ENDPOINTS — Azure Backup (LLD 4.3.10)
# Place in CI-DMZ proxy subnets (same as Key Vault PEs in phase-08)
# ============================================================================

resource "azurerm_private_endpoint" "we_backup_pe" {
  name                = "SI-PEP-WE-RSV"
  location            = data.azurerm_resource_group.we_ops.location
  resource_group_name = var.we_pe_resource_group_name
  subnet_id           = data.azurerm_subnet.we_backup_pe_subnet.id

  private_service_connection {
    name                           = "SI-PEP-WE-RSV-psc"
    private_connection_resource_id = data.azurerm_recovery_services_vault.we_rsv.id
    subresource_names              = ["AzureBackup"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "backup-we-dns-group"
    private_dns_zone_ids = [azurerm_private_dns_zone.backup_we.id]
  }
}

resource "azurerm_private_endpoint" "ne_backup_pe" {
  provider            = azurerm.secondary
  name                = "SI-PEP-NE-RSV"
  location            = data.azurerm_resource_group.ne_ops.location
  resource_group_name = var.ne_pe_resource_group_name
  subnet_id           = data.azurerm_subnet.ne_backup_pe_subnet.id

  private_service_connection {
    name                           = "SI-PEP-NE-RSV-psc"
    private_connection_resource_id = data.azurerm_recovery_services_vault.ne_rsv.id
    subresource_names              = ["AzureBackup"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "backup-ne-dns-group"
    private_dns_zone_ids = [azurerm_private_dns_zone.backup_ne.id]
  }
}