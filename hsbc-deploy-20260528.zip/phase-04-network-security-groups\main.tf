# Phase 04: Network Security Groups (NSGs)
# Deploy after Phase 03: Subnets
# Creates 4 NSGs for Proxy and RDS subnets in both West Europe and North Europe regions
# Each NSG includes detailed inbound and outbound rules with specific IP ranges, ports, and service tags

terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.primary_subscription_id
  features {
    virtual_machine {
    }
  }
}

provider "azurerm" {
  alias           = "secondary"
  subscription_id = var.secondary_subscription_id
  features {
    virtual_machine {
    }
  }
}

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# ============================================================================
# VNet data sources (used for subnet lookups and NSG associations)
# ============================================================================

data "azurerm_virtual_network" "we_cidmz" {
  name                = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.we.name
}

data "azurerm_virtual_network" "ne_cidmz" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.ne.name
}

data "azurerm_subnet" "we_cidmz_proxy_snet" {
  name                 = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
  virtual_network_name = data.azurerm_virtual_network.we_cidmz.name
  resource_group_name  = data.azurerm_resource_group.we.name
}

data "azurerm_subnet" "we_cidmz_rds_snet" {
  name                 = "MIP-SI-WE-ciDMZ-RDS-snet"
  virtual_network_name = data.azurerm_virtual_network.we_cidmz.name
  resource_group_name  = data.azurerm_resource_group.we.name
}

data "azurerm_subnet" "we_cidmz_appgw_snet" {
  name                 = "MIP-SI-WE-ciDMZ-AppGW-snet"
  virtual_network_name = data.azurerm_virtual_network.we_cidmz.name
  resource_group_name  = data.azurerm_resource_group.we.name
}

data "azurerm_subnet" "ne_cidmz_proxy_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"
  virtual_network_name = data.azurerm_virtual_network.ne_cidmz.name
  resource_group_name  = data.azurerm_resource_group.ne.name
}

data "azurerm_subnet" "ne_cidmz_rds_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-RDS-snet"
  virtual_network_name = data.azurerm_virtual_network.ne_cidmz.name
  resource_group_name  = data.azurerm_resource_group.ne.name
}

data "azurerm_subnet" "ne_cidmz_appgw_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-AppGW-snet"
  virtual_network_name = data.azurerm_virtual_network.ne_cidmz.name
  resource_group_name  = data.azurerm_resource_group.ne.name
}

# ============================================================================
# WEST EUROPE - NSGs
# ============================================================================

# ============================================================================
# WE Proxy DMZ NSG (MIP-SI-WE-ciDMZ-Proxy-nsg) - Subnet: 10.200.11.0/26
# ============================================================================

resource "azurerm_network_security_group" "we_proxy_nsg" {
  name                = "MIP-SI-WE-ciDMZ-Proxy-nsg"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  tags = merge(
    local.default_tags,
    { Subnet = "Proxy-DMZ", Region = "West Europe" }
  )
}

# ============================================================================
# WE Proxy Inbound Rules
# ============================================================================

# Allow-LINUX-SSH (Priority 100)
resource "azurerm_network_security_rule" "we_proxy_allow_ssh" {
  name                        = "Allow-LINUX-SSH"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "22"
  source_address_prefixes     = ["10.100.1.12", "10.150.1.12", "10.150.10.0/27", "10.100.10.0/27"]
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-NGINX-HTTPS (Priority 110)
resource "azurerm_network_security_rule" "we_proxy_allow_nginx_https" {
  name                        = "Allow-NGINX-HTTPS"
  priority                    = 110
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.160/27"
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-INTERNAL-to-SQUID-PROXY (Priority 120)
resource "azurerm_network_security_rule" "we_proxy_allow_squid" {
  name                        = "Allow-INTERNAL-to-SQUID-PROXY"
  priority                    = 120
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "3128", "8080"]
  source_address_prefixes     = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-AZURELB-to-SQUID-PROXY (Priority 130)
resource "azurerm_network_security_rule" "we_proxy_allow_azurelb_squid" {
  name                        = "Allow-AZURELB-to-SQUID-PROXY"
  priority                    = 130
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3128"
  source_address_prefix       = "AzureLoadBalancer"
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}


# ============================================================================
# WE Proxy Outbound Rules
# ============================================================================

# Allow-NGINX-to-CINTERNAL (Priority 200)
resource "azurerm_network_security_rule" "we_proxy_allow_nginx_cinternal" {
  name                        = "Allow-NGINX-to-CINTERNAL"
  priority                    = 200
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "10.100.0.0/16"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-SQUID-to-AFW-WEB (Priority 210)
resource "azurerm_network_security_rule" "we_proxy_allow_squid_afw" {
  name                        = "Allow-SQUID-to-AFW-WEB"
  priority                    = 210
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "10.200.50.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-DNS (Priority 230)
resource "azurerm_network_security_rule" "we_proxy_allow_dns" {
  name                        = "Allow-DNS"
  priority                    = 230
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "53"
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "AzureDNS"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-UBUNTU-UPDATES-AZURE (Priority 320)
resource "azurerm_network_security_rule" "we_proxy_allow_ubuntu_azure" {
  name                        = "Allow-UBUNTU-UPDATES-AZURE"
  priority                    = 320
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "Internet"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}


# ============================================================================
# WE RDS NSG (MIP-SI-WE-RDS-NSG) - Subnet: 10.200.11.64/27
# ============================================================================

resource "azurerm_network_security_group" "we_rds_nsg" {
  name                = "MIP-SI-WE-RDS-NSG"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  tags = merge(
    local.default_tags,
    { Subnet = "RDS", Region = "West Europe" }
  )
}

# ============================================================================
# WE RDS Inbound Rules
# ============================================================================

# Allow-RDS-HTTPS-from-CEFW-WE (Priority 200)
resource "azurerm_network_security_rule" "we_rds_allow_cefw_inbound" {
  name                        = "Allow-RDS-HTTPS-from-CEFW-WE"
  priority                    = 200
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.50.0/26"
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-UK-VPN-IN (Priority 210)
resource "azurerm_network_security_rule" "we_rds_allow_uk_vpn" {
  name                        = "Allow-UK-VPN-IN"
  priority                    = 210
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["27.110.72.0/23", "27.110.74.0/24", "27.110.75.0/25", "27.110.75.128/26", "27.110.75.192/27", "27.110.75.224/28", "27.110.75.240/29", "27.110.75.248/30", "27.110.75.252/32", "27.110.76.0/24", "27.110.77.0/25", "27.110.77.128/26", "27.110.77.192/27", "27.110.77.224/28", "27.110.77.240/29", "27.110.77.248/30", "27.110.77.252/32", "27.110.78.0/24", "27.110.79.0/25", "27.110.79.128/26", "27.110.79.192/27", "27.110.79.224/27", "203.112.80.0/20", "161.113.192.0/19"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-IND-VPN-IN (Priority 220)
resource "azurerm_network_security_rule" "we_rds_allow_ind_vpn" {
  name                        = "Allow-IND-VPN-IN"
  priority                    = 220
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["203.171.222.0/29", "203.171.222.8/32", "203.171.222.9/32", "203.171.222.10/32", "203.171.222.12/30", "203.171.222.16/28", "203.171.222.32/27", "203.171.222.64/26", "203.171.222.128/25", "203.171.209.0/29", "203.171.209.8/30", "203.171.209.13/32", "203.171.209.14/32", "203.171.209.15/32", "203.171.209.16/28", "203.171.209.32/27", "203.171.209.64/26", "203.171.209.128/25", "103.171.66.0/27", "103.171.66.32/30", "103.171.66.64/26", "103.171.66.128/25", "103.171.67.0/24", "103.54.135.32/28"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-HK-VPN-IN (Priority 230)
resource "azurerm_network_security_rule" "we_rds_allow_hk_vpn" {
  name                        = "Allow-HK-VPN-IN"
  priority                    = 230
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["91.214.4.0/24", "91.214.5.0/26", "91.214.5.64/28", "91.214.5.80/30", "91.214.5.84/32", "91.214.5.85/32", "91.214.5.88/29", "91.214.5.96/27", "91.214.5.128/25", "91.214.6.0/23", "193.108.72.0/22", "193.108.76.0/26", "193.108.76.64/28", "193.108.76.80/30", "193.108.76.84/32", "193.108.76.85/32", "193.108.76.88/29", "193.108.76.96/27", "193.108.76.128/25", "193.108.77.0/24", "193.108.78.0/23", "161.113.224.0/19"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-MGMT-ADMIN-RDS (Priority 270)
resource "azurerm_network_security_rule" "we_rds_allow_mgmt_admin" {
  name                        = "Allow-MGMT-ADMIN-RDS"
  priority                    = 270
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefixes     = ["10.100.1.0/24", "10.150.1.0/24"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-IN-RDS-INTERNAL (Priority 280)
resource "azurerm_network_security_rule" "we_rds_allow_internal" {
  name                        = "Allow-IN-RDS-INTERNAL"
  priority                    = 280
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefixes     = ["10.100.1.0/24", "10.150.1.0/24"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-RDPfromRDSWEB-In (Priority 1012)
resource "azurerm_network_security_rule" "we_rds_allow_rdp_from_rdsweb" {
  name                        = "Allow-RDPfromRDSWEB-In"
  priority                    = 1012
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.0/24"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-RDPfromRDSWEB-In-UDP (Priority 1013)
resource "azurerm_network_security_rule" "we_rds_allow_rdp_udp_from_rdsweb" {
  name                        = "Allow-RDPfromRDSWEB-In-UDP"
  priority                    = 1013
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.0/24"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow_RDS_Gateway_To_ConnectionBroker (Priority 1014)
resource "azurerm_network_security_rule" "we_rds_allow_gw_to_connbroker" {
  name                        = "Allow_RDS_Gateway_To_ConnectionBroker"
  priority                    = 1014
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5504"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.0/24"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow_RDS_Internal_WMI_In (Priority 1015)
resource "azurerm_network_security_rule" "we_rds_allow_internal_wmi" {
  name                        = "Allow_RDS_Internal_WMI_In"
  priority                    = 1015
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.0/24"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow_NetLogon_Internal_RDS (Priority 1016)
resource "azurerm_network_security_rule" "we_rds_allow_netlogon" {
  name                        = "Allow_NetLogon_Internal_RDS"
  priority                    = 1016
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "137"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.0/24"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-HSBC-DRN-TCP-Inbound02 (Priority 4005)
resource "azurerm_network_security_rule" "we_rds_allow_drn_tcp_inbound02" {
  name                        = "Allow-HSBC-DRN-TCP-Inbound02"
  priority                    = 4005
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["135", "443", "445", "5000-5100", "49152-65535"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.0/24"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# ============================================================================
# WE RDS Outbound Rules
# ============================================================================

# Allow-SESSIONHOSTS-RDP-TCP (Priority 100)
resource "azurerm_network_security_rule" "we_rds_allow_sessionhosts_rdp_tcp" {
  name                         = "Allow-SESSIONHOSTS-RDP-TCP"
  priority                     = 100
  direction                    = "Outbound"
  access                       = "Allow"
  protocol                     = "Tcp"
  source_port_range            = "*"
  destination_port_range       = "3389"
  source_address_prefix        = "10.200.11.64/27"
  destination_address_prefixes = ["10.100.1.11", "10.100.1.12", "10.100.1.14"]
  resource_group_name          = data.azurerm_resource_group.we.name
  network_security_group_name  = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-SESSIONHOSTS-RDP-UDP (Priority 110)
resource "azurerm_network_security_rule" "we_rds_allow_sessionhosts_rdp_udp" {
  name                         = "Allow-SESSIONHOSTS-RDP-UDP"
  priority                     = 110
  direction                    = "Outbound"
  access                       = "Allow"
  protocol                     = "Udp"
  source_port_range            = "*"
  destination_port_range       = "3389"
  source_address_prefix        = "10.200.11.64/27"
  destination_address_prefixes = ["10.100.1.11", "10.100.1.12", "10.100.1.14"]
  resource_group_name          = data.azurerm_resource_group.we.name
  network_security_group_name  = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-To-Firewall-Direct (Priority 170)
resource "azurerm_network_security_rule" "we_rds_allow_firewall_direct" {
  name                        = "Allow-To-Firewall-Direct"
  priority                    = 170
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureFirewall"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-RD-CONNECTIONBROKER (Priority 130)
resource "azurerm_network_security_rule" "we_rds_allow_connectionbroker" {
  name                        = "Allow-RD-CONNECTIONBROKER"
  priority                    = 130
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5504"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.10"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-RD-WMIDC (Priority 140)
resource "azurerm_network_security_rule" "we_rds_allow_wmidc" {
  name                         = "Allow-RD-WMIDC"
  priority                     = 140
  direction                    = "Outbound"
  access                       = "Allow"
  protocol                     = "Tcp"
  source_port_range            = "*"
  destination_port_range       = "5985"
  source_address_prefix        = "10.200.11.64/27"
  destination_address_prefixes = ["10.100.0.0/24", "10.100.1.0/24", "10.100.2.0/24"]
  resource_group_name          = data.azurerm_resource_group.we.name
  network_security_group_name  = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP (Priority 150)
resource "azurerm_network_security_rule" "we_rds_allow_dc_tcp" {
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP"
  priority                    = 150
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "80", "88", "135", "139", "389", "443", "445", "464", "636", "5000-5100", "49152-65535"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP (Priority 160)
resource "azurerm_network_security_rule" "we_rds_allow_dc_udp" {
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP"
  priority                    = 160
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "88", "123", "137", "138", "389", "464"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# WSUS-out (Priority 4003)
resource "azurerm_network_security_rule" "we_rds_wsus_out" {
  name                        = "WSUS-out"
  priority                    = 4003
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["8530", "8531"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.0.0.22"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# AzureCloud-UKTimeSync-Out (Priority 4005)
resource "azurerm_network_security_rule" "we_rds_time_sync_out" {
  name                        = "AzureCloud-UKTimeSync-Out"
  priority                    = 4005
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "123"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureCloud.ukwest"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-AZUREBACKUP (Priority 4015)
resource "azurerm_network_security_rule" "we_rds_allow_azurebackup" {
  name                        = "Allow-AZUREBACKUP"
  priority                    = 4015
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureBackup"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-AZUREMONITOR (Priority 4018)
resource "azurerm_network_security_rule" "we_rds_allow_azuremonitor" {
  name                        = "Allow-AZUREMONITOR"
  priority                    = 4018
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureMonitor"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-MDE (Priority 4019)
resource "azurerm_network_security_rule" "we_rds_allow_mde" {
  name                        = "Allow-MDE"
  priority                    = 4019
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "MicrosoftDefenderForEndpoint"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-AAD (Priority 4020)
resource "azurerm_network_security_rule" "we_rds_allow_aad" {
  name                        = "Allow-AAD"
  priority                    = 4020
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureActiveDirectory"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# AllowCrowdStrikeOut (Priority 4012)
# Note: NSG rules do not support FQDN destinations. IPs below are from LLD reference list.
# CrowdStrike traffic is also permitted via Allow-To-Firewall-Direct (priority 170) routing
# through Azure Firewall where FQDN-based CrowdStrike rules (eu-1) are enforced.
resource "azurerm_network_security_rule" "we_rds_allow_crowdstrike" {
  name                   = "AllowCrowdStrikeOut"
  priority               = 4012
  direction              = "Outbound"
  access                 = "Allow"
  protocol               = "Tcp"
  source_port_range      = "*"
  destination_port_range = "443"
  source_address_prefix  = "10.200.11.64/27"
  destination_address_prefixes = [
    "13.56.127.239/32", "13.57.54.63/32", "50.18.194.39/32", "52.52.117.52/32", "52.52.119.33/32",
    "52.52.149.168/32", "52.52.239.58/32", "52.53.77.89/32", "52.8.134.130/32", "52.8.160.82/32",
    "52.8.172.89/32", "52.8.173.58/32", "52.8.19.75/32", "52.8.32.113/32", "52.8.45.162/32",
    "52.8.5.240/32", "52.8.54.244/32", "52.8.61.206/32", "52.9.104.148/32", "52.9.212.176/32",
    "52.9.77.209/32", "52.9.82.94/32", "52.9.87.98/32", "54.183.105.3/32", "54.183.122.156/32",
    "54.183.140.32/32", "54.183.142.105/32", "54.183.148.116/32", "54.183.148.43/32", "54.183.234.42/32",
    "54.183.24.162/32", "54.183.252.86/32", "54.183.34.154/32", "54.183.39.68/32", "54.183.51.31/32",
    "54.183.51.69/32", "54.183.52.221/32", "54.193.117.199/32", "54.193.27.226/32", "54.193.29.47/32",
    "54.193.67.98/32", "54.193.87.57/32", "54.193.90.171/32", "54.193.93.19/32", "54.215.131.232/32",
    "54.215.154.80/32", "54.215.169.199/32", "54.215.169.38/32", "54.215.176.108/32", "54.215.183.157/32",
    "54.215.226.55/32", "54.219.112.243/32", "54.219.115.12/32", "54.219.137.54/32", "54.219.140.50/32",
    "54.219.141.250/32", "54.219.145.181/32", "54.219.147.253/32", "54.219.148.161/32", "54.219.149.89/32",
    "54.219.149.92/32", "54.219.151.1/32", "54.219.151.27/32", "54.219.153.248/32", "54.219.158.53/32",
    "54.219.159.84/32", "54.219.161.141/32", "54.241.138.180/32", "54.241.146.67/32", "54.241.148.127/32",
    "54.241.150.134/32", "54.241.161.60/32", "54.241.162.180/32", "54.241.162.64/32", "54.241.164.212/32",
    "54.241.175.140/32", "54.241.175.52/32", "54.241.179.52/32", "54.241.181.242/32", "54.241.184.161/32",
    "54.241.185.201/32", "54.241.186.124/32", "54.241.197.58/32", "54.67.105.202/32", "54.67.119.89/32",
    "54.67.123.150/32", "54.67.123.234/32", "54.67.26.184/32", "54.67.33.233/32", "54.67.48.56/32",
    "54.67.54.116/32", "54.67.6.201/32", "54.67.68.88/32", "54.67.92.206/32", "54.67.96.255/32",
    "54.67.99.247/32", "13.56.121.58/32", "50.18.198.237/32", "52.8.141.1/32", "54.183.120.141/32",
    "54.183.135.80/32", "54.183.215.154/32", "54.193.86.245/32", "54.215.170.42/32", "54.219.179.25/32",
    "54.241.161.242/32", "54.241.181.78/32", "54.241.182.78/32", "54.241.183.151/32", "54.241.183.229/32",
    "54.241.183.232/32", "54.67.108.17/32", "54.67.114.188/32", "54.67.122.238/32", "54.67.17.131/32",
    "54.67.24.156/32", "54.67.4.108/32", "54.67.41.192/32", "54.67.5.136/32", "54.67.51.32/32",
    "54.67.72.218/32", "54.67.78.134/32"
  ]
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}


# ============================================================================
# NORTH EUROPE - NSGs
# ============================================================================

# ============================================================================
# NE Proxy DMZ NSG (MIP-SI-NE-ciDMZ-Proxy-nsg) - Subnet: 10.200.12.0/26
# ============================================================================

resource "azurerm_network_security_group" "ne_proxy_nsg" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-Proxy-nsg"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  tags = merge(
    local.default_tags,
    { Subnet = "Proxy-DMZ", Region = "North Europe" }
  )
}

# ============================================================================
# NE Proxy Inbound Rules
# ============================================================================

# Allow-LINUX-SSH (Priority 100)
resource "azurerm_network_security_rule" "ne_proxy_allow_ssh" {
  provider                    = azurerm.secondary
  name                        = "Allow-LINUX-SSH"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "22"
  source_address_prefixes     = ["10.150.1.12", "10.150.10.0/27", "10.100.10.0/27"]
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-NGINX-HTTPS (Priority 110)
resource "azurerm_network_security_rule" "ne_proxy_allow_nginx_https" {
  provider                    = azurerm.secondary
  name                        = "Allow-NGINX-HTTPS"
  priority                    = 110
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.160/27"
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-INTERNAL-to-SQUID-PROXY (Priority 120)
resource "azurerm_network_security_rule" "ne_proxy_allow_squid" {
  provider                    = azurerm.secondary
  name                        = "Allow-INTERNAL-to-SQUID-PROXY"
  priority                    = 120
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "3128", "8080"]
  source_address_prefixes     = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-AZURELB-to-SQUID-PROXY (Priority 130)
resource "azurerm_network_security_rule" "ne_proxy_allow_azurelb_squid" {
  provider                    = azurerm.secondary
  name                        = "Allow-AZURELB-to-SQUID-PROXY"
  priority                    = 130
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3128"
  source_address_prefix       = "AzureLoadBalancer"
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}


# ============================================================================
# NE Proxy Outbound Rules
# ============================================================================

# Allow-NGINX-to-CINTERNAL (Priority 200)
resource "azurerm_network_security_rule" "ne_proxy_allow_nginx_cinternal" {
  provider                    = azurerm.secondary
  name                        = "Allow-NGINX-to-CINTERNAL"
  priority                    = 200
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefix  = "10.150.0.0/16"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-SQUID-to-AFW-WEB (Priority 210)
resource "azurerm_network_security_rule" "ne_proxy_allow_squid_afw" {
  provider                    = azurerm.secondary
  name                        = "Allow-SQUID-to-AFW-WEB"
  priority                    = 210
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefix  = "10.200.60.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-DNS (Priority 230)
resource "azurerm_network_security_rule" "ne_proxy_allow_dns" {
  provider                    = azurerm.secondary
  name                        = "Allow-DNS"
  priority                    = 230
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "53"
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefix  = "AzureDNS"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-UBUNTU-UPDATES-AZURE (Priority 320)
resource "azurerm_network_security_rule" "ne_proxy_allow_ubuntu_azure" {
  provider                     = azurerm.secondary
  name                         = "Allow-UBUNTU-UPDATES-AZURE"
  priority                     = 320
  direction                    = "Outbound"
  access                       = "Allow"
  protocol                     = "Tcp"
  source_port_range            = "*"
  destination_port_ranges      = ["80", "443"]
  source_address_prefix        = "10.200.12.0/26"
  destination_address_prefix   = "Internet"
  resource_group_name          = data.azurerm_resource_group.ne.name
  network_security_group_name  = azurerm_network_security_group.ne_proxy_nsg.name
}


# ============================================================================
# NE RDS NSG (MIP-SI-NE-RDS-NSG) - Subnet: 10.200.12.64/27
# ============================================================================

resource "azurerm_network_security_group" "ne_rds_nsg" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-RDS-NSG"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  tags = merge(
    local.default_tags,
    { Subnet = "RDS", Region = "North Europe" }
  )
}

# ============================================================================
# NE RDS Inbound Rules
# ============================================================================

# Allow-RDS-HTTPS-from-CEFW-NE (Priority 200)
resource "azurerm_network_security_rule" "ne_rds_allow_cefw_inbound" {
  provider                    = azurerm.secondary
  name                        = "Allow-RDS-HTTPS-from-CEFW-NE"
  priority                    = 200
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.60.0/26"
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-UK-VPN-IN (Priority 210)
resource "azurerm_network_security_rule" "ne_rds_allow_uk_vpn" {
  provider                    = azurerm.secondary
  name                        = "Allow-UK-VPN-IN"
  priority                    = 210
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["27.110.72.0/23", "27.110.74.0/24", "27.110.75.0/25", "27.110.75.128/26", "27.110.75.192/27", "27.110.75.224/28", "27.110.75.240/29", "27.110.75.248/30", "27.110.75.252/32", "27.110.76.0/24", "27.110.77.0/25", "27.110.77.128/26", "27.110.77.192/27", "27.110.77.224/28", "27.110.77.240/29", "27.110.77.248/30", "27.110.77.252/32", "27.110.78.0/24", "27.110.79.0/25", "27.110.79.128/26", "27.110.79.192/27", "27.110.79.224/27", "203.112.80.0/20", "161.113.192.0/19"]
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-IND-VPN-IN (Priority 220)
resource "azurerm_network_security_rule" "ne_rds_allow_ind_vpn" {
  provider                    = azurerm.secondary
  name                        = "Allow-IND-VPN-IN"
  priority                    = 220
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["203.171.222.0/29", "203.171.222.8/32", "203.171.222.9/32", "203.171.222.10/32", "203.171.222.12/30", "203.171.222.16/28", "203.171.222.32/27", "203.171.222.64/26", "203.171.222.128/25", "203.171.209.0/29", "203.171.209.8/30", "203.171.209.13/32", "203.171.209.14/32", "203.171.209.15/32", "203.171.209.16/28", "203.171.209.32/27", "203.171.209.64/26", "203.171.209.128/25", "103.171.66.0/27", "103.171.66.32/30", "103.171.66.64/26", "103.171.66.128/25", "103.171.67.0/24", "103.54.135.32/28"]
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-HK-VPN-IN (Priority 230)
resource "azurerm_network_security_rule" "ne_rds_allow_hk_vpn" {
  provider                    = azurerm.secondary
  name                        = "Allow-HK-VPN-IN"
  priority                    = 230
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["91.214.4.0/24", "91.214.5.0/26", "91.214.5.64/28", "91.214.5.80/30", "91.214.5.84/32", "91.214.5.85/32", "91.214.5.88/29", "91.214.5.96/27", "91.214.5.128/25", "91.214.6.0/23", "193.108.72.0/22", "193.108.76.0/26", "193.108.76.64/28", "193.108.76.80/30", "193.108.76.84/32", "193.108.76.85/32", "193.108.76.88/29", "193.108.76.96/27", "193.108.76.128/25", "193.108.77.0/24", "193.108.78.0/23", "161.113.224.0/19"]
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-MGMT-ADMIN-RDS (Priority 270)
resource "azurerm_network_security_rule" "ne_rds_allow_mgmt_admin" {
  provider                    = azurerm.secondary
  name                        = "Allow-MGMT-ADMIN-RDS"
  priority                    = 270
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.150.1.0/24"
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-IN-RDS-INTERNAL (Priority 280)
resource "azurerm_network_security_rule" "ne_rds_allow_internal" {
  provider                    = azurerm.secondary
  name                        = "Allow-IN-RDS-INTERNAL"
  priority                    = 280
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefix       = "10.150.1.0/24"
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-RDPfromRDSWEB-In (Priority 1012)
resource "azurerm_network_security_rule" "ne_rds_allow_rdp_from_rdsweb" {
  provider                    = azurerm.secondary
  name                        = "Allow-RDPfromRDSWEB-In"
  priority                    = 1012
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.0/24"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-RDPfromRDSWEB-In-UDP (Priority 1013)
resource "azurerm_network_security_rule" "ne_rds_allow_rdp_udp_from_rdsweb" {
  provider                    = azurerm.secondary
  name                        = "Allow-RDPfromRDSWEB-In-UDP"
  priority                    = 1013
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.0/24"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow_RDS_Gateway_To_ConnectionBroker (Priority 1014)
resource "azurerm_network_security_rule" "ne_rds_allow_gw_to_connbroker" {
  provider                    = azurerm.secondary
  name                        = "Allow_RDS_Gateway_To_ConnectionBroker"
  priority                    = 1014
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5504"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.0/24"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow_RDS_Internal_WMI_In (Priority 1015)
resource "azurerm_network_security_rule" "ne_rds_allow_internal_wmi" {
  provider                    = azurerm.secondary
  name                        = "Allow_RDS_Internal_WMI_In"
  priority                    = 1015
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.0/24"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow_NetLogon_Internal_RDS (Priority 1016)
resource "azurerm_network_security_rule" "ne_rds_allow_netlogon" {
  provider                    = azurerm.secondary
  name                        = "Allow_NetLogon_Internal_RDS"
  priority                    = 1016
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "137"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.0/24"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-HSBC-DRN-TCP-Inbound02 (Priority 4005)
resource "azurerm_network_security_rule" "ne_rds_allow_drn_tcp_inbound02" {
  provider                    = azurerm.secondary
  name                        = "Allow-HSBC-DRN-TCP-Inbound02"
  priority                    = 4005
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["135", "443", "445", "5000-5100", "49152-65535"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.0/24"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# ============================================================================
# NE RDS Outbound Rules
# ============================================================================

# Allow-SESSIONHOSTS-RDP-TCP (Priority 100)
resource "azurerm_network_security_rule" "ne_rds_allow_sessionhosts_rdp_tcp" {
  provider                     = azurerm.secondary
  name                         = "Allow-SESSIONHOSTS-RDP-TCP"
  priority                     = 100
  direction                    = "Outbound"
  access                       = "Allow"
  protocol                     = "Tcp"
  source_port_range            = "*"
  destination_port_range       = "3389"
  source_address_prefix        = "10.200.12.64/27"
  destination_address_prefixes = ["10.150.1.11", "10.150.1.12", "10.150.1.14"]
  resource_group_name          = data.azurerm_resource_group.ne.name
  network_security_group_name  = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-SESSIONHOSTS-RDP-UDP (Priority 110)
resource "azurerm_network_security_rule" "ne_rds_allow_sessionhosts_rdp_udp" {
  provider                     = azurerm.secondary
  name                         = "Allow-SESSIONHOSTS-RDP-UDP"
  priority                     = 110
  direction                    = "Outbound"
  access                       = "Allow"
  protocol                     = "Udp"
  source_port_range            = "*"
  destination_port_range       = "3389"
  source_address_prefix        = "10.200.12.64/27"
  destination_address_prefixes = ["10.150.1.11", "10.150.1.12", "10.150.1.14"]
  resource_group_name          = data.azurerm_resource_group.ne.name
  network_security_group_name  = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-To-Firewall-Direct (Priority 170)
resource "azurerm_network_security_rule" "ne_rds_allow_firewall_direct" {
  provider                    = azurerm.secondary
  name                        = "Allow-To-Firewall-Direct"
  priority                    = 170
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureFirewall"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-RD-CONNECTIONBROKER (Priority 130)
resource "azurerm_network_security_rule" "ne_rds_allow_connectionbroker" {
  provider                    = azurerm.secondary
  name                        = "Allow-RD-CONNECTIONBROKER"
  priority                    = 130
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5504"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.10"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-RD-WMIDC (Priority 140)
resource "azurerm_network_security_rule" "ne_rds_allow_wmidc" {
  provider                     = azurerm.secondary
  name                         = "Allow-RD-WMIDC"
  priority                     = 140
  direction                    = "Outbound"
  access                       = "Allow"
  protocol                     = "Tcp"
  source_port_range            = "*"
  destination_port_range       = "5985"
  source_address_prefix        = "10.200.12.64/27"
  destination_address_prefixes = ["10.150.0.0/24", "10.150.1.0/24", "10.150.2.0/24"]
  resource_group_name          = data.azurerm_resource_group.ne.name
  network_security_group_name  = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP (Priority 150)
resource "azurerm_network_security_rule" "ne_rds_allow_dc_tcp" {
  provider                    = azurerm.secondary
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP"
  priority                    = 150
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "80", "88", "135", "139", "389", "443", "445", "464", "636", "5000-5100", "49152-65535"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP (Priority 160)
resource "azurerm_network_security_rule" "ne_rds_allow_dc_udp" {
  provider                    = azurerm.secondary
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP"
  priority                    = 160
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "88", "123", "137", "138", "389", "464"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# WSUS-out (Priority 4003)
resource "azurerm_network_security_rule" "ne_rds_wsus_out" {
  provider                    = azurerm.secondary
  name                        = "WSUS-out"
  priority                    = 4003
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["8530", "8531"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.0.0.22"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# AzureCloud-UKTimeSync-Out (Priority 4005)
resource "azurerm_network_security_rule" "ne_rds_time_sync_out" {
  provider                    = azurerm.secondary
  name                        = "AzureCloud-UKTimeSync-Out"
  priority                    = 4005
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "123"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureCloud.ukwest"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-AZUREBACKUP (Priority 4015)
resource "azurerm_network_security_rule" "ne_rds_allow_azurebackup" {
  provider                    = azurerm.secondary
  name                        = "Allow-AZUREBACKUP"
  priority                    = 4015
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureBackup"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-AZUREMONITOR (Priority 4018)
resource "azurerm_network_security_rule" "ne_rds_allow_azuremonitor" {
  provider                    = azurerm.secondary
  name                        = "Allow-AZUREMONITOR"
  priority                    = 4018
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureMonitor"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-MDE (Priority 4019)
resource "azurerm_network_security_rule" "ne_rds_allow_mde" {
  provider                    = azurerm.secondary
  name                        = "Allow-MDE"
  priority                    = 4019
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "MicrosoftDefenderForEndpoint"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-AAD (Priority 4020)
resource "azurerm_network_security_rule" "ne_rds_allow_aad" {
  provider                    = azurerm.secondary
  name                        = "Allow-AAD"
  priority                    = 4020
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureActiveDirectory"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# AllowCrowdStrikeOut (Priority 4012)
# Note: NSG rules do not support FQDN destinations. IPs below are from LLD reference list.
# CrowdStrike traffic is also permitted via Allow-To-Firewall-Direct (priority 170) routing
# through Azure Firewall where FQDN-based CrowdStrike rules (eu-1) are enforced.
resource "azurerm_network_security_rule" "ne_rds_allow_crowdstrike" {
  provider               = azurerm.secondary
  name                   = "AllowCrowdStrikeOut"
  priority               = 4012
  direction              = "Outbound"
  access                 = "Allow"
  protocol               = "Tcp"
  source_port_range      = "*"
  destination_port_range = "443"
  source_address_prefix  = "10.200.12.64/27"
  destination_address_prefixes = [
    "13.56.127.239/32", "13.57.54.63/32", "50.18.194.39/32", "52.52.117.52/32", "52.52.119.33/32",
    "52.52.149.168/32", "52.52.239.58/32", "52.53.77.89/32", "52.8.134.130/32", "52.8.160.82/32",
    "52.8.172.89/32", "52.8.173.58/32", "52.8.19.75/32", "52.8.32.113/32", "52.8.45.162/32",
    "52.8.5.240/32", "52.8.54.244/32", "52.8.61.206/32", "52.9.104.148/32", "52.9.212.176/32",
    "52.9.77.209/32", "52.9.82.94/32", "52.9.87.98/32", "54.183.105.3/32", "54.183.122.156/32",
    "54.183.140.32/32", "54.183.142.105/32", "54.183.148.116/32", "54.183.148.43/32", "54.183.234.42/32",
    "54.183.24.162/32", "54.183.252.86/32", "54.183.34.154/32", "54.183.39.68/32", "54.183.51.31/32",
    "54.183.51.69/32", "54.183.52.221/32", "54.193.117.199/32", "54.193.27.226/32", "54.193.29.47/32",
    "54.193.67.98/32", "54.193.87.57/32", "54.193.90.171/32", "54.193.93.19/32", "54.215.131.232/32",
    "54.215.154.80/32", "54.215.169.199/32", "54.215.169.38/32", "54.215.176.108/32", "54.215.183.157/32",
    "54.215.226.55/32", "54.219.112.243/32", "54.219.115.12/32", "54.219.137.54/32", "54.219.140.50/32",
    "54.219.141.250/32", "54.219.145.181/32", "54.219.147.253/32", "54.219.148.161/32", "54.219.149.89/32",
    "54.219.149.92/32", "54.219.151.1/32", "54.219.151.27/32", "54.219.153.248/32", "54.219.158.53/32",
    "54.219.159.84/32", "54.219.161.141/32", "54.241.138.180/32", "54.241.146.67/32", "54.241.148.127/32",
    "54.241.150.134/32", "54.241.161.60/32", "54.241.162.180/32", "54.241.162.64/32", "54.241.164.212/32",
    "54.241.175.140/32", "54.241.175.52/32", "54.241.179.52/32", "54.241.181.242/32", "54.241.184.161/32",
    "54.241.185.201/32", "54.241.186.124/32", "54.241.197.58/32", "54.67.105.202/32", "54.67.119.89/32",
    "54.67.123.150/32", "54.67.123.234/32", "54.67.26.184/32", "54.67.33.233/32", "54.67.48.56/32",
    "54.67.54.116/32", "54.67.6.201/32", "54.67.68.88/32", "54.67.92.206/32", "54.67.96.255/32",
    "54.67.99.247/32", "13.56.121.58/32", "50.18.198.237/32", "52.8.141.1/32", "54.183.120.141/32",
    "54.183.135.80/32", "54.183.215.154/32", "54.193.86.245/32", "54.215.170.42/32", "54.219.179.25/32",
    "54.241.161.242/32", "54.241.181.78/32", "54.241.182.78/32", "54.241.183.151/32", "54.241.183.229/32",
    "54.241.183.232/32", "54.67.108.17/32", "54.67.114.188/32", "54.67.122.238/32", "54.67.17.131/32",
    "54.67.24.156/32", "54.67.4.108/32", "54.67.41.192/32", "54.67.5.136/32", "54.67.51.32/32",
    "54.67.72.218/32", "54.67.78.134/32"
  ]
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}


# ============================================================================
# WEST EUROPE - App Gateway NSG
# ============================================================================

# ============================================================================
# WE App Gateway NSG (MIP-SI-WE-AppGW-nsg) - Subnet: 10.200.11.160/27
# ============================================================================

resource "azurerm_network_security_group" "we_appgw_nsg" {
  name                = "MIP-SI-WE-AppGW-nsg"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  tags = merge(
    local.default_tags,
    { Subnet = "AppGW", Region = "West Europe" }
  )
}

# ============================================================================
# WE AppGW Inbound Rules
# ============================================================================

# Allow-FD-Backend (Priority 100)
resource "azurerm_network_security_rule" "we_appgw_allow_fd_backend" {
  name                        = "Allow-FD-Backend"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["443", "80"]
  source_address_prefix       = "AzureFrontDoor.Backend"
  destination_address_prefix  = "10.200.11.160/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_appgw_nsg.name
}

# Allow-GatewayManager (Priority 105) - REQUIRED by Azure for AppGW v2 SKU health probes
resource "azurerm_network_security_rule" "we_appgw_allow_gateway_manager" {
  name                        = "Allow-GatewayManager"
  priority                    = 105
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "65200-65535"
  source_address_prefix       = "GatewayManager"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_appgw_nsg.name
}

# Allow-MIP-DevProxyAndRDS-IN (Priority 250)
resource "azurerm_network_security_rule" "we_appgw_allow_dev_proxy_rds" {
  name                        = "Allow-MIP-DevProxyAndRDS-IN"
  priority                    = 250
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["20.71.217.12", "137.135.242.113", "104.45.81.28", "98.71.221.48", "51.145.130.107", "40.69.78.187", "52.232.99.39", "52.178.152.242"]
  destination_address_prefix  = "10.200.11.160/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_appgw_nsg.name
}


# ============================================================================
# WE AppGW Outbound Rules
# ============================================================================

# Allow-SSL-Out (Priority 200)
resource "azurerm_network_security_rule" "we_appgw_allow_ssl_out" {
  name                        = "Allow-SSL-Out"
  priority                    = 200
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "VirtualNetwork"
  destination_address_prefix  = "AzureKeyVault"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_appgw_nsg.name
}

# Allow-AppGW-to-NGINX-Backend (Priority 210)
resource "azurerm_network_security_rule" "we_appgw_allow_nginx_backend" {
  name                        = "Allow-AppGW-to-NGINX-Backend"
  priority                    = 210
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.160/27"
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_appgw_nsg.name
}

# Allow-DNS-Out (Priority 230)
resource "azurerm_network_security_rule" "we_appgw_allow_dns_out" {
  name                        = "Allow-DNS-Out"
  priority                    = 230
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "53"
  source_address_prefix       = "10.200.11.160/27"
  destination_address_prefix  = "AzureDNS"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_appgw_nsg.name
}

# Allow-AzureMonitor-Out (Priority 320)
resource "azurerm_network_security_rule" "we_appgw_allow_azuremonitor_out" {
  name                        = "Allow-AzureMonitor-Out"
  priority                    = 320
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "VirtualNetwork"
  destination_address_prefix  = "AzureMonitor"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_appgw_nsg.name
}


# ============================================================================
# NORTH EUROPE - App Gateway NSG
# ============================================================================

# ============================================================================
# NE App Gateway NSG (MIP-SI-NE-AppGW-nsg) - Subnet: 10.200.12.160/27
# ============================================================================

resource "azurerm_network_security_group" "ne_appgw_nsg" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-AppGW-nsg"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  tags = merge(
    local.default_tags,
    { Subnet = "AppGW", Region = "North Europe" }
  )
}

# ============================================================================
# NE AppGW Inbound Rules
# ============================================================================

# Allow-FD-Backend (Priority 100)
resource "azurerm_network_security_rule" "ne_appgw_allow_fd_backend" {
  provider                    = azurerm.secondary
  name                        = "Allow-FD-Backend"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["443", "80"]
  source_address_prefix       = "AzureFrontDoor.Backend"
  destination_address_prefix  = "10.200.12.160/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_appgw_nsg.name
}

# Allow-GatewayManager (Priority 105) - REQUIRED by Azure for AppGW v2 SKU health probes
resource "azurerm_network_security_rule" "ne_appgw_allow_gateway_manager" {
  provider                    = azurerm.secondary
  name                        = "Allow-GatewayManager"
  priority                    = 105
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "65200-65535"
  source_address_prefix       = "GatewayManager"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_appgw_nsg.name
}

# Allow-MIP-DevProxyAndRDS-IN (Priority 250)
resource "azurerm_network_security_rule" "ne_appgw_allow_dev_proxy_rds" {
  provider                    = azurerm.secondary
  name                        = "Allow-MIP-DevProxyAndRDS-IN"
  priority                    = 250
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["20.71.217.12", "137.135.242.113", "104.45.81.28", "98.71.221.48", "51.145.130.107", "40.69.78.187", "52.232.99.39", "52.178.152.242"]
  destination_address_prefix  = "10.200.12.160/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_appgw_nsg.name
}


# ============================================================================
# NE AppGW Outbound Rules
# ============================================================================

# Allow-SSL-Out (Priority 200)
resource "azurerm_network_security_rule" "ne_appgw_allow_ssl_out" {
  provider                    = azurerm.secondary
  name                        = "Allow-SSL-Out"
  priority                    = 200
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "VirtualNetwork"
  destination_address_prefix  = "AzureKeyVault"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_appgw_nsg.name
}

# Allow-AppGW-to-NGINX-Backend (Priority 210)
resource "azurerm_network_security_rule" "ne_appgw_allow_nginx_backend" {
  provider                    = azurerm.secondary
  name                        = "Allow-AppGW-to-NGINX-Backend"
  priority                    = 210
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.160/27"
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_appgw_nsg.name
}

# Allow-DNS-Out (Priority 230)
resource "azurerm_network_security_rule" "ne_appgw_allow_dns_out" {
  provider                    = azurerm.secondary
  name                        = "Allow-DNS-Out"
  priority                    = 230
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "53"
  source_address_prefix       = "10.200.12.160/27"
  destination_address_prefix  = "AzureDNS"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_appgw_nsg.name
}

# Allow-AzureMonitor-Out (Priority 320)
resource "azurerm_network_security_rule" "ne_appgw_allow_azuremonitor_out" {
  provider                    = azurerm.secondary
  name                        = "Allow-AzureMonitor-Out"
  priority                    = 320
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "VirtualNetwork"
  destination_address_prefix  = "AzureMonitor"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_appgw_nsg.name
}


# ============================================================================
# NSG to Subnet Associations
# Associates each NSG with its target subnet. Existing NSGs with old names
# in Azure must be manually removed after this deployment completes.
# ============================================================================

resource "azurerm_subnet_network_security_group_association" "we_proxy_nsg_assoc" {
  subnet_id                 = data.azurerm_subnet.we_cidmz_proxy_snet.id
  network_security_group_id = azurerm_network_security_group.we_proxy_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "we_rds_nsg_assoc" {
  subnet_id                 = data.azurerm_subnet.we_cidmz_rds_snet.id
  network_security_group_id = azurerm_network_security_group.we_rds_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "we_appgw_nsg_assoc" {
  subnet_id                 = data.azurerm_subnet.we_cidmz_appgw_snet.id
  network_security_group_id = azurerm_network_security_group.we_appgw_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "ne_proxy_nsg_assoc" {
  provider                  = azurerm.secondary
  subnet_id                 = data.azurerm_subnet.ne_cidmz_proxy_snet.id
  network_security_group_id = azurerm_network_security_group.ne_proxy_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "ne_rds_nsg_assoc" {
  provider                  = azurerm.secondary
  subnet_id                 = data.azurerm_subnet.ne_cidmz_rds_snet.id
  network_security_group_id = azurerm_network_security_group.ne_rds_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "ne_appgw_nsg_assoc" {
  provider                  = azurerm.secondary
  subnet_id                 = data.azurerm_subnet.ne_cidmz_appgw_snet.id
  network_security_group_id = azurerm_network_security_group.ne_appgw_nsg.id
}

