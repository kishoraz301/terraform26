﻿# Phase 14: Azure Backup Private Endpoints

# Azure Subscription Configuration
primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"

# Environment
environment = "production"

# CI-DMZ Resource Groups (VNets and subnets)
we_resource_group_name = "MIP-SI-WE-RG"
ne_resource_group_name = "MIP-SI-NE-RG"

# CI-DMZ VNet names
we_cidmz_vnet_name = "MIP-SI-WE-ciDMZ-vnet"
ne_cidmz_vnet_name = "MIP-SI-NE-ciDMZ-vnet"

# Proxy subnets for private endpoints (shared with KV PEs — phase-08)
we_backup_pe_subnet_name = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
ne_backup_pe_subnet_name = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"

# Recovery Services Vaults (confirmed by HSBC infrastructure team)
we_rsv_name              = "SI-Recovery-v2"
we_rsv_resource_group    = "SI-OPS-WE-01-rg"
ne_rsv_name              = "SI-Recovery-NE-v2"
ne_rsv_resource_group    = "SI-OPS-NE-01-rg"

# Private Endpoint resource groups (OPS RGs per LLD 4.3.10)
we_pe_resource_group_name = "SI-OPS-WE-01-rg"
ne_pe_resource_group_name = "SI-OPS-NE-01-rg"