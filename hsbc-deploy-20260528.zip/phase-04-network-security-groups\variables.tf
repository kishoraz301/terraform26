variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
}

variable "primary_subscription_id" {
  description = "Primary subscription ID"
  type        = string
  sensitive   = true
}

variable "secondary_subscription_id" {
  description = "Secondary subscription ID"
  type        = string
  sensitive   = true
}

variable "we_resource_group_name" {
  description = "West Europe Resource Group name"
  type        = string
  default     = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  description = "North Europe Resource Group name"
  type        = string
  default     = "MIP-SI-NE-RG"
}

variable "tags" {
  description = "Additional tags"
  type        = map(string)
  default     = {}
}

# ============================================================================

