# Azure Subscription Configuration
primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"

# Environment
environment = "production"

# Resource Group Names
# Source RGs for subnets + PIPs. AppGW-dedicated RGs are created by main.tf.
we_resource_group_name = "MIP-SI-WE-RG"
ne_resource_group_name = "MIP-SI-NE-RG"

# NE private frontend IP — pending architect confirmation of NE IP plan.
# WE is hardcoded: 10.200.11.170 (confirmed in LLD section 4.3.9).
ne_appgw_private_frontend_ip = "10.200.12.170"

# Managed identities are created by this phase (azurerm_user_assigned_identity).
# Key Vault + role assignments are also managed by this phase.
# Upload certificates to each vault BEFORE running full apply.

# HTTPS listeners — 9 domains (prod + non-prod), one listener per FQDN.
# Cert naming convention: cert-<subdomain>-<env> (must match Key Vault certificate names).
# WAF policies auto-assigned by hostname regex in locals (main.tf):
#   WAF-LMS     → sendvaluerupdate FQDNs
#   WAF-HSBCPAPI → ecot* / devecot* FQDNs
# HTTP redirect rules use priority + 200 automatically (see locals in main.tf).
we_https_listeners = [
  # --- Production ---
  {
    hostname  = "notifyadvresultready.intermediaries.hsbc.co.uk"
    cert_name = "cert-notifyadvresultready-prod"
    priority  = 10
  },
  {
    hostname  = "ecotgetpropertydetails.intermediaries.hsbc.co.uk"
    cert_name = "cert-ecotgetpropertydetails-prod"
    priority  = 20
  },
  {
    hostname  = "ecotnotifypaymentsanction.intermediaries.hsbc.co.uk"
    cert_name = "cert-ecotnotifypaymentsanction-prod"
    priority  = 30
  },
  {
    hostname  = "sendvaluerupdate.intermediaries.hsbc.co.uk"
    cert_name = "cert-sendvaluerupdate-prod"
    priority  = 40
  },
  # --- SIT1 (non-prod) ---
  {
    hostname  = "notifyadvresultready.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-notifyadvresultready-sit1"
    priority  = 50
  },
  {
    hostname  = "sendvaluerupdate.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-sendvaluerupdate-sit1"
    priority  = 60
  },
  {
    hostname  = "devecotgetpropertydetails.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-devecotgetpropertydetails-sit1"
    priority  = 70
  },
  {
    hostname  = "devecotnotifypaymentsanction.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-devecotnotifypaymentsanction-sit1"
    priority  = 80
  },
  # --- UAT (non-prod) ---
  {
    hostname  = "sendvaluerupdate.intermediaries-uat.hsbc.co.uk"
    cert_name = "cert-sendvaluerupdate-uat"
    priority  = 90
  },
  # --- SIT2 (non-prod) ---
  {
    hostname  = "notifyadvresultready-st4.intermediaries-sit2.hsbc.co.uk"
    cert_name = "cert-notifyadvresultready-st4-sit2"
    priority  = 100
  },
]

ne_https_listeners = [
  # Mirror of WE — same 9 FQDNs, certs from SI-Core-Vault-NE-51
  {
    hostname  = "notifyadvresultready.intermediaries.hsbc.co.uk"
    cert_name = "cert-notifyadvresultready-prod"
    priority  = 10
  },
  {
    hostname  = "ecotgetpropertydetails.intermediaries.hsbc.co.uk"
    cert_name = "cert-ecotgetpropertydetails-prod"
    priority  = 20
  },
  {
    hostname  = "ecotnotifypaymentsanction.intermediaries.hsbc.co.uk"
    cert_name = "cert-ecotnotifypaymentsanction-prod"
    priority  = 30
  },
  {
    hostname  = "sendvaluerupdate.intermediaries.hsbc.co.uk"
    cert_name = "cert-sendvaluerupdate-prod"
    priority  = 40
  },
  {
    hostname  = "notifyadvresultready.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-notifyadvresultready-sit1"
    priority  = 50
  },
  {
    hostname  = "sendvaluerupdate.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-sendvaluerupdate-sit1"
    priority  = 60
  },
  {
    hostname  = "devecotgetpropertydetails.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-devecotgetpropertydetails-sit1"
    priority  = 70
  },
  {
    hostname  = "devecotnotifypaymentsanction.intermediaries-sit1.hsbc.co.uk"
    cert_name = "cert-devecotnotifypaymentsanction-sit1"
    priority  = 80
  },
  {
    hostname  = "sendvaluerupdate.intermediaries-uat.hsbc.co.uk"
    cert_name = "cert-sendvaluerupdate-uat"
    priority  = 90
  },
  {
    hostname  = "notifyadvresultready-st4.intermediaries-sit2.hsbc.co.uk"
    cert_name = "cert-notifyadvresultready-st4-sit2"
    priority  = 100
  },
]

# Tags — add all mandatory HSBC governance tags here.
tags = {
  Environment = "Production"
  Phase       = "08-application-gateways"
}
