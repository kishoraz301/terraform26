﻿output "we_appgw_id" {
  value = azurerm_application_gateway.we_appgw.id
}

output "we_appgw_name" {
  value = azurerm_application_gateway.we_appgw.name
}

output "we_waf_policy_id" {
  value = azurerm_web_application_firewall_policy.we_waf_policy.id
}

output "we_appgw_identity_principal_id" {
  description = "Principal ID for role assignment: Key Vault Secrets User on SI-Core-Vault-WE-01"
  value       = data.azurerm_user_assigned_identity.we_appgw_identity.principal_id
}

output "ne_appgw_id" {
  value = azurerm_application_gateway.ne_appgw.id
}

output "ne_appgw_name" {
  value = azurerm_application_gateway.ne_appgw.name
}

output "ne_waf_policy_id" {
  value = azurerm_web_application_firewall_policy.ne_waf_policy.id
}

output "ne_appgw_identity_principal_id" {
  description = "Principal ID for role assignment: Key Vault Secrets User on SI-Core-Vault-NE-51"
  value       = data.azurerm_user_assigned_identity.ne_appgw_identity.principal_id
}

output "we_kv_id" {
  value = data.azurerm_key_vault.we_kv.id
}

output "we_kv_uri" {
  value = data.azurerm_key_vault.we_kv.vault_uri
}

output "ne_kv_id" {
  value = data.azurerm_key_vault.ne_kv.id
}

output "ne_kv_uri" {
  value = data.azurerm_key_vault.ne_kv.vault_uri
}

