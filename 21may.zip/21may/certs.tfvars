# Certificate mappings — populate AFTER certs are uploaded to Key Vault.
#
# Apply with:  terraform apply -var-file=certs.tfvars
# (Do NOT include this file until certs are physically present in each vault.)
#
# Upload each cert to the vault first:
#   az keyvault certificate import --vault-name SI-Core-Vault-WE-01 \
#     --name cert-<name> --file <cert>.pfx --password <pwd>
#
# Key Vault URI format: https://<vault>.vault.azure.net/secrets/<cert-name>
# (Use the /secrets/ prefix, not /certificates/ — AppGW requires the secret version.)

we_cert_map = {
  "cert-notifyadvresultready-prod"         = "https://si-core-vault-we-01.vault.azure.net/secrets/NotifyAdvResultReadyintermediaries"
  "cert-ecotgetpropertydetails-prod"       = "https://si-core-vault-we-01.vault.azure.net/secrets/ecotgetpropertydetailsintermediaries"
  "cert-ecotnotifypaymentsanction-prod"    = "https://si-core-vault-we-01.vault.azure.net/secrets/ecotnotifypaymentsanctionintermediaries"
  "cert-sendvaluerupdate-prod"             = "https://si-core-vault-we-01.vault.azure.net/secrets/sendvaluerupdateintermediaries"
  "cert-notifyadvresultready-sit1"         = "https://si-core-vault-we-01.vault.azure.net/secrets/NotifyAdvResultReadyintermediaries-sit1"
  "cert-sendvaluerupdate-sit1"             = "https://si-core-vault-we-01.vault.azure.net/secrets/SendValuerUpdateintermediaries-sit1"
  # cert-devecotgetpropertydetails-sit1 and cert-devecotnotifypaymentsanction-sit1 pending upload — add and re-apply when ready
  "cert-sendvaluerupdate-uat"              = "https://si-core-vault-we-01.vault.azure.net/secrets/SendValuerUpdateintermediaries-uat"
  "cert-notifyadvresultready-st4-sit2"     = "https://si-core-vault-we-01.vault.azure.net/secrets/NotifyAdvResultReady-ST4intermediaries-sit2"
}

ne_cert_map = {
  "cert-notifyadvresultready-prod"         = "https://si-core-vault-ne-51.vault.azure.net/secrets/NotifyAdvResultReadyintermediaries"
  "cert-ecotgetpropertydetails-prod"       = "https://si-core-vault-ne-51.vault.azure.net/secrets/ecotgetpropertydetailsintermediaries"
  "cert-ecotnotifypaymentsanction-prod"    = "https://si-core-vault-ne-51.vault.azure.net/secrets/ecotnotifypaymentsanctionintermediaries"
  "cert-sendvaluerupdate-prod"             = "https://si-core-vault-ne-51.vault.azure.net/secrets/sendvaluerupdateintermediaries"
  "cert-notifyadvresultready-sit1"         = "https://si-core-vault-ne-51.vault.azure.net/secrets/NotifyAdvResultReadyintermediaries-sit1"
  "cert-sendvaluerupdate-sit1"             = "https://si-core-vault-ne-51.vault.azure.net/secrets/SendValuerUpdateintermediaries-sit1"
  # cert-devecotgetpropertydetails-sit1 and cert-devecotnotifypaymentsanction-sit1 pending upload — add and re-apply when ready
  "cert-sendvaluerupdate-uat"              = "https://si-core-vault-ne-51.vault.azure.net/secrets/SendValuerUpdateintermediaries-uat"
  "cert-notifyadvresultready-st4-sit2"     = "https://si-core-vault-ne-51.vault.azure.net/secrets/NotifyAdvResultReady-ST4intermediaries-sit2"
}
