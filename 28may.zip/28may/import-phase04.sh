#!/bin/bash
# import-phase04.sh
# Imports all existing NSG resources into Terraform state.
# Failures are silenced (|| true) — rules not yet in Azure will simply be
# created by the subsequent terraform apply.
#
# Run from: ~/landing-zone-deploy/phase-04-network-security-groups
# Usage:    bash ../import-phase04.sh

set -uo pipefail

SUB="9bde6346-5250-49f9-a010-3ac07609cb70"
WE_RG="MIP-SI-WE-RG"
NE_RG="MIP-SI-NE-RG"
WE_VNET="MIP-SI-WE-ciDMZ-vnet"
NE_VNET="MIP-SI-NE-ciDMZ-vnet"

imp() {
  local addr="$1" id="$2"
  echo "Importing: $addr"
  terraform import "$addr" "$id" 2>&1 | tail -1
}

# ── NSGs ──────────────────────────────────────────────────────────────────────
imp azurerm_network_security_group.we_proxy_nsg \
  "/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-WE-ciDMZ-Proxy-nsg" || true

imp azurerm_network_security_group.we_rds_nsg \
  "/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-WE-RDS-NSG" || true

imp azurerm_network_security_group.we_appgw_nsg \
  "/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-WE-AppGW-nsg" || true

imp azurerm_network_security_group.ne_proxy_nsg \
  "/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-NE-ciDMZ-Proxy-nsg" || true

imp azurerm_network_security_group.ne_rds_nsg \
  "/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-NE-RDS-NSG" || true

imp azurerm_network_security_group.ne_appgw_nsg \
  "/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-NE-AppGW-nsg" || true

# ── WE Proxy rules ────────────────────────────────────────────────────────────
WE_PROXY_BASE="/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-WE-ciDMZ-Proxy-nsg/securityRules"
imp azurerm_network_security_rule.we_proxy_allow_ssh              "$WE_PROXY_BASE/Allow-LINUX-SSH" || true
imp azurerm_network_security_rule.we_proxy_allow_nginx_https      "$WE_PROXY_BASE/Allow-NGINX-HTTPS" || true
imp azurerm_network_security_rule.we_proxy_allow_squid            "$WE_PROXY_BASE/Allow-INTERNAL-to-SQUID-PROXY" || true
imp azurerm_network_security_rule.we_proxy_allow_azurelb_squid    "$WE_PROXY_BASE/Allow-AZURELB-to-SQUID-PROXY" || true
imp azurerm_network_security_rule.we_proxy_allow_nginx_cinternal  "$WE_PROXY_BASE/Allow-NGINX-to-CINTERNAL" || true
imp azurerm_network_security_rule.we_proxy_allow_squid_afw        "$WE_PROXY_BASE/Allow-SQUID-to-AFW-WEB" || true
imp azurerm_network_security_rule.we_proxy_allow_dns              "$WE_PROXY_BASE/Allow-DNS" || true
imp azurerm_network_security_rule.we_proxy_allow_ubuntu_azure     "$WE_PROXY_BASE/Allow-UBUNTU-UPDATES-AZURE" || true

# ── WE RDS rules ──────────────────────────────────────────────────────────────
WE_RDS_BASE="/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-WE-RDS-NSG/securityRules"
imp azurerm_network_security_rule.we_rds_allow_cefw_inbound          "$WE_RDS_BASE/Allow-RDS-HTTPS-from-CEFW-WE" || true
imp azurerm_network_security_rule.we_rds_allow_uk_vpn                "$WE_RDS_BASE/Allow-UK-VPN-IN" || true
imp azurerm_network_security_rule.we_rds_allow_ind_vpn               "$WE_RDS_BASE/Allow-IND-VPN-IN" || true
imp azurerm_network_security_rule.we_rds_allow_hk_vpn                "$WE_RDS_BASE/Allow-HK-VPN-IN" || true
imp azurerm_network_security_rule.we_rds_allow_mgmt_admin            "$WE_RDS_BASE/Allow-MGMT-ADMIN-RDS" || true
imp azurerm_network_security_rule.we_rds_allow_internal              "$WE_RDS_BASE/Allow-IN-RDS-INTERNAL" || true
imp azurerm_network_security_rule.we_rds_allow_rdp_from_rdsweb       "$WE_RDS_BASE/Allow-RDPfromRDSWEB-In" || true
imp azurerm_network_security_rule.we_rds_allow_rdp_udp_from_rdsweb   "$WE_RDS_BASE/Allow-RDPfromRDSWEB-In-UDP" || true
imp azurerm_network_security_rule.we_rds_allow_gw_to_connbroker      "$WE_RDS_BASE/Allow_RDS_Gateway_To_ConnectionBroker" || true
imp azurerm_network_security_rule.we_rds_allow_internal_wmi          "$WE_RDS_BASE/Allow_RDS_Internal_WMI_In" || true
imp azurerm_network_security_rule.we_rds_allow_netlogon              "$WE_RDS_BASE/Allow_NetLogon_Internal_RDS" || true
imp azurerm_network_security_rule.we_rds_allow_drn_tcp_inbound02     "$WE_RDS_BASE/Allow-HSBC-DRN-TCP-Inbound02" || true
imp azurerm_network_security_rule.we_rds_allow_sessionhosts_rdp_tcp  "$WE_RDS_BASE/Allow-SESSIONHOSTS-RDP-TCP" || true
imp azurerm_network_security_rule.we_rds_allow_sessionhosts_rdp_udp  "$WE_RDS_BASE/Allow-SESSIONHOSTS-RDP-UDP" || true
imp azurerm_network_security_rule.we_rds_allow_firewall_direct       "$WE_RDS_BASE/Allow-To-Firewall-Direct" || true
imp azurerm_network_security_rule.we_rds_allow_connectionbroker      "$WE_RDS_BASE/Allow-RD-CONNECTIONBROKER" || true
imp azurerm_network_security_rule.we_rds_allow_wmidc                 "$WE_RDS_BASE/Allow-RD-WMIDC" || true
imp azurerm_network_security_rule.we_rds_allow_dc_tcp                "$WE_RDS_BASE/Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP" || true
imp azurerm_network_security_rule.we_rds_allow_dc_udp                "$WE_RDS_BASE/Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP" || true
imp azurerm_network_security_rule.we_rds_wsus_out                    "$WE_RDS_BASE/WSUS-out" || true
imp azurerm_network_security_rule.we_rds_time_sync_out               "$WE_RDS_BASE/AzureCloud-UKTimeSync-Out" || true
imp azurerm_network_security_rule.we_rds_allow_azurebackup           "$WE_RDS_BASE/Allow-AZUREBACKUP" || true
imp azurerm_network_security_rule.we_rds_allow_azuremonitor          "$WE_RDS_BASE/Allow-AZUREMONITOR" || true
imp azurerm_network_security_rule.we_rds_allow_mde                   "$WE_RDS_BASE/Allow-MDE" || true
imp azurerm_network_security_rule.we_rds_allow_aad                   "$WE_RDS_BASE/Allow-AAD" || true
imp azurerm_network_security_rule.we_rds_allow_crowdstrike           "$WE_RDS_BASE/AllowCrowdStrikeOut" || true

# ── WE AppGW rules ────────────────────────────────────────────────────────────
WE_APPGW_BASE="/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-WE-AppGW-nsg/securityRules"
imp azurerm_network_security_rule.we_appgw_allow_fd_backend         "$WE_APPGW_BASE/Allow-FD-Backend" || true
imp azurerm_network_security_rule.we_appgw_allow_gateway_manager    "$WE_APPGW_BASE/Allow-GatewayManager" || true
imp azurerm_network_security_rule.we_appgw_allow_dev_proxy_rds      "$WE_APPGW_BASE/Allow-MIP-DevProxyAndRDS-IN" || true
imp azurerm_network_security_rule.we_appgw_allow_ssl_out            "$WE_APPGW_BASE/Allow-SSL-Out" || true
imp azurerm_network_security_rule.we_appgw_allow_nginx_backend      "$WE_APPGW_BASE/Allow-AppGW-to-NGINX-Backend" || true
imp azurerm_network_security_rule.we_appgw_allow_dns_out            "$WE_APPGW_BASE/Allow-DNS-Out" || true
imp azurerm_network_security_rule.we_appgw_allow_azuremonitor_out   "$WE_APPGW_BASE/Allow-AzureMonitor-Out" || true

# ── NE Proxy rules ────────────────────────────────────────────────────────────
NE_PROXY_BASE="/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-NE-ciDMZ-Proxy-nsg/securityRules"
imp azurerm_network_security_rule.ne_proxy_allow_ssh              "$NE_PROXY_BASE/Allow-LINUX-SSH" || true
imp azurerm_network_security_rule.ne_proxy_allow_nginx_https      "$NE_PROXY_BASE/Allow-NGINX-HTTPS" || true
imp azurerm_network_security_rule.ne_proxy_allow_squid            "$NE_PROXY_BASE/Allow-INTERNAL-to-SQUID-PROXY" || true
imp azurerm_network_security_rule.ne_proxy_allow_azurelb_squid    "$NE_PROXY_BASE/Allow-AZURELB-to-SQUID-PROXY" || true
imp azurerm_network_security_rule.ne_proxy_allow_nginx_cinternal  "$NE_PROXY_BASE/Allow-NGINX-to-CINTERNAL" || true
imp azurerm_network_security_rule.ne_proxy_allow_squid_afw        "$NE_PROXY_BASE/Allow-SQUID-to-AFW-WEB" || true
imp azurerm_network_security_rule.ne_proxy_allow_dns              "$NE_PROXY_BASE/Allow-DNS" || true
imp azurerm_network_security_rule.ne_proxy_allow_ubuntu_azure     "$NE_PROXY_BASE/Allow-UBUNTU-UPDATES-AZURE" || true

# ── NE RDS rules ──────────────────────────────────────────────────────────────
NE_RDS_BASE="/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-NE-RDS-NSG/securityRules"
imp azurerm_network_security_rule.ne_rds_allow_cefw_inbound          "$NE_RDS_BASE/Allow-RDS-HTTPS-from-CEFW-NE" || true
imp azurerm_network_security_rule.ne_rds_allow_uk_vpn                "$NE_RDS_BASE/Allow-UK-VPN-IN" || true
imp azurerm_network_security_rule.ne_rds_allow_ind_vpn               "$NE_RDS_BASE/Allow-IND-VPN-IN" || true
imp azurerm_network_security_rule.ne_rds_allow_hk_vpn                "$NE_RDS_BASE/Allow-HK-VPN-IN" || true
imp azurerm_network_security_rule.ne_rds_allow_mgmt_admin            "$NE_RDS_BASE/Allow-MGMT-ADMIN-RDS" || true
imp azurerm_network_security_rule.ne_rds_allow_internal              "$NE_RDS_BASE/Allow-IN-RDS-INTERNAL" || true
imp azurerm_network_security_rule.ne_rds_allow_rdp_from_rdsweb       "$NE_RDS_BASE/Allow-RDPfromRDSWEB-In" || true
imp azurerm_network_security_rule.ne_rds_allow_rdp_udp_from_rdsweb   "$NE_RDS_BASE/Allow-RDPfromRDSWEB-In-UDP" || true
imp azurerm_network_security_rule.ne_rds_allow_gw_to_connbroker      "$NE_RDS_BASE/Allow_RDS_Gateway_To_ConnectionBroker" || true
imp azurerm_network_security_rule.ne_rds_allow_internal_wmi          "$NE_RDS_BASE/Allow_RDS_Internal_WMI_In" || true
imp azurerm_network_security_rule.ne_rds_allow_netlogon              "$NE_RDS_BASE/Allow_NetLogon_Internal_RDS" || true
imp azurerm_network_security_rule.ne_rds_allow_drn_tcp_inbound02     "$NE_RDS_BASE/Allow-HSBC-DRN-TCP-Inbound02" || true
imp azurerm_network_security_rule.ne_rds_allow_sessionhosts_rdp_tcp  "$NE_RDS_BASE/Allow-SESSIONHOSTS-RDP-TCP" || true
imp azurerm_network_security_rule.ne_rds_allow_sessionhosts_rdp_udp  "$NE_RDS_BASE/Allow-SESSIONHOSTS-RDP-UDP" || true
imp azurerm_network_security_rule.ne_rds_allow_firewall_direct       "$NE_RDS_BASE/Allow-To-Firewall-Direct" || true
imp azurerm_network_security_rule.ne_rds_allow_connectionbroker      "$NE_RDS_BASE/Allow-RD-CONNECTIONBROKER" || true
imp azurerm_network_security_rule.ne_rds_allow_wmidc                 "$NE_RDS_BASE/Allow-RD-WMIDC" || true
imp azurerm_network_security_rule.ne_rds_allow_dc_tcp                "$NE_RDS_BASE/Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP" || true
imp azurerm_network_security_rule.ne_rds_allow_dc_udp                "$NE_RDS_BASE/Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP" || true
imp azurerm_network_security_rule.ne_rds_wsus_out                    "$NE_RDS_BASE/WSUS-out" || true
imp azurerm_network_security_rule.ne_rds_time_sync_out               "$NE_RDS_BASE/AzureCloud-UKTimeSync-Out" || true
imp azurerm_network_security_rule.ne_rds_allow_azurebackup           "$NE_RDS_BASE/Allow-AZUREBACKUP" || true
imp azurerm_network_security_rule.ne_rds_allow_azuremonitor          "$NE_RDS_BASE/Allow-AZUREMONITOR" || true
imp azurerm_network_security_rule.ne_rds_allow_mde                   "$NE_RDS_BASE/Allow-MDE" || true
imp azurerm_network_security_rule.ne_rds_allow_aad                   "$NE_RDS_BASE/Allow-AAD" || true
imp azurerm_network_security_rule.ne_rds_allow_crowdstrike           "$NE_RDS_BASE/AllowCrowdStrikeOut" || true

# ── NE AppGW rules ────────────────────────────────────────────────────────────
NE_APPGW_BASE="/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/networkSecurityGroups/MIP-SI-NE-AppGW-nsg/securityRules"
imp azurerm_network_security_rule.ne_appgw_allow_fd_backend         "$NE_APPGW_BASE/Allow-FD-Backend" || true
imp azurerm_network_security_rule.ne_appgw_allow_gateway_manager    "$NE_APPGW_BASE/Allow-GatewayManager" || true
imp azurerm_network_security_rule.ne_appgw_allow_dev_proxy_rds      "$NE_APPGW_BASE/Allow-MIP-DevProxyAndRDS-IN" || true
imp azurerm_network_security_rule.ne_appgw_allow_ssl_out            "$NE_APPGW_BASE/Allow-SSL-Out" || true
imp azurerm_network_security_rule.ne_appgw_allow_nginx_backend      "$NE_APPGW_BASE/Allow-AppGW-to-NGINX-Backend" || true
imp azurerm_network_security_rule.ne_appgw_allow_dns_out            "$NE_APPGW_BASE/Allow-DNS-Out" || true
imp azurerm_network_security_rule.ne_appgw_allow_azuremonitor_out   "$NE_APPGW_BASE/Allow-AzureMonitor-Out" || true

# ── Subnet NSG associations ───────────────────────────────────────────────────
imp azurerm_subnet_network_security_group_association.we_proxy_nsg_assoc \
  "/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/virtualNetworks/$WE_VNET/subnets/MIP-SI-WE-ciDMZ-Proxy-dmz-snet" || true

imp azurerm_subnet_network_security_group_association.we_rds_nsg_assoc \
  "/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/virtualNetworks/$WE_VNET/subnets/MIP-SI-WE-ciDMZ-RDS-snet" || true

imp azurerm_subnet_network_security_group_association.we_appgw_nsg_assoc \
  "/subscriptions/$SUB/resourceGroups/$WE_RG/providers/Microsoft.Network/virtualNetworks/$WE_VNET/subnets/MIP-SI-WE-ciDMZ-AppGW-snet" || true

imp azurerm_subnet_network_security_group_association.ne_proxy_nsg_assoc \
  "/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/virtualNetworks/$NE_VNET/subnets/MIP-SI-NE-ciDMZ-Proxy-dmz-snet" || true

imp azurerm_subnet_network_security_group_association.ne_rds_nsg_assoc \
  "/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/virtualNetworks/$NE_VNET/subnets/MIP-SI-NE-ciDMZ-RDS-snet" || true

imp azurerm_subnet_network_security_group_association.ne_appgw_nsg_assoc \
  "/subscriptions/$SUB/resourceGroups/$NE_RG/providers/Microsoft.Network/virtualNetworks/$NE_VNET/subnets/MIP-SI-NE-ciDMZ-AppGW-snet" || true

echo ""
echo "Import complete. Now run: terraform plan -out=phase04.tfplan"
echo "Only genuinely new rules will appear as 'to add'."
