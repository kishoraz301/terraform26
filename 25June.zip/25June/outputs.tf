# Outstanding Item 03: Firewall Rules Configuration Outputs

output "dnat_rules_summary" {
  description = "DNAT Rules configured for RDS publishing"
  value = {
    west_europe = {
      rule_1 = "DNAT-RDS-HTTPS443-UK (UK VPN → RDS ILB)"
      rule_2 = "DNAT-RDS-HTTPS443-IND (India VPN → RDS ILB)"
      rule_3 = "DNAT-RDS-HTTPS443-HK (HK/China VPN → RDS ILB)"
    }
    north_europe = {
      rule_1 = "DNAT-RDS-HTTPS443-UK-NE (UK VPN → RDS ILB)"
      rule_2 = "DNAT-RDS-HTTPS443-IND-NE (India VPN → RDS ILB)"
      rule_3 = "DNAT-RDS-HTTPS443-HK-NE (HK/China VPN → RDS ILB)"
    }
  }
}

output "outbound_app_rules_summary" {
  description = "Outbound Application Rules configured"
  value = {
    rules_per_region = 9
    coverage = {
      business_apps     = "29 FQDNs whitelisted"
      ubuntu_updates    = "OS security updates"
      tls_validation    = "CRL/OCSP endpoints"
      aad_graph         = "Entra ID and Graph API"
      crowdstrike       = "Falcon sensor connectivity"
      tools_platform    = "DevOps and monitoring tools"
      azure_monitor     = "Firewall diagnostics and logs"
      rds_control_plane = "RDS broker communication"
      log_analytics     = "DMZ logs to Log Analytics"
    }
  }
}

output "next_steps" {
  description = "Instructions to verify and proceed"
  value = {
    step_1 = "Verify DNAT rules appear in Azure Portal"
    step_2 = "Verify Application rules appear in Firewall Policy"
    step_3 = "Verify RDS DNAT path from VPN ranges"
    step_4 = "Verify outbound traffic flows for business apps"
    step_5 = "Check firewall logs in Log Analytics"
    step_6 = "Proceed to outstanding/04-appgw-waf-integration"
  }
}
