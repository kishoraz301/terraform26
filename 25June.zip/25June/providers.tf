terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"
  features {}
}
