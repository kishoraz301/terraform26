# Standard Firewall Policies - LLD Compliant Structure (CI DMZ)
# WE = West Europe, NE = North Europe
# Separate region-specific policies: SI-CIDMZ-FWPLCY-STD-WE and SI-CIDMZ-FWPLCY-STD-NE

# ============================================================================
# DATA SOURCES
# ============================================================================

data "azurerm_resource_group" "cidmz_we" {
  name = "MIP-SI-WE-RG"
}

data "azurerm_resource_group" "cidmz_ne" {
  name = "MIP-SI-NE-RG"
}

# ============================================================================
# IP GROUPS - CI DMZ Standard Firewall
# ============================================================================

resource "azurerm_ip_group" "ipg_ci_devops_agents" {
  name                = "IPG-CI-DEVOPS-AGENTS"
  location            = data.azurerm_resource_group.cidmz_ne.location
  resource_group_name = data.azurerm_resource_group.cidmz_ne.name
  cidrs = [
    "13.107.6.0/24", "13.107.9.0/24", "13.107.42.0/24", "13.107.43.0/24",
    "150.171.22.0/24", "150.171.23.0/24", "150.171.73.0/24", "150.171.74.0/24",
    "150.171.75.0/24", "150.171.76.0/24"
  ]
}

resource "azurerm_ip_group" "ipg_crowdstrike" {
  name                = "IPG-CROWDSTRIKE"
  location            = data.azurerm_resource_group.cidmz_ne.location
  resource_group_name = data.azurerm_resource_group.cidmz_ne.name
  cidrs = [
    "13.56.127.239", "13.57.54.63", "50.18.194.39", "52.52.117.52", "52.52.119.33", "52.52.149.168", "52.52.239.58", "52.53.77.89",
    "52.8.134.130", "52.8.160.82", "52.8.172.89", "52.8.173.58", "52.8.19.75", "52.8.32.113", "52.8.45.162", "52.8.5.240",
    "52.8.54.244", "52.8.61.206", "52.9.104.148", "52.9.212.176", "52.9.77.209", "52.9.82.94", "52.9.87.98",
    "54.183.105.3", "54.183.122.156", "54.183.140.32", "54.183.142.105", "54.183.148.116", "54.183.148.43", "54.183.234.42", "54.183.24.162",
    "54.183.252.86", "54.183.34.154", "54.183.39.68", "54.183.51.31", "54.183.51.69", "54.183.52.221",
    "54.193.117.199", "54.193.27.226", "54.193.29.47", "54.193.67.98", "54.193.87.57", "54.193.90.171", "54.193.93.19",
    "54.215.131.232", "54.215.154.80", "54.215.169.199", "54.215.169.38", "54.215.176.108", "54.215.183.157", "54.215.226.55",
    "54.219.112.243", "54.219.115.12", "54.219.137.54", "54.219.140.50", "54.219.141.250", "54.219.145.181", "54.219.147.253", "54.219.148.161",
    "54.219.149.89", "54.219.149.92", "54.219.151.1", "54.219.151.27", "54.219.153.248", "54.219.158.53", "54.219.159.84", "54.219.161.141",
    "54.241.138.180", "54.241.146.67", "54.241.148.127", "54.241.150.134", "54.241.161.60", "54.241.162.180", "54.241.162.64", "54.241.164.212",
    "54.241.175.140", "54.241.175.52", "54.241.179.52", "54.241.181.242", "54.241.184.161", "54.241.185.201", "54.241.186.124", "54.241.197.58",
    "54.67.105.202", "54.67.119.89", "54.67.123.150", "54.67.123.234", "54.67.26.184", "54.67.33.233", "54.67.48.56", "54.67.54.116",
    "54.67.6.201", "54.67.68.88", "54.67.92.206", "54.67.96.255", "54.67.99.247",
    "13.56.121.58", "50.18.198.237", "52.8.141.1",
    "54.183.120.141", "54.183.135.80", "54.183.215.154", "54.193.86.245", "54.215.170.42", "54.219.179.25",
    "54.241.161.242", "54.241.181.78", "54.241.182.78", "54.241.183.151", "54.241.183.229", "54.241.183.232",
    "54.67.108.17", "54.67.114.188", "54.67.122.238", "54.67.17.131", "54.67.24.156", "54.67.4.108", "54.67.41.192", "54.67.5.136",
    "54.67.51.32", "54.67.72.218", "54.67.78.134"
  ]
}

# ============================================================================
# STANDARD FIREWALL POLICIES
# ============================================================================

resource "azurerm_firewall_policy" "std_we_policy" {
  name                = "SI-CIDMZ-FWPLCY-STD-WE"
  location            = data.azurerm_resource_group.cidmz_we.location
  resource_group_name = data.azurerm_resource_group.cidmz_we.name
  sku                 = "Standard"
}

resource "azurerm_firewall_policy" "std_ne_policy" {
  name                = "SI-CIDMZ-FWPLCY-STD-NE"
  location            = data.azurerm_resource_group.cidmz_ne.location
  resource_group_name = data.azurerm_resource_group.cidmz_ne.name
  sku                 = "Standard"
}

# ============================================================================
# WEST EUROPE - PRIORITY 21000: INBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_we_rcg_inbound" {
  name               = "RCG-CI-WE-IN-NET-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_we_policy.id
  priority           = 21000

  network_rule_collection {
    name     = "RC-CI-WE-IN-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "IN-CE2CI-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.50.0/26"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-INTERNAL2CI-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.100.0.0/16"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-ILB-HEALTH-PROBES"
      protocols             = ["TCP"]
      source_addresses      = ["168.63.129.16/32"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["65200-65535"]
    }

    rule {
      name                  = "IN-DNS-FROM-INFRA"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.0.0/16", "10.100.0.0/16"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["53"]
    }

    rule {
      name                  = "IN-MGMT-JIT-ADMIN"
      protocols             = ["TCP"]
      source_ip_groups      = [azurerm_ip_group.ipg_uk_vpn.id, azurerm_ip_group.ipg_ind_vpn.id, azurerm_ip_group.ipg_hk_vpn.id]
      destination_addresses = ["10.200.11.96/26"]
      destination_ports     = ["22", "3389"]
    }
  }

  network_rule_collection {
    name     = "RC-CI-WE-IN-DENY-ALL"
    priority = 4096
    action   = "Deny"

    rule {
      name                  = "IN-DENY-ALL"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["*"]
      destination_addresses = ["*"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# WEST EUROPE - PRIORITY 21100: OUTBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_we_rcg_out_net" {
  name               = "RCG-CI-WE-OUT-NET-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_we_policy.id
  priority           = 21100

  network_rule_collection {
    name     = "RC-CI-WE-OUT-NET-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "OUT-INTERNAL-TO-CE-FW"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.100.0.0/16"]
      destination_addresses = ["10.200.50.10"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# WEST EUROPE - PRIORITY 21200: OUTBOUND APPLICATION RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_we_rcg_out_app" {
  name               = "RCG-CI-WE-OUT-APP-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_we_policy.id
  priority           = 21200

  application_rule_collection {
    name     = "RC-CI-WE-OUT-APP-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name              = "OUT-ENTRA-ID"
      source_addresses  = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["login.microsoftonline.com", "graph.microsoft.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-CONTROL-PLANE"
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureCloud"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-MONITOR"
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name              = "OUT-CRL-OCSP"
      source_addresses  = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["ocsp.digicert.com", "crl3.digicert.com", "crl4.digicert.com", "ocsp.sectigo.com", "crl.sectigo.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31000: INBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_inbound" {
  name               = "RCG-CI-NE-IN-NET-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_ne_policy.id
  priority           = 31000

  network_rule_collection {
    name     = "RC-CI-NE-IN-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "IN-CE2CI-NONPROXY-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.60.0/26"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-INTERNAL2CI-NONPROXY-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.150.0.0/16"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-ILB-HEALTH-PROBES-NE"
      protocols             = ["TCP"]
      source_addresses      = ["168.63.129.16/32"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["65200-65535"]
    }

    rule {
      name                  = "IN-DNS-FROM-INFRA-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.0.0/16", "10.150.0.0/16"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["53"]
    }

    rule {
      name                  = "IN-MGMT-JIT-ADMIN-NE"
      protocols             = ["TCP"]
      source_ip_groups      = [azurerm_ip_group.ipg_uk_vpn.id, azurerm_ip_group.ipg_ind_vpn.id, azurerm_ip_group.ipg_hk_vpn.id]
      destination_addresses = ["10.200.12.96/26"]
      destination_ports     = ["22", "3389"]
    }
  }

  network_rule_collection {
    name     = "RC-CI-NE-IN-DENY-ALL"
    priority = 4096
    action   = "Deny"

    rule {
      name                  = "IN-DENY-ALL"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["*"]
      destination_addresses = ["*"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31100: OUTBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_out_net" {
  name               = "RCG-CI-NE-OUT-PRD-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_ne_policy.id
  priority           = 31100

  network_rule_collection {
    name     = "RC-CI-NE-OUT-NET-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "OUT-INTERNAL-TO-CE-FW-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.150.0.0/16"]
      destination_addresses = ["10.200.60.10"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31200: OUTBOUND APPLICATION RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_out_app" {
  name               = "RCG-CI-NE-OUT-PRD-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_ne_policy.id
  priority           = 31200

  application_rule_collection {
    name     = "RC-CI-NE-OUT-APP-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name              = "OUT-ENTRA-ID"
      source_addresses  = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["login.microsoftonline.com", "graph.microsoft.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-CONTROL-PLANE"
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureCloud"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-MONITOR"
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name              = "OUT-CRL-OCSP"
      source_addresses  = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["ocsp.digicert.com", "crl3.digicert.com", "crl4.digicert.com", "ocsp.sectigo.com", "crl.sectigo.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}
