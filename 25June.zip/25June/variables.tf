variable "cedmz_we_rg" {
  description = "West Europe resource group where Premium firewall exists"
  type        = string
  default     = "MIP-SI-WE-RG"
}

variable "cedmz_ne_rg" {
  description = "North Europe resource group where Premium firewall exists"
  type        = string
  default     = "MIP-SI-NE-RG"
}
