# Outstanding Item 03: Firewall Rules - Production Resource Groups
# All other values are hardcoded in Terraform code or use data sources

cedmz_we_rg = "MIP-SI-WE-RG"
cedmz_ne_rg = "MIP-SI-NE-RG"
