<#
.SYNOPSIS
    Clone 5 NGINX VMs with Availability Sets
    
.DESCRIPTION
    Clones 5 NGINX VMs from production source RGs to target RGs
    INCLUDES: 
    - Automatic availability set creation
    - Marketplace term acceptance
    - No wait times for fast execution
    - Corrected IP addresses (later in subnet range)
    
.PARAMETER SubscriptionId
    Azure subscription ID
    
.EXAMPLE
    .\Clone-5-NGINX-VMs-WITH-AVSETS.ps1 -SubscriptionId "b3179146-e675-480d-aa38-23ec90529400"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId
)

Set-AzContext -SubscriptionId $SubscriptionId | Out-Null

# VM Configuration - 5 NGINX VMs with Availability Sets
# Availability Sets (per architect table):
# SI-RPRXY-NE-59-AS: VMs 59, 60
# SI-RPRXY-WE-05-AS: VMs 10, 11
# No AS: VM 09
$vmCloneConfig = @(
    @{
        SourceVMName = "SI-RPRXY-VM-54"
        TargetVMName = "SI-RPRXY-VM-59"
        SourceResourceGroup = "si-rprxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.35"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
        AvailabilitySetName = "SI-RPRXY-NE-59-AS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-55"
        TargetVMName = "SI-RPRXY-VM-60"
        SourceResourceGroup = "si-rprxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.36"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
        AvailabilitySetName = "SI-RPRXY-NE-59-AS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-05"
        TargetVMName = "SI-RPRXY-VM-10"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.35"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
        AvailabilitySetName = "SI-RPRXY-WE-05-AS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-06"
        TargetVMName = "SI-RPRXY-VM-11"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.36"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
        AvailabilitySetName = "SI-RPRXY-WE-05-AS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-04"
        TargetVMName = "SI-RPRXY-VM-09"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.40"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
        AvailabilitySetName = ""
    }
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $output = "[$timestamp] [$Level] $Message"
    
    switch ($Level) {
        "SUCCESS" { Write-Host $output -ForegroundColor Green }
        "ERROR" { Write-Host $output -ForegroundColor Red }
        "WARNING" { Write-Host $output -ForegroundColor Yellow }
        default { Write-Host $output -ForegroundColor Cyan }
    }
}

function New-AvailabilitySet {
    param([string]$Name, [string]$Location, [string]$ResourceGroup)
    
    try {
        Write-Log "Creating availability set: $Name" "INFO"
        
        $existingAvSet = Get-AzAvailabilitySet -Name $Name -ResourceGroupName $ResourceGroup -ErrorAction SilentlyContinue
        if ($existingAvSet) {
            Write-Log "✓ Availability set already exists: $Name" "SUCCESS"
            return $existingAvSet
        }
        
        $avSet = New-AzAvailabilitySet -Name $Name -ResourceGroupName $ResourceGroup -Location $Location -Sku Aligned -PlatformFaultDomainCount 2 -PlatformUpdateDomainCount 2 -ErrorAction Stop
        Write-Log "✓ Availability set created: $Name" "SUCCESS"
        return $avSet
    }
    catch {
        Write-Log "Error creating availability set: $_" "ERROR"
        throw
    }
}

function Accept-MarketplaceTerms {
    param([string]$Publisher, [string]$Offer, [string]$Sku)
    
    try {
        Write-Log "Accepting marketplace terms for: Publisher=$Publisher, Offer=$Offer, Sku=$Sku" "INFO"
        
        $terms = Get-AzMarketplaceTerms -Publisher $Publisher -Product $Offer -Name $Sku -ErrorAction SilentlyContinue
        
        if ($null -eq $terms) {
            Write-Log "No marketplace terms found (image may not require acceptance)" "WARNING"
            return $true
        }
        
        if ($terms.Accepted) {
            Write-Log "✓ Marketplace terms already accepted" "SUCCESS"
            return $true
        }
        
        Write-Log "Accepting marketplace terms..." "INFO"
        Set-AzMarketplaceTerms -Publisher $Publisher -Product $Offer -Name $Sku -Accept -ErrorAction Stop | Out-Null
        Write-Log "✓ Marketplace terms accepted successfully" "SUCCESS"
        return $true
    }
    catch {
        Write-Log "Warning: Could not accept marketplace terms - $_" "WARNING"
        return $false
    }
}

function New-VMSnapshot {
    param([string]$SnapshotName, [string]$SourceDiskId, [string]$TargetResourceGroup, [string]$Location, [string]$SourceVMName)
    
    try {
        Write-Log "Creating snapshot: $SnapshotName"
        
        $existingSnapshot = Get-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction SilentlyContinue
        if ($existingSnapshot) {
            Write-Log "Removing existing snapshot: $SnapshotName" "WARNING"
            Remove-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -Force -ErrorAction SilentlyContinue
        }
        
        $snapshotConfig = New-AzSnapshotConfig -SourceResourceId $SourceDiskId -Location $Location -CreateOption Copy
        $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction Stop
        Write-Log "Snapshot created successfully" "SUCCESS"
        return $snapshot
    }
    catch {
        Write-Log "Error creating snapshot: $_" "ERROR"
        throw
    }
}

function New-VMDiskFromSnapshot {
    param([string]$DiskName, [string]$SnapshotId, [string]$TargetResourceGroup, [string]$Location, [string]$DiskType)
    
    try {
        Write-Log "Creating managed disk: $DiskName"
        
        $diskConfig = New-AzDiskConfig -SourceResourceId $SnapshotId -Location $Location -CreateOption Copy -SkuName $DiskType
        $disk = New-AzDisk -Disk $diskConfig -ResourceGroupName $TargetResourceGroup -DiskName $DiskName -ErrorAction Stop
        Write-Log "Managed disk created successfully" "SUCCESS"
        
        $maxRetries = 15
        $retryCount = 0
        while ($retryCount -lt $maxRetries) {
            $chk = Get-AzDisk -Name $DiskName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($chk) {
                Write-Log "Disk verified and available" "SUCCESS"
                return $disk
            }
            $retryCount++
        }
        
        Write-Log "Disk verification timeout" "WARNING"
        return $disk
    }
    catch {
        Write-Log "Error creating disk: $_" "ERROR"
        throw
    }
}

function New-VMNetworkInterface {
    param([string]$NICName, [string]$TargetVNetName, [string]$TargetSubnetName, [string]$TargetResourceGroup, [string]$VNetResourceGroup, [string]$PrivateIP, [string]$Location)
    
    try {
        Write-Log "Creating network interface: $NICName"
        
        $vnet = Get-AzVirtualNetwork -Name $TargetVNetName -ResourceGroupName $VNetResourceGroup -ErrorAction Stop
        $subnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $TargetSubnetName -ErrorAction Stop
        
        $nicConfig = New-AzNetworkInterfaceIpConfig -Name "ipconfig1" -PrivateIpAddress $PrivateIP -Subnet $subnet -Primary
        $nic = New-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -Location $Location -IpConfiguration $nicConfig -ErrorAction Stop
        Write-Log "Network interface created successfully" "SUCCESS"
        
        $maxRetries = 10
        $retryCount = 0
        while ($retryCount -lt $maxRetries) {
            $chk = Get-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($chk) {
                Write-Log "Network interface verified" "SUCCESS"
                return $nic
            }
            $retryCount++
        }
        
        Write-Log "NIC verification timeout" "WARNING"
        return $nic
    }
    catch {
        Write-Log "Error creating NIC: $_" "ERROR"
        throw
    }
}

function New-ClonedVM {
    param(
        [object]$Config,
        [object]$NIC,
        [object]$Disk,
        [object]$AvailabilitySet,
        [object]$Plan
    )
    
    try {
        $vmName = $Config.TargetVMName
        Write-Log "Creating VM: $vmName" "INFO"
        
        $vmConfig = New-AzVMConfig -VMName $vmName -VMSize "Standard_D2s_v3"
        
        if ($AvailabilitySet) {
            $vmConfig = $vmConfig | Set-AzVMAvailabilitySet -AvailabilitySet $AvailabilitySet
        }
        
        if ($Plan) {
            $vmConfig = $vmConfig | Set-AzVMPlan -Publisher $Plan.Publisher -Product $Plan.Product -Name $Plan.Name
        }
        
        $vmConfig = $vmConfig | Add-AzVMNetworkInterface -Id $NIC.Id -Primary -ErrorAction Stop
        $vmConfig = $vmConfig | Set-AzVMOSDisk -ManagedDiskId $Disk.Id -CreateOption Attach -Linux
        
        Write-Log "Submitting VM creation to Azure..." "INFO"
        $vm = New-AzVM -ResourceGroupName $Config.TargetResourceGroup -VM $vmConfig -Location $Config.Location -ErrorAction Stop
        
        $createdVM = Get-AzVM -Name $vmName -ResourceGroupName $Config.TargetResourceGroup -ErrorAction SilentlyContinue
        if ($createdVM) {
            Write-Log "✓ VM created and verified in resource group" "SUCCESS"
            Write-Log "  Provisioning State: $($createdVM.ProvisioningState)" "INFO"
            return $createdVM
        } else {
            Write-Log "Warning: VM creation completed but verification failed" "WARNING"
            return $vm
        }
    }
    catch {
        Write-Log "Error creating VM: $_" "ERROR"
        throw
    }
}

# Main execution
Write-Log "========================================" "INFO"
Write-Log "NGINX VM CLONING SCRIPT WITH AVSETS" "INFO"
Write-Log "========================================" "INFO"

$successCount = 0
$failureCount = 0

foreach ($vm in $vmCloneConfig) {
    Write-Log "========================================" "INFO"
    Write-Log "Processing VM: $($vm.TargetVMName)" "INFO"
    Write-Log "========================================" "INFO"
    
    try {
        # Get source VM
        Write-Log "Retrieving source VM: $($vm.SourceVMName)" "INFO"
        $sourceVM = Get-AzVM -Name $vm.SourceVMName -ResourceGroupName $vm.SourceResourceGroup -ErrorAction Stop
        Write-Log "✓ Source VM found" "SUCCESS"
        
        # Accept marketplace terms
        $plan = $sourceVM.Plan
        if ($plan) {
            Accept-MarketplaceTerms -Publisher $plan.Publisher -Offer $plan.Product -Sku $plan.Name | Out-Null
        }
        
        # Create availability set if needed
        $avSet = $null
        if ($vm.AvailabilitySetName -ne "") {
            $avSet = New-AvailabilitySet -Name $vm.AvailabilitySetName -Location $vm.Location -ResourceGroup $vm.TargetResourceGroup
        }
        
        # Create snapshot
        $snapshotName = "snapshot-$($vm.TargetVMName)-$(Get-Random)"
        $sourceDisk = Get-AzDisk -Name $sourceVM.StorageProfile.OsDisk.ManagedDisk.Id.Split('/')[-1] -ResourceGroupName $vm.SourceResourceGroup
        $snapshot = New-VMSnapshot -SnapshotName $snapshotName -SourceDiskId $sourceDisk.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -SourceVMName $vm.SourceVMName
        
        # Create disk from snapshot
        $diskName = "disk-$($vm.TargetVMName)-$(Get-Random)"
        $disk = New-VMDiskFromSnapshot -DiskName $diskName -SnapshotId $snapshot.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -DiskType $vm.DiskType
        
        # Create network interface
        $nicName = "nic-$($vm.TargetVMName)-$(Get-Random)"
        $nic = New-VMNetworkInterface -NICName $nicName -TargetVNetName $vm.TargetVNetName -TargetSubnetName $vm.TargetSubnetName -TargetResourceGroup $vm.TargetResourceGroup -VNetResourceGroup $vm.VNetResourceGroup -PrivateIP $vm.TargetPrivateIP -Location $vm.Location
        
        # Create VM
        $newVM = New-ClonedVM -Config $vm -NIC $nic -Disk $disk -AvailabilitySet $avSet -Plan $plan
        
        Write-Log "✓ VM cloning completed successfully" "SUCCESS"
        $successCount++
    }
    catch {
        Write-Log "✗ VM cloning failed: $_" "ERROR"
        $failureCount++
    }
}

Write-Log "========================================" "INFO"
Write-Log "CLONING SUMMARY" "INFO"
Write-Log "========================================" "INFO"
Write-Log "Successful: $successCount" "SUCCESS"
Write-Log "Failed: $failureCount" "ERROR"
Write-Log "Total: $($vmCloneConfig.Count)" "INFO"
