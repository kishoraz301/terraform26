# Certificate mappings — populate AFTER certs are uploaded to Key Vault.
#
# Apply with:  terraform apply -var-file=certs.tfvars
# (Do NOT include this file until certs are physically present in each vault.)
#
# Upload each cert to the vault first:
#   az keyvault certificate import --vault-name SI-Core-Vault-WE-01 \
#     --name cert-<name> --file <cert>.pfx --password <pwd>
#
# Key Vault URI format: https://<vault>.vault.azure.net/secrets/<cert-name>
# (Use the /secrets/ prefix, not /certificates/ — AppGW requires the secret version.)

we_cert_map = {
  "cert-notifyadvresultready-prod"         = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-notifyadvresultready-prod"
  "cert-ecotgetpropertydetails-prod"       = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-ecotgetpropertydetails-prod"
  "cert-ecotnotifypaymentsanction-prod"    = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-ecotnotifypaymentsanction-prod"
  "cert-sendvaluerupdate-prod"             = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-sendvaluerupdate-prod"
  "cert-notifyadvresultready-sit1"         = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-notifyadvresultready-sit1"
  "cert-sendvaluerupdate-sit1"             = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-sendvaluerupdate-sit1"
  "cert-devecotgetpropertydetails-sit1"    = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-devecotgetpropertydetails-sit1"
  "cert-devecotnotifypaymentsanction-sit1" = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-devecotnotifypaymentsanction-sit1"
  "cert-sendvaluerupdate-uat"              = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-sendvaluerupdate-uat"
  "cert-notifyadvresultready-st4-sit2"     = "https://si-core-vault-we-01.vault.azure.net/secrets/cert-notifyadvresultready-st4-sit2"
}

ne_cert_map = {
  "cert-notifyadvresultready-prod"         = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-notifyadvresultready-prod"
  "cert-ecotgetpropertydetails-prod"       = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-ecotgetpropertydetails-prod"
  "cert-ecotnotifypaymentsanction-prod"    = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-ecotnotifypaymentsanction-prod"
  "cert-sendvaluerupdate-prod"             = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-sendvaluerupdate-prod"
  "cert-notifyadvresultready-sit1"         = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-notifyadvresultready-sit1"
  "cert-sendvaluerupdate-sit1"             = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-sendvaluerupdate-sit1"
  "cert-devecotgetpropertydetails-sit1"    = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-devecotgetpropertydetails-sit1"
  "cert-devecotnotifypaymentsanction-sit1" = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-devecotnotifypaymentsanction-sit1"
  "cert-sendvaluerupdate-uat"              = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-sendvaluerupdate-uat"
  "cert-notifyadvresultready-st4-sit2"     = "https://si-core-vault-ne-51.vault.azure.net/secrets/cert-notifyadvresultready-st4-sit2"
}
