# Azure Subscription
primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"

# Resource Group Names
primary_rg_name   = "MIP-SI-WE-RG"
secondary_rg_name = "MIP-SI-NE-RG"

# Public IP Addresses for DNAT Rules
cedmz_pip_we = "48.209.40.88"  # PIP on SI-CEDMZ-WE-FW-01
cedmz_pip_ne = "74.234.51.102" # PIP on SI-CEDMZ-NE-FW-51
