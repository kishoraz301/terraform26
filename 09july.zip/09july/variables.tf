variable "primary_subscription_id" {
  type      = string
  sensitive = true
}

variable "secondary_subscription_id" {
  type      = string
  sensitive = true
}

# WE resource group
variable "primary_rg_name" {
  type    = string
  default = "MIP-SI-WE-RG"
}

# NE resource group
variable "secondary_rg_name" {
  type    = string
  default = "MIP-SI-NE-RG"
}

# Public IP on WE firewall used as DNAT destination
variable "cedmz_pip_we" {
  type        = string
  description = "Public IP for CE-DMZ West Europe Firewall (SI-CEDMZ-WE-FW-01)"
}

# Public IP on NE firewall used as DNAT destination
variable "cedmz_pip_ne" {
  type        = string
  description = "Public IP for CE-DMZ North Europe Firewall (SI-CEDMZ-NE-FW-51)"
}
