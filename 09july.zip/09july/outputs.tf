output "cedmz_ne_v2_policy_id" {
  value       = azurerm_firewall_policy.cedmz_ne_v2.id
  description = "ID of SI-CEDMZ-FWPLCY-NE-V2"
}

output "cedmz_we_v2_policy_id" {
  value       = azurerm_firewall_policy.cedmz_we_v2.id
  description = "ID of SI-CEDMZ-FWPLCY-WE-V2"
}

output "cidmz_ne_v2_policy_id" {
  value       = azurerm_firewall_policy.cidmz_ne_v2.id
  description = "ID of SI-CIDMZ-FWPLCY-STD-NE-V2"
}

output "cidmz_we_v2_policy_id" {
  value       = azurerm_firewall_policy.cidmz_we_v2.id
  description = "ID of SI-CIDMZ-FWPLCY-STD-WE-V2"
}
