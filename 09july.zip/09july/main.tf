# =============================================================================
# Phase 12b: Azure Firewall Policies V2
# Creates NEW V2 policies for CE-DMZ Premium and CI-DMZ Standard (NE + WE)
# Based on LLD: FIREWALLPOLICIES09JULY.MD
# Deploy AFTER Phase 06 (firewalls exist), BEFORE policy reassignment
# =============================================================================

terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

# Default provider → West Europe (MIP-SI-WE-RG)
provider "azurerm" {
  subscription_id = var.primary_subscription_id
  features {}
}

# Secondary provider → North Europe (MIP-SI-NE-RG)
provider "azurerm" {
  alias           = "secondary"
  subscription_id = var.secondary_subscription_id
  features {}
}

# =============================================================================
# LOCALS — FQDN lists used across multiple rules
# =============================================================================

locals {

  # CE-DMZ: Business application allow-list FQDNs
  ce_business_app_fqdns = [
    "valuationapi.hometrack.com",
    "hsbc.server115.net",
    "hsbcuat.server115.net",
    "api.mls.hometrack.com",
    "api.pre.mls.hometrack.com",
    "api.uat.mls.hometrack.com",
    "secure.authenticator.uat.uk.experian.com",
    "uat.bankwizardondemand.uk.experian.com",
    "bankwizardondemand.uk.experian.com",
    "secure.authenticator.uk.experian.com",
    "webportal.gb.co.uk",
    "api.addressy.com",
    "idm.gb.co.uk",
    "digitalprod-b2b-api.hsbc.co.uk",
    "digitaldev-b2b-api.p2g.netd2.hsbc.com.hk",
    "rbwm-b2b-api.hsbc.co.uk",
    "digitaluat-b2b-api.p2g.netd2.hsbc.com.hk",
    "srq1.lms.com",
    "lmu.lms.com",
    "hpp.sandbox.globaliris.com",
    "eu.sms.sdi.sinch.com",
    "sms-pp.sapmobileservices.com",
    "*.intermediaries-nft.hsbc.co.uk",
    "*.intermediaries-sit1.hsbc.co.uk",
    "*.intermediaries-sit2.hsbc.co.uk",
    "*.intermediaries-uat.hsbc.co.uk",
    "*.intermediaries.hsbc.co.uk",
    "if-api-preprod.hsbc.co.uk",
    "*.nuget.org",
    "if-api.hsbc.co.uk",
    "hap-preprod-api.hsbc.co.uk",
    "hap-api.hsbc.co.uk",
    "sourceforge.net",
    "www.postman.com",
    "www.red-gate.com"
  ]

  # CE-DMZ: Ubuntu package/security update FQDNs
  ce_ubuntu_fqdns = [
    "archive.ubuntu.com",
    "security.ubuntu.com",
    "*.archive.ubuntu.com",
    "*.security.ubuntu.com",
    "debian-archive.trafficmanager.net",
    "packages.nginx.org",
    "nginx.org"
  ]

  # CE-DMZ: TLS certificate validation (CRL/OCSP) FQDNs
  ce_tls_crl_fqdns = [
    "ocsp.digicert.com",
    "crl3.digicert.com",
    "crl4.digicert.com",
    "ocsp.sectigo.com",
    "crl.sectigo.com",
    "crl.comodoca.com",
    "crl.comodo.com",
    "crl.microsoft.com",
    "crl.usertrust.com",
    "crl2.microsoft.com",
    "ocsp.comodoca.com",
    "ocsp.usertrust.com"
  ]

  # CE-DMZ NE: QueueIT + ClamAV FQDNs
  ce_ne_queue_av_fqdns = [
    "hsbcuktest.queue-it.net",
    "hsbcuktest.api2.queue-it.net",
    "hsbcuk.queue-it.net",
    "*.clamav.net"
  ]

  # CE-DMZ WE: QueueIT + ClamAV FQDNs
  ce_we_queue_av_fqdns = [
    "hsbcuktest.queue-it.net",
    "hsbcuktest.api2.queue-it.net",
    "hsbcuk.queue-it.net",
    "*.clamav.net"
  ]

  # CE-DMZ: CrowdStrike Falcon sensor FQDNs
  ce_crowdstrike_fqdns = [
    "ts01-lanner-lion.cloudsink.net",
    "lfodown01-lanner-lion.cloudsink.net",
    "lfoup01-lanner-lion.cloudsink.net",
    "assets.falcon.eu-1.crowdstrike.com",
    "assets-public.falcon.eu-1.crowdstrike.com",
    "api.eu-1.crowdstrike.com",
    "firehose.eu-1.crowdstrike.com",
    "ts01-b.cloudsink.net"
  ]

  # CE-DMZ: Azure tooling + platform FQDNs (NE and WE share same list)
  ce_tools_platform_fqdns = [
    "www.powershellgallery.com",
    "devopsagentstorage.blob.core.windows.net",
    "vstagentpackage.azureedge.net",
    "winatp-gw-weu.microsoft.com",
    "ava-hsbc.visualstudio.com",
    "download.microsoft.com",
    "azure.microsoft.com",
    "*.ods.opinsights.azure.com",
    "*.oms.opinsights.azure.com",
    "*.agentsvc.azure-automation.net",
    "*.blob.core.windows.net",
    "*.azure.com",
    "*.microsoft.com",
    "*.windows.net",
    "*.microsoftonline.com",
    "login.microsoftonline.com",
    "graph.microsoft.com",
    "*.windowsupdate.com",
    "ecs.office.com",
    "*.vault.azure.net",
    "file.core.windows.net",
    "azureedge.net",
    "prod.microsoftmetrics.com",
    "config.ecs.dod.teams.microsoft.us",
    "config.edge.skype.com",
    "dc.services.visualstudio.com",
    "gccmod.ecs.office.com"
  ]

  # CI-DMZ: CRL/OCSP FQDNs for Standard firewall
  ci_crl_fqdns = [
    "ocsp.digicert.com",
    "crl3.digicert.com",
    "crl4.digicert.com",
    "ocsp.sectigo.com",
    "crl.sectigo.com",
    "crl.comodoca.com",
    "crl.comodo.com",
    "crl.microsoft.com",
    "crl.usertrust.com",
    "crl2.microsoft.com",
    "ocsp.comodoca.com",
    "ocsp.usertrust.com"
  ]

  # CI-DMZ NE: Tools + platform FQDNs (includes telecommandsvc not in WE)
  ci_ne_tools_platform_fqdns = [
    "login.microsoftonline.com",
    "graph.microsoft.com",
    "*.endpoint.security.microsoft.com",
    "*.azure.com",
    "*.events.data.microsoft.com",
    "*.handler.control.monitor.azure.com",
    "*.handler.service.batch.azure.com",
    "servicebus.windows.net",
    "config.edge.skype.com",
    "config.ecs.dod.teams.microsoft.us",
    "dc.services.visualstudio.com",
    "iecvlist.microsoft.com",
    "msedge.api.cdp.microsoft.com",
    "settings-win.data.microsoft.com",
    "vortex.data.microsoft.com",
    "wdcp.microsoft.com",
    "wdcpalt.microsoft.com",
    "tsl-b.cloudsink.net",
    "client.wns.windows.com",
    "sls.update.microsoft.com",
    "go.microsoft.com",
    "edge-consumer-static.azureedge.net",
    "europe.cp.wd.microsoft.com",
    "europe.smartscreen.microsoft.com",
    "www.msftconnecttest.com",
    "www.msftncsi.com",
    "www.telecommandsvc.microsoft.com",
    "global.handler.control.monitor.azure.com",
    "northurope-2.in.applicationinsights.azure.com",
    "*.blob.storage.azure.net",
    "*.opinsights.azure.com",
    "*.northurope.service.batch.azure.com",
    "*.servicebus.windows.net",
    "login.live.com",
    "login.windows.net",
    "winatp-gw-weu.microsoft.com",
    "*.clamav.net",
    "database.clamav.net"
  ]

  # CI-DMZ WE: Tools + platform FQDNs
  ci_we_tools_platform_fqdns = [
    "login.microsoftonline.com",
    "graph.microsoft.com",
    "*.endpoint.security.microsoft.com",
    "*.azure.com",
    "*.events.data.microsoft.com",
    "*.handler.control.monitor.azure.com",
    "*.handler.service.batch.azure.com",
    "servicebus.windows.net",
    "config.edge.skype.com",
    "config.ecs.dod.teams.microsoft.us",
    "dc.services.visualstudio.com",
    "iecvlist.microsoft.com",
    "msedge.api.cdp.microsoft.com",
    "settings-win.data.microsoft.com",
    "vortex.data.microsoft.com",
    "wdcp.microsoft.com",
    "wdcpalt.microsoft.com",
    "tsl-b.cloudsink.net",
    "client.wns.windows.com",
    "sls.update.microsoft.com",
    "go.microsoft.com",
    "edge-consumer-static.azureedge.net",
    "europe.cp.wd.microsoft.com",
    "europe.smartscreen.microsoft.com",
    "www.msftconnecttest.com",
    "www.msftncsi.com",
    "global.handler.control.monitor.azure.com",
    "northurope-2.in.applicationinsights.azure.com",
    "*.blob.storage.azure.net",
    "*.opinsights.azure.com",
    "*.northurope.service.batch.azure.com",
    "*.servicebus.windows.net",
    "login.live.com",
    "login.windows.net",
    "winatp-gw-weu.microsoft.com",
    "*.clamav.net",
    "database.clamav.net"
  ]

  # CI-DMZ AZURE-PLATFORM-PROD service tags (same list for NE and WE)
  ci_azure_platform_service_tags = [
    "Storage.NorthEurope",
    "Storage.WestEurope",
    "ServiceBus",
    "AzureActiveDirectory",
    "AzureCloud",
    "ServiceFabric",
    "AzureCloud.WestEurope",
    "ServiceBus.WestEurope",
    "MicrosoftDefenderForEndpoint",
    "GuestAndHybridManagement",
    "AzureMonitor",
    "AzureBackup",
    "AzureResourceManager",
    "AzureUpdateDelivery"
  ]

  # AppInsights extension install IPs (non-prod)
  appinsights_install_ips = ["152.199.23.209", "52.240.159.111"]

  # SFTP dev endpoint IP
  sftp_dev_ip = ["161.113.228.48"]

  # SFTP prod endpoint IPs
  sftp_prod_ips = ["193.108.76.149", "91.214.5.149"]

  # SFTP endpoints used in non-prod (includes dev secondary IP)
  sftp_nonprod_ips = ["161.113.228.48", "161.113.239.62"]
}

# =============================================================================
# DATA SOURCES — Existing IP Groups (not managed by this phase)
# =============================================================================

# VPN IP groups are in MIP-SI-WE-RG → default provider
data "azurerm_ip_group" "vpn_uk" {
  name                = "IPG-UK-VPN"
  resource_group_name = var.primary_rg_name
}

data "azurerm_ip_group" "vpn_ind" {
  name                = "IPG-IND-VPN"
  resource_group_name = var.primary_rg_name
}

data "azurerm_ip_group" "vpn_hk" {
  name                = "IPG-HK-VPN"
  resource_group_name = var.primary_rg_name
}

# Security/DevOps IP groups are in MIP-SI-NE-RG → secondary provider
data "azurerm_ip_group" "crowdstrike" {
  provider            = azurerm.secondary
  name                = "IPG-CROWDSTRIKE"
  resource_group_name = var.secondary_rg_name
}

data "azurerm_ip_group" "devops_agents" {
  provider            = azurerm.secondary
  name                = "IPG-CI-DEVOPS-AGENTS"
  resource_group_name = var.secondary_rg_name
}

# =============================================================================
# FIREWALL POLICY RESOURCES — V2 (new, not modifying existing)
# =============================================================================

# CE-DMZ Premium NE — assigned to SI-CEDMZ-NE-FW-51
resource "azurerm_firewall_policy" "cedmz_ne_v2" {
  provider            = azurerm.secondary
  name                = "SI-CEDMZ-FWPLCY-NE-V2"
  resource_group_name = var.secondary_rg_name
  location            = "northeurope"
  sku                 = "Premium"

  tags = {
    version = "V2"
    phase   = "12b"
    region  = "NE"
    tier    = "CE-DMZ"
  }
}

# CE-DMZ Premium WE — assigned to SI-CEDMZ-WE-FW-01
resource "azurerm_firewall_policy" "cedmz_we_v2" {
  name                = "SI-CEDMZ-FWPLCY-WE-V2"
  resource_group_name = var.primary_rg_name
  location            = "westeurope"
  sku                 = "Premium"

  tags = {
    version = "V2"
    phase   = "12b"
    region  = "WE"
    tier    = "CE-DMZ"
  }
}

# CI-DMZ Standard NE — assigned to SI-DMZ-NE-FWSTD-51
resource "azurerm_firewall_policy" "cidmz_ne_v2" {
  provider            = azurerm.secondary
  name                = "SI-CIDMZ-FWPLCY-STD-NE-V2"
  resource_group_name = var.secondary_rg_name
  location            = "northeurope"
  sku                 = "Standard"

  tags = {
    version = "V2"
    phase   = "12b"
    region  = "NE"
    tier    = "CI-DMZ"
  }
}

# CI-DMZ Standard WE — assigned to SI-DMZ-WE-FWSTD-01
resource "azurerm_firewall_policy" "cidmz_we_v2" {
  name                = "SI-CIDMZ-FWPLCY-STD-WE-V2"
  resource_group_name = var.primary_rg_name
  location            = "westeurope"
  sku                 = "Standard"

  tags = {
    version = "V2"
    phase   = "12b"
    region  = "WE"
    tier    = "CI-DMZ"
  }
}

# =============================================================================
# CE-DMZ PREMIUM — NORTH EUROPE RULES
# Firewall: SI-CEDMZ-NE-FW-51
# =============================================================================

# ── DNAT Rules (RCG priority 50) ─────────────────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_ne_dnat" {
  provider           = azurerm.secondary
  name               = "RCG-CE-DMZ-IN-DNAT-NE"
  firewall_policy_id = azurerm_firewall_policy.cedmz_ne_v2.id
  priority           = 100

  nat_rule_collection {
    name     = "DNAT-RDS-HTTPS443-NE-UK"
    priority = 1101
    action   = "Dnat"
    rule {
      name                = "DNAT-RDS-HTTPS443-NE-UK"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.vpn_uk.id]
      destination_address = var.cedmz_pip_ne
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }

  nat_rule_collection {
    name     = "DNAT-RDS-HTTPS443-NE-IND"
    priority = 1102
    action   = "Dnat"
    rule {
      name                = "DNAT-RDS-HTTPS443-NE-IND"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.vpn_ind.id]
      destination_address = var.cedmz_pip_ne
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }

  nat_rule_collection {
    name     = "DNAT-RDS-HTTPS443-NE-HK"
    priority = 1103
    action   = "Dnat"
    rule {
      name                = "DNAT-RDS-HTTPS443-NE-HK"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.vpn_hk.id]
      destination_address = var.cedmz_pip_ne
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }
}

# ── Application Rules (RCG priority 100) ─────────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_ne_app" {
  provider           = azurerm.secondary
  name               = "RCG-CE-DMZ-OUT-PROD-APP-NE"
  firewall_policy_id = azurerm_firewall_policy.cedmz_ne_v2.id
  priority           = 200

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-BUSINESS"
    priority = 110
    action   = "Allow"
    rule {
      name             = "OUT-APP-WHITELIST-BUSINESS"
      source_addresses = ["10.200.12.0/26", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_business_app_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-UBUNTU-UPDATES"
    priority = 120
    action   = "Allow"
    rule {
      name             = "OUT-APP-UBUNTU-UPDATES"
      source_addresses = ["10.200.12.0/26"]
      protocols {
        type = "Http"
        port = "80"
      }
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_ubuntu_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TLS-CRL-OCSP"
    priority = 135
    action   = "Allow"
    rule {
      name             = "OUT-APP-TLS-CRL-OCSP"
      source_addresses = ["10.200.12.0/24", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      protocols {
        type = "Http"
        port = "80"
      }
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_tls_crl_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-BUSINESS-QUEUE-AV"
    priority = 140
    action   = "Allow"
    rule {
      name             = "OUT-APP-BUSINESS-QUEUE-AV"
      source_addresses = ["10.210.2.0/24", "10.210.0.0/24", "10.212.2.0/24", "10.212.0.0/24", "10.214.2.0/24", "10.214.0.0/24"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_ne_queue_av_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-CROWDSTRIKE-NE"
    priority = 145
    action   = "Allow"
    rule {
      name             = "OUT-CROWDSTRIKE-NE"
      source_addresses = ["10.200.12.64/27"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_crowdstrike_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TOOLS-PLATFORM"
    priority = 150
    action   = "Allow"
    rule {
      name             = "OUT-APP-TOOLS-PLATFORM"
      source_addresses = ["10.200.60.0/26", "10.200.12.192/26", "10.200.12.0/26", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_tools_platform_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-FW-AZURE-MONITOR"
    priority = 155
    action   = "Allow"
    rule {
      name             = "OUT-FW-AZURE-MONITOR"
      source_addresses = ["10.200.60.0/26"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureMonitor"]
    }
  }

  application_rule_collection {
    name     = "OUT-RDS-CONTROL-PLANE-NE"
    priority = 160
    action   = "Allow"
    rule {
      name             = "OUT-RDS-CONTROL-PLANE-NE"
      source_addresses = ["10.200.12.64/27"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["WindowsVirtualDesktop"]
    }
  }

  application_rule_collection {
    name     = "OUT-LOG-ANALYTICS-NE"
    priority = 170
    action   = "Allow"
    rule {
      name             = "OUT-LOG-ANALYTICS-NE"
      source_addresses = ["10.200.12.0/24"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureMonitor"]
    }
  }

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-TESTING"
    priority = 180
    action   = "Allow"
    rule {
      name             = "OUT-APP-WHITELIST-TESTING"
      source_addresses = ["10.200.12.0/26"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = ["api.ipify.org"]
    }
  }
}

# ── FTP / SFTP Network Rules (RCG priority 300) ───────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_ne_ftp" {
  provider           = azurerm.secondary
  name               = "RCG-CE-DMZ-OUT-FTP-NE"
  firewall_policy_id = azurerm_firewall_policy.cedmz_ne_v2.id
  priority           = 300

  network_rule_collection {
    name     = "FTP-NE-dev-01"
    priority = 310
    action   = "Allow"
    rule {
      name                  = "FTP-NE-dev-01"
      protocols             = ["TCP"]
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = local.sftp_dev_ip
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "FTP-NE-prod-01"
    priority = 320
    action   = "Allow"
    rule {
      name                  = "FTP-NE-prod-01"
      protocols             = ["TCP"]
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = local.sftp_prod_ips
      destination_ports     = ["10022"]
    }
  }
}

# ── Internet Network Rules (RCG priority 500) ─────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_ne_internet" {
  provider           = azurerm.secondary
  name               = "RCG-CE-DMZ-OUT-INTERNET"
  firewall_policy_id = azurerm_firewall_policy.cedmz_ne_v2.id
  priority           = 500

  network_rule_collection {
    name     = "AZURE-MANAGEMENT"
    priority = 500
    action   = "Allow"
    rule {
      name                  = "AZURE-MANAGEMENT"
      protocols             = ["TCP"]
      source_addresses      = ["10.200.12.192/26", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope", "ServiceBus", "AzureActiveDirectory", "AzureCloud", "ServiceFabric"]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "SFC-TO-INTERNET"
    priority = 510
    action   = "Allow"
    rule {
      name                  = "SFC-TO-INTERNET"
      protocols             = ["Any"]
      source_addresses      = ["10.210.6.0/24", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = ["AzureCloud"]
      destination_ports     = ["*"]
    }
  }
}

# ── Non-Prod ST4 Network Rules (RCG priority 1600) ────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_ne_st4" {
  provider           = azurerm.secondary
  name               = "RCG-CE-DMZ-OUT-NET-ST4"
  firewall_policy_id = azurerm_firewall_policy.cedmz_ne_v2.id
  priority           = 1600

  network_rule_collection {
    name     = "SFTP-OUT-OMIGADB-ST4"
    priority = 1630
    action   = "Allow"
    rule {
      name                  = "SFTP-OUT-OMIGADB-ST4"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.5.0/24"]
      destination_addresses = local.sftp_nonprod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "STORAGE-FILE-SHARE-SMB-ST4"
    priority = 1640
    action   = "Allow"
    rule {
      name                  = "STORAGE-FILE-SHARE-SMB-ST4"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope"]
      destination_ports     = ["445"]
    }
  }

  network_rule_collection {
    name     = "SQL-OUTBOUND-ASE-ST4"
    priority = 1650
    action   = "Allow"
    rule {
      name                  = "SQL-OUTBOUND-ASE-ST4"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "APPINSIGHTS-INSTALL-ST4"
    priority = 1690
    action   = "Allow"
    rule {
      name                  = "APPINSIGHTS-INSTALL-ST4"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }
}

# ── OT1-NE Network Rules (RCG priority 1800) ──────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_ne_ot1" {
  provider           = azurerm.secondary
  name               = "RCG-CE-DMZ-OUT-NET-NE-OT1"
  firewall_policy_id = azurerm_firewall_policy.cedmz_ne_v2.id
  priority           = 1800

  network_rule_collection {
    name     = "SFTP-OUT-OT1-NE"
    priority = 1810
    action   = "Allow"
    rule {
      name                  = "SFTP-OUT-OT1-NE"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.0.0/16"]
      destination_addresses = local.sftp_prod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "STORAGE-SMB-OT1-NE"
    priority = 1820
    action   = "Allow"
    rule {
      name                  = "STORAGE-SMB-OT1-NE"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope"]
      destination_ports     = ["445"]
    }
  }

  network_rule_collection {
    name     = "SQL-OUTBOUND-ASE-OT1-NE"
    priority = 1830
    action   = "Allow"
    rule {
      name                  = "SQL-OUTBOUND-ASE-OT1-NE"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "APPINSIGHTS-EXTENSION-INSTALL-OT1-NE"
    priority = 1870
    action   = "Allow"
    rule {
      name                  = "APPINSIGHTS-EXTENSION-INSTALL-OT1-NE"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }
}

# =============================================================================
# CE-DMZ PREMIUM — WEST EUROPE RULES
# Firewall: SI-CEDMZ-WE-FW-01
# =============================================================================

# ── DNAT Rules (RCG priority 50) ─────────────────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_we_dnat" {
  name               = "RCG-CE-DMZ-IN-DNAT-WE"
  firewall_policy_id = azurerm_firewall_policy.cedmz_we_v2.id
  priority           = 100

  nat_rule_collection {
    name     = "DNAT-RDS-HTTPS443-WE-UK"
    priority = 1001
    action   = "Dnat"
    rule {
      name                = "DNAT-RDS-HTTPS443-WE-UK"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.vpn_uk.id]
      destination_address = var.cedmz_pip_we
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }

  nat_rule_collection {
    name     = "DNAT-RDS-HTTPS443-WE-IND"
    priority = 1002
    action   = "Dnat"
    rule {
      name                = "DNAT-RDS-HTTPS443-WE-IND"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.vpn_ind.id]
      destination_address = var.cedmz_pip_we
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }

  nat_rule_collection {
    name     = "DNAT-RDS-HTTPS443-WE-HK"
    priority = 1003
    action   = "Dnat"
    rule {
      name                = "DNAT-RDS-HTTPS443-WE-HK"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.vpn_hk.id]
      destination_address = var.cedmz_pip_we
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }
}

# ── Application Rules (RCG priority 400) ─────────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_we_app" {
  name               = "RCG-CE-DMZ-OUT-PROD-APP-WE"
  firewall_policy_id = azurerm_firewall_policy.cedmz_we_v2.id
  priority           = 500

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-BUSINESS"
    priority = 210
    action   = "Allow"
    rule {
      name             = "OUT-APP-WHITELIST-BUSINESS"
      source_addresses = ["10.200.11.0/26", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_business_app_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-UBUNTU-UPDATES"
    priority = 220
    action   = "Allow"
    rule {
      name             = "OUT-APP-UBUNTU-UPDATES"
      source_addresses = ["10.200.11.0/26"]
      protocols {
        type = "Http"
        port = "80"
      }
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_ubuntu_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TLS-CRL-OCSP"
    priority = 235
    action   = "Allow"
    rule {
      name             = "OUT-APP-TLS-CRL-OCSP"
      source_addresses = ["10.200.11.0/24", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      protocols {
        type = "Http"
        port = "80"
      }
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_tls_crl_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-BUSINESS-QUEUE-AV"
    priority = 240
    action   = "Allow"
    rule {
      name             = "OUT-APP-BUSINESS-QUEUE-AV"
      source_addresses = ["10.207.2.0/24", "10.207.0.0/24", "10.213.2.0/24", "10.213.0.0/24", "10.215.2.0/24", "10.215.0.0/24"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_we_queue_av_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-CROWDSTRIKE-WE"
    priority = 245
    action   = "Allow"
    rule {
      name             = "OUT-CROWDSTRIKE-WE"
      source_addresses = ["10.200.11.64/27"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_crowdstrike_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TOOLS-PLATFORM"
    priority = 250
    action   = "Allow"
    rule {
      name             = "OUT-APP-TOOLS-PLATFORM"
      source_addresses = ["10.200.50.0/26", "10.200.11.192/26", "10.200.11.0/26", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ce_tools_platform_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-FW-AZURE-MONITOR"
    priority = 255
    action   = "Allow"
    rule {
      name             = "OUT-FW-AZURE-MONITOR"
      source_addresses = ["10.200.50.0/26"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureMonitor"]
    }
  }

  application_rule_collection {
    name     = "OUT-RDS-CONTROL-PLANE-WE"
    priority = 260
    action   = "Allow"
    rule {
      name             = "OUT-RDS-CONTROL-PLANE-WE"
      source_addresses = ["10.200.11.64/27"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["WindowsVirtualDesktop"]
    }
  }

  application_rule_collection {
    name     = "OUT-LOG-ANALYTICS-WE"
    priority = 270
    action   = "Allow"
    rule {
      name             = "OUT-LOG-ANALYTICS-WE"
      source_addresses = ["10.200.11.0/24"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureMonitor"]
    }
  }

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-TESTING"
    priority = 280
    action   = "Allow"
    rule {
      name             = "OUT-APP-WHITELIST-TESTING"
      source_addresses = ["10.200.11.0/26"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = ["api.ipify.org"]
    }
  }
}

# ── FTP / SFTP Network Rules (RCG priority 350) ───────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_we_ftp" {
  name               = "RCG-CE-DMZ-OUT-FTP-WE"
  firewall_policy_id = azurerm_firewall_policy.cedmz_we_v2.id
  priority           = 350

  network_rule_collection {
    name     = "FTP-WE-dev-01"
    priority = 355
    action   = "Allow"
    rule {
      name                  = "FTP-WE-dev-01"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = local.sftp_dev_ip
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "FTP-WE-prod-01"
    priority = 365
    action   = "Allow"
    rule {
      name                  = "FTP-WE-prod-01"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = local.sftp_prod_ips
      destination_ports     = ["10022"]
    }
  }
}

# ── Internet Network Rules (RCG priority 550) ─────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_we_internet" {
  name               = "RCG-CE-DMZ-WE-OUT-INTERNET"
  firewall_policy_id = azurerm_firewall_policy.cedmz_we_v2.id
  priority           = 550

  network_rule_collection {
    name     = "AZURE-MANAGEMENT"
    priority = 565
    action   = "Allow"
    rule {
      name                  = "AZURE-MANAGEMENT"
      protocols             = ["TCP"]
      source_addresses      = ["10.200.11.192/26", "10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope", "ServiceBus", "AzureActiveDirectory", "AzureCloud", "ServiceFabric"]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "SFC-TO-INTERNET"
    priority = 575
    action   = "Allow"
    rule {
      name                  = "SFC-TO-INTERNET"
      protocols             = ["Any"]
      source_addresses      = ["10.210.6.0/24", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["AzureCloud"]
      destination_ports     = ["*"]
    }
  }
}

# ── UT1 Network Rules (RCG priority 1700) ─────────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_we_ut1" {
  name               = "RCG-CE-DMZ-OUT-NET-WE-UT1"
  firewall_policy_id = azurerm_firewall_policy.cedmz_we_v2.id
  priority           = 1700

  network_rule_collection {
    name     = "SFTP-OUT-UT1"
    priority = 1730
    action   = "Allow"
    rule {
      name                  = "SFTP-OUT-UT1"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.0.0/16"]
      destination_addresses = local.sftp_nonprod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "STORAGE-FILE-SHARE-SMB-UT1"
    priority = 1740
    action   = "Allow"
    rule {
      name                  = "STORAGE-FILE-SHARE-SMB-UT1"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope"]
      destination_ports     = ["445"]
    }
  }

  network_rule_collection {
    name     = "SQL-OUTBOUND-ASE-UT1"
    priority = 1750
    action   = "Allow"
    rule {
      name                  = "SQL-OUTBOUND-ASE-UT1"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "APPINSIGHTS-INSTALL-UT1"
    priority = 1790
    action   = "Allow"
    rule {
      name                  = "APPINSIGHTS-INSTALL-UT1"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }
}

# ── OT1-WE Network Rules (RCG priority 1900) ──────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cedmz_we_ot1" {
  name               = "RCG-CE-DMZ-OUT-NET-WE-OT1"
  firewall_policy_id = azurerm_firewall_policy.cedmz_we_v2.id
  priority           = 1900

  network_rule_collection {
    name     = "SFTP-OUT-OT1-WE"
    priority = 1910
    action   = "Allow"
    rule {
      name                  = "SFTP-OUT-OT1-WE"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.0.0/16"]
      destination_addresses = local.sftp_prod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "STORAGE-SMB-OT1-WE"
    priority = 1920
    action   = "Allow"
    rule {
      name                  = "STORAGE-SMB-OT1-WE"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope"]
      destination_ports     = ["445"]
    }
  }

  network_rule_collection {
    name     = "SQL-OUTBOUND-ASE-OT1-WE"
    priority = 1930
    action   = "Allow"
    rule {
      name                  = "SQL-OUTBOUND-ASE-OT1-WE"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "APPINSIGHTS-EXTENSION-INSTALL-OT1-WE"
    priority = 1970
    action   = "Allow"
    rule {
      name                  = "APPINSIGHTS-EXTENSION-INSTALL-OT1-WE"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }
}

# =============================================================================
# CI-DMZ STANDARD — NORTH EUROPE RULES
# Firewall: SI-DMZ-NE-FWSTD-51
# =============================================================================

# ── Application Outbound Rules (RCG priority 3200) ────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_ne_app_out" {
  provider           = azurerm.secondary
  name               = "RCG-CI-NE-OUT-PRD-ALLOW-APP"
  firewall_policy_id = azurerm_firewall_policy.cidmz_ne_v2.id
  priority           = 3200

  application_rule_collection {
    name     = "OUT-Tools-Platform"
    priority = 3205
    action   = "Allow"
    rule {
      name             = "OUT-Tools-Platform"
      source_addresses = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ci_ne_tools_platform_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-AZURE-CONTROL-PLANE"
    priority = 3210
    action   = "Allow"
    rule {
      name             = "OUT-AZURE-CONTROL-PLANE"
      source_addresses = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureCloud"]
    }
  }

  application_rule_collection {
    name     = "OUT-AZURE-MONITOR"
    priority = 3220
    action   = "Allow"
    rule {
      name             = "OUT-AZURE-MONITOR"
      source_addresses = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureMonitor"]
    }
  }

  application_rule_collection {
    name     = "OUT-CRL-OCSP"
    priority = 3230
    action   = "Allow"
    rule {
      name             = "OUT-CRL-OCSP"
      source_addresses = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      protocols {
        type = "Http"
        port = "80"
      }
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ci_crl_fqdns
    }
  }
}

# ── Network Outbound Rules (RCG priority 3300) ────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_ne_net_out" {
  provider           = azurerm.secondary
  name               = "RCG-CI-NE-OUT-PRD-ALLOW-NET"
  firewall_policy_id = azurerm_firewall_policy.cidmz_ne_v2.id
  priority           = 3300

  network_rule_collection {
    name     = "OUT-INTERNAL-TO-CE-FW-NE"
    priority = 3305
    action   = "Allow"
    rule {
      name                  = "OUT-INTERNAL-TO-CE-FW-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = ["10.200.50.10"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "AZURE-PLATFORM-PROD"
    priority = 3310
    action   = "Allow"
    rule {
      name                  = "AZURE-PLATFORM-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.6.0/24", "10.210.6.0/24", "10.212.6.0/24", "10.213.6.0/24", "10.214.6.0/24", "10.215.6.0/24"]
      destination_addresses = local.ci_azure_platform_service_tags
      destination_ports     = ["80", "443"]
    }
  }

  network_rule_collection {
    name     = "AZURE-MONITOR-PROD"
    priority = 3320
    action   = "Allow"
    rule {
      name                  = "AZURE-MONITOR-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = ["AzureMonitor"]
      destination_ports     = ["80", "443"]
    }
  }

  network_rule_collection {
    name     = "CROWDSTRIKE-PRO"
    priority = 3330
    action   = "Allow"
    rule {
      name                  = "CROWDSTRIKE-PRO"
      protocols             = ["TCP"]
      source_addresses      = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_ip_groups = [data.azurerm_ip_group.crowdstrike.id]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "DEVOPS-AGENT-PROD"
    priority = 3340
    action   = "Allow"
    rule {
      name                  = "DEVOPS-AGENT-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.213.0.0/16", "10.214.0.0/16", "10.215.0.0/16"]
      destination_ip_groups = [data.azurerm_ip_group.devops_agents.id]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "AZURE-LOGANALYTICS-PROD"
    priority = 3350
    action   = "Allow"
    rule {
      name                  = "AZURE-LOGANALYTICS-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = ["AzureCloud.NorthEurope"]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "NTP-PROD"
    priority = 3360
    action   = "Allow"
    rule {
      name                  = "NTP-PROD"
      protocols             = ["UDP"]
      source_addresses      = ["10.150.0.0/16", "10.210.0.0/16", "10.212.0.0/16", "10.214.0.0/16"]
      destination_addresses = ["AzureCloud.UKWest", "AzureCloud.NorthEurope", "AzureCloud.WestEurope"]
      destination_ports     = ["123"]
    }
  }
}

# ── Network Inbound Rules (RCG priority 4100) ─────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_ne_net_in" {
  provider           = azurerm.secondary
  name               = "RCG-CI-NE-IN-NET-PRD-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.cidmz_ne_v2.id
  priority           = 4100

  network_rule_collection {
    name     = "IN-CE2C-NONPROXY"
    priority = 4105
    action   = "Allow"
    rule {
      name                  = "IN-CE2C-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.60.0/26"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "IN-INTERNAL2CI-NONPROXY"
    priority = 4110
    action   = "Allow"
    rule {
      name                  = "IN-INTERNAL2CI-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.150.0.0/16"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "IN-LB-HEALTH-PROBES"
    priority = 4120
    action   = "Allow"
    rule {
      name                  = "IN-LB-HEALTH-PROBES"
      protocols             = ["TCP"]
      source_addresses      = ["168.63.129.16/32"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["65200-65535"]
    }
  }

  network_rule_collection {
    name     = "IN-DNS-FROM-INFRA"
    priority = 4130
    action   = "Allow"
    rule {
      name                  = "IN-DNS-FROM-INFRA"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.0.0/16", "10.150.0.0/16"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["53"]
    }
  }

  network_rule_collection {
    name     = "IN-MGMT-IT-ADMIN"
    priority = 4140
    action   = "Allow"
    rule {
      name                  = "IN-MGMT-IT-ADMIN"
      protocols             = ["TCP"]
      source_ip_groups      = [data.azurerm_ip_group.vpn_uk.id, data.azurerm_ip_group.vpn_ind.id, data.azurerm_ip_group.vpn_hk.id]
      destination_addresses = ["10.200.12.96/26"]
      destination_ports     = ["22", "3389"]
    }
  }
}

# ── ST4 Non-Prod Network Rules (RCG priority 4200) ────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_ne_st4" {
  provider           = azurerm.secondary
  name               = "RCG-CI-NE-OUT-NET-ST4-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.cidmz_ne_v2.id
  priority           = 4200

  network_rule_collection {
    name     = "Batch-SFTP-Out-OMIGADB"
    priority = 4210
    action   = "Allow"
    rule {
      name                  = "Batch-SFTP-Out-OMIGADB"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.5.0/24"]
      destination_addresses = local.sftp_nonprod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "Allow-AppInsights-out-ASE"
    priority = 4220
    action   = "Allow"
    rule {
      name                  = "Allow-AppInsights-out-ASE"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "Allow-DB-Outbound-ASE"
    priority = 4230
    action   = "Allow"
    rule {
      name                  = "Allow-DB-Outbound-ASE"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }
}

# ── OT1-NE Non-Prod Network Rules (RCG priority 4400) ────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_ne_ot1" {
  provider           = azurerm.secondary
  name               = "RCG-CI-NE-OUT-NET-OT1-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.cidmz_ne_v2.id
  priority           = 4400

  network_rule_collection {
    name     = "AllowHSBCSFTPOut"
    priority = 4410
    action   = "Allow"
    rule {
      name                  = "AllowHSBCSFTPOut"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.0.0/16"]
      destination_addresses = local.sftp_prod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "Allow-ASE-DB-Outbound"
    priority = 4420
    action   = "Allow"
    rule {
      name                  = "Allow-ASE-DB-Outbound"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "AllowAppInsightsLiveMetrics"
    priority = 4430
    action   = "Allow"
    rule {
      name                  = "AllowAppInsightsLiveMetrics"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.18.0/24"]
      destination_addresses = ["ApplicationInsightsAvailability"]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "AllowCertappsvc-sfc"
    priority = 4450
    action   = "Allow"
    rule {
      name                  = "AllowCertappsvc-sfc"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.0.0/16"]
      destination_addresses = ["AppService"]
      destination_ports     = ["80"]
    }
  }

  network_rule_collection {
    name     = "OUT-APP-APPINSIGHTS-INSTALL-OT1"
    priority = 4460
    action   = "Allow"
    rule {
      name                  = "OUT-APP-APPINSIGHTS-INSTALL-OT1"
      protocols             = ["TCP"]
      source_addresses      = ["10.212.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }
}

# =============================================================================
# CI-DMZ STANDARD — WEST EUROPE RULES
# Firewall: SI-DMZ-WE-FWSTD-01
# =============================================================================

# ── Application Outbound Rules (RCG priority 2100) ────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_we_app_out" {
  name               = "RCG-CI-WE-OUT-PRD-ALLOW-APP"
  firewall_policy_id = azurerm_firewall_policy.cidmz_we_v2.id
  priority           = 2100

  application_rule_collection {
    name     = "OUT-Tools-Platform"
    priority = 2110
    action   = "Allow"
    rule {
      name             = "OUT-Tools-Platform"
      source_addresses = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ci_we_tools_platform_fqdns
    }
  }

  application_rule_collection {
    name     = "OUT-AZURE-CONTROL-PLANE"
    priority = 2120
    action   = "Allow"
    rule {
      name             = "OUT-AZURE-CONTROL-PLANE"
      source_addresses = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureCloud"]
    }
  }

  application_rule_collection {
    name     = "OUT-AZURE-MONITOR"
    priority = 2130
    action   = "Allow"
    rule {
      name             = "OUT-AZURE-MONITOR"
      source_addresses = ["10.100.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdn_tags = ["AzureMonitor"]
    }
  }

  application_rule_collection {
    name     = "OUT-CRL-OCSP"
    priority = 2140
    action   = "Allow"
    rule {
      name             = "OUT-CRL-OCSP"
      source_addresses = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      protocols {
        type = "Http"
        port = "80"
      }
      protocols {
        type = "Https"
        port = "443"
      }
      destination_fqdns = local.ci_crl_fqdns
    }
  }
}

# ── Network Outbound Rules (RCG priority 2600) ────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_we_net_out" {
  name               = "RCG-CI-WE-OUT-PRD-ALLOW-NET"
  firewall_policy_id = azurerm_firewall_policy.cidmz_we_v2.id
  priority           = 2600

  network_rule_collection {
    name     = "OUT-INTERNAL-TO-CE-FW-WE"
    priority = 2610
    action   = "Allow"
    rule {
      name                  = "OUT-INTERNAL-TO-CE-FW-WE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.100.0.0/16", "10.150.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["10.200.50.10"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "AZURE-PLATFORM-PROD"
    priority = 2620
    action   = "Allow"
    rule {
      name                  = "AZURE-PLATFORM-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.6.0/24", "10.213.6.0/24", "10.215.6.0/24"]
      destination_addresses = local.ci_azure_platform_service_tags
      destination_ports     = ["80", "443"]
    }
  }

  network_rule_collection {
    name     = "AZURE-MONITOR-PROD"
    priority = 2625
    action   = "Allow"
    rule {
      name                  = "AZURE-MONITOR-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["AzureMonitor"]
      destination_ports     = ["80", "443"]
    }
  }

  network_rule_collection {
    name     = "CROWDSTRIKE-PRO"
    priority = 2630
    action   = "Allow"
    rule {
      name                  = "CROWDSTRIKE-PRO"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_ip_groups = [data.azurerm_ip_group.crowdstrike.id]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "DEVOPS-AGENT-PROD"
    priority = 2640
    action   = "Allow"
    rule {
      name                  = "DEVOPS-AGENT-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_ip_groups = [data.azurerm_ip_group.devops_agents.id]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "AZURE-LOGANALYTICS-PROD"
    priority = 2650
    action   = "Allow"
    rule {
      name                  = "AZURE-LOGANALYTICS-PROD"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["AzureCloud.WestEurope"]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "NTP-PROD"
    priority = 2660
    action   = "Allow"
    rule {
      name                  = "NTP-PROD"
      protocols             = ["UDP"]
      source_addresses      = ["10.100.0.0/16", "10.207.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["AzureCloud.UKWest", "AzureCloud.WestEurope"]
      destination_ports     = ["123"]
    }
  }
}

# ── Network Inbound Rules (RCG priority 2800) ─────────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_we_net_in" {
  name               = "RCG-CI-WE-IN-NET-PRD-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.cidmz_we_v2.id
  priority           = 2800

  network_rule_collection {
    name     = "IN-CE2C-NONPROXY"
    priority = 2810
    action   = "Allow"
    rule {
      name                  = "IN-CE2C-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.50.0/26"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "IN-INTERNAL2CI-NONPROXY"
    priority = 2820
    action   = "Allow"
    rule {
      name                  = "IN-INTERNAL2CI-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.100.0.0/16"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "IN-LB-HEALTH-PROBES"
    priority = 2830
    action   = "Allow"
    rule {
      name                  = "IN-LB-HEALTH-PROBES"
      protocols             = ["TCP"]
      source_addresses      = ["168.63.129.16/32"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["65200-65535"]
    }
  }

  network_rule_collection {
    name     = "IN-DNS-FROM-INFRA"
    priority = 2840
    action   = "Allow"
    rule {
      name                  = "IN-DNS-FROM-INFRA"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.0.0/16", "10.100.0.0/16"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["53"]
    }
  }

  network_rule_collection {
    name     = "IN-MGMT-IT-ADMIN"
    priority = 2850
    action   = "Allow"
    rule {
      name                  = "IN-MGMT-IT-ADMIN"
      protocols             = ["TCP"]
      source_ip_groups      = [data.azurerm_ip_group.vpn_uk.id, data.azurerm_ip_group.vpn_ind.id, data.azurerm_ip_group.vpn_hk.id]
      destination_addresses = ["10.200.11.96/26"]
      destination_ports     = ["22", "3389"]
    }
  }
}

# ── UT1 Non-Prod Network Rules (RCG priority 4300) ────────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_we_ut1" {
  name               = "RCG-CI-WE-OUT-NET-UT1-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.cidmz_we_v2.id
  priority           = 4300

  network_rule_collection {
    name     = "AllowHSCPSFTPOut"
    priority = 4310
    action   = "Allow"
    rule {
      name                  = "AllowHSCPSFTPOut"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.0.0/16"]
      destination_addresses = local.sftp_nonprod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "Allow-AppInsightsOut-ASE"
    priority = 4320
    action   = "Allow"
    rule {
      name                  = "Allow-AppInsightsOut-ASE"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "Allow-ASE-DB-Outbound"
    priority = 4330
    action   = "Allow"
    rule {
      name                  = "Allow-ASE-DB-Outbound"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "Allow-AppInsights-LiveMetrics"
    priority = 4340
    action   = "Allow"
    rule {
      name                  = "Allow-AppInsights-LiveMetrics"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.18.0/24"]
      destination_addresses = ["ApplicationInsightsAvailability"]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "AllowCertappsvcout-SFC"
    priority = 4350
    action   = "Allow"
    rule {
      name                  = "AllowCertappsvcout-SFC"
      protocols             = ["TCP"]
      source_addresses      = ["10.207.0.0/16"]
      destination_addresses = ["AppService"]
      destination_ports     = ["80"]
    }
  }
}

# ── OT1-WE Non-Prod Network Rules (RCG priority 4500) ────────────────────────
resource "azurerm_firewall_policy_rule_collection_group" "cidmz_we_ot1" {
  name               = "RCG-CI-WE-OUT-NET-OT1-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.cidmz_we_v2.id
  priority           = 4500

  network_rule_collection {
    name     = "HSBC-SFTP-OUTBOUND"
    priority = 4510
    action   = "Allow"
    rule {
      name                  = "HSBC-SFTP-OUTBOUND"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.0.0/16"]
      destination_addresses = local.sftp_prod_ips
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "ASE-SQL-OUTBOUND"
    priority = 4520
    action   = "Allow"
    rule {
      name                  = "ASE-SQL-OUTBOUND"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.18.0/24"]
      destination_addresses = ["Sql"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "APPINSIGHTS-LIVE-METRICS"
    priority = 4535
    action   = "Allow"
    rule {
      name                  = "APPINSIGHTS-LIVE-METRICS"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.18.0/24"]
      destination_addresses = ["ApplicationInsightsAvailability"]
      destination_ports     = ["443"]
    }
  }

  network_rule_collection {
    name     = "APPSERVICE-CERTIFICATE-VALIDATION"
    priority = 4540
    action   = "Allow"
    rule {
      name                  = "APPSERVICE-CERTIFICATE-VALIDATION"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.0.0/16"]
      destination_addresses = ["AppService"]
      destination_ports     = ["80"]
    }
  }

  network_rule_collection {
    name     = "APPINSIGHTS-EXTENSION-INSTALL"
    priority = 4550
    action   = "Allow"
    rule {
      name                  = "APPINSIGHTS-EXTENSION-INSTALL"
      protocols             = ["TCP"]
      source_addresses      = ["10.213.18.0/24"]
      destination_addresses = local.appinsights_install_ips
      destination_ports     = ["443"]
    }
  }
}
