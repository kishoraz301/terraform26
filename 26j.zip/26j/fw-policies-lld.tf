# Premium Firewall Policies - LLD Compliant Structure
# WE = West Europe, NE = North Europe
# Separate RCGs per priority tier to match LLD exactly

# ============================================================================
# DATA SOURCES
# ============================================================================

data "azurerm_resource_group" "cedmz_we" {
  name = "MIP-SI-WE-RG"
}

data "azurerm_resource_group" "cedmz_ne" {
  name = "MIP-SI-NE-RG"
}

# Firewall Public IPs (Static - hardcoded)
locals {
  prem_we_pip_address = "48.209.40.88"
  prem_ne_pip_address = "74.234.51.102"
}

# ============================================================================
# IP GROUPS - LLD compliant VPN source groups
# ============================================================================

resource "azurerm_ip_group" "ipg_uk_vpn" {
  name                = "IPG-UK-VPN"
  location            = data.azurerm_resource_group.cedmz_we.location
  resource_group_name = data.azurerm_resource_group.cedmz_we.name
  cidrs               = local.uk_vpn_ranges
}

resource "azurerm_ip_group" "ipg_ind_vpn" {
  name                = "IPG-IND-VPN"
  location            = data.azurerm_resource_group.cedmz_we.location
  resource_group_name = data.azurerm_resource_group.cedmz_we.name
  cidrs               = local.ind_vpn_ranges
}

resource "azurerm_ip_group" "ipg_hk_vpn" {
  name                = "IPG-HK-VPN"
  location            = data.azurerm_resource_group.cedmz_we.location
  resource_group_name = data.azurerm_resource_group.cedmz_we.name
  cidrs               = local.hk_vpn_ranges
}

# Reference EXISTING firewall policies (using data sources - policies must already exist in Azure)
# Do NOT create them with resource - they should be created separately and managed outside Terraform
data "azurerm_firewall_policy" "prem_we_policy" {
  name                = "SI-CEDMZ-FWPLCY-WE"
  resource_group_name = data.azurerm_resource_group.cedmz_we.name
}

data "azurerm_firewall_policy" "prem_ne_policy" {
  name                = "SI-CEDMZ-FWPLCY-NE"
  resource_group_name = data.azurerm_resource_group.cedmz_ne.name
}

# ============================================================================
# WEST EUROPE - PRIORITY 1000: DNAT INBOUND NAT RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_we_rcg_dnat" {
  name               = "RCG-DNAT-WE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_we_policy.id
  priority           = 1000

  nat_rule_collection {
    name     = "DNAT-RDS"
    priority = 1001
    action   = "Dnat"

    rule {
      name                = "DNAT-RDS-HTTPS443-UK"
      protocols           = ["TCP"]
      source_ip_groups    = [azurerm_ip_group.ipg_uk_vpn.id]
      destination_address = local.prem_we_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }

    rule {
      name                = "DNAT-RDS-HTTPS443-IND"
      protocols           = ["TCP"]
      source_ip_groups    = [azurerm_ip_group.ipg_ind_vpn.id]
      destination_address = local.prem_we_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }

    rule {
      name                = "DNAT-RDS-HTTPS443-HK"
      protocols           = ["TCP"]
      source_ip_groups    = [azurerm_ip_group.ipg_hk_vpn.id]
      destination_address = local.prem_we_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }
}

# ============================================================================
# WEST EUROPE - PRIORITY 100: OUTBOUND APPLICATION RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_we_rcg_app" {
  name               = "RCG-CE-DMZ-OUT-PROD-APP-NE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_we_policy.id
  priority           = 100

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-BUSINESS"
    priority = 100
    action   = "Allow"

    rule {
      name             = "Business"
      source_addresses = ["10.200.11.0/26"]
      destination_fqdns = [
        "valuationapi.hometrack.com", "hsbc.server115.net", "hsbcuat.server115.net",
        "api.mls.hometrack.com", "api.pre.mls.hometrack.com", "api.uat.mls.hometrack.com",
        "secure.authenticator.uk.experian.com", "secure.authenticator.uat.uk.experian.com",
        "bankwizardondemand.uk.experian.com", "uat.bankwizardondemand.uk.experian.com",
        "webportal.gb.co.uk", "api.addressy.com", "idm.gb.co.uk",
        "digitalprod-b2b-api.hsbc.co.uk", "digitaldev-b2b-api.p2g.netd2.hsbc.com.hk",
        "rbwm-b2b-api.hsbc.co.uk", "digitaluat-b2b-api.p2g.netd2.hsbc.com.hk",
        "srq1.lms.com", "lmu.lms.com", "hpp.sandbox.globaliris.com",
        "eu.sms.sdi.sinch.com", "sms-pp.sapmobileservices.com",
        "hsbcuk.queue-it.net", "hsbucketst.queue-it.net",
        "*.intermediaries.hsbc.co.uk", "*.intermediaries-nft.hsbc.co.uk",
        "*.intermediaries-sit1.hsbc.co.uk", "*.intermediaries-sit2.hsbc.co.uk",
        "*.intermediaries-uat.hsbc.co.uk"
      ]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-UBUNTU-UPDATES"
    priority = 110
    action   = "Allow"

    rule {
      name              = "Ubuntu"
      source_addresses  = ["10.200.11.0/26"]
      destination_fqdns = ["archive.ubuntu.com", "security.ubuntu.com", "*.archive.ubuntu.com", "*.security.ubuntu.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TLS-CRL-OCSP"
    priority = 120
    action   = "Allow"

    rule {
      name              = "TLS"
      source_addresses  = ["10.200.11.0/24"]
      destination_fqdns = ["ocsp.digicert.com", "crl3.digicert.com", "crl4.digicert.com", "ocsp.sectigo.com", "crl.sectigo.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-AAD-GRAPH"
    priority = 130
    action   = "Allow"

    rule {
      name              = "AAD"
      source_addresses  = ["10.200.11.0/26"]
      destination_fqdns = ["login.microsoftonline.com", "graph.microsoft.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-CROWDSTRIKE-WE"
    priority = 135
    action   = "Allow"

    rule {
      name              = "CrowdStrike"
      source_addresses  = ["10.200.11.64/27"]
      destination_fqdns = ["ts01-lanner-lion.cloudsink.net", "lfodown01-lanner-lion.cloudsink.net", "lfoup01-lanner-lion.cloudsink.net", "assets.falcon.eu-1.crowdstrike.com", "assets-public.falcon.eu-1.crowdstrike.com", "api.eu-1.crowdstrike.com", "firehose.eu-1.crowdstrike.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TOOLS-PLATFORM"
    priority = 140
    action   = "Allow"

    rule {
      name              = "Platform"
      source_addresses  = ["10.200.60.0/26", "10.200.12.192/26", "10.200.12.0/26"]
      destination_fqdns = ["www.powershellgallery.com", "devopsagentstorage.blob.core.windows.net", "vstagentpackage.azureedge.net", "winatp-gw-weu.microsoft.com", "ava-hsbc.visualstudio.com", "download.microsoft.com", "azure.microsoft.com", "*.nuget.org", "if-api-preprod.hsbc.co.uk", "if-api.hsbc.co.uk", "hap-preprod-api.hsbc.co.uk", "hap-api.hsbc.co.uk", "sourceforge.net", "www.postman.com", "www.red-gate.com", "*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com", "*.agentsvc.azure-automation.net", "*.blob.core.windows.net"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-FW-AZURE-MONITOR"
    priority = 145
    action   = "Allow"

    rule {
      name                  = "Monitor"
      source_addresses      = ["10.200.50.0/26"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-RDS-CONTROL-PLANE"
    priority = 150
    action   = "Allow"

    rule {
      name                  = "RDSControl"
      source_addresses      = ["10.200.11.64/27"]
      destination_fqdn_tags = ["WindowsVirtualDesktop"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-LOG-ANALYTICS"
    priority = 160
    action   = "Allow"

    rule {
      name                  = "LogAnalytics"
      source_addresses      = ["10.200.11.0/24"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  network_rule_collection {
    name     = "OUT-DENY-ALL-WE"
    priority = 4096
    action   = "Deny"

    rule {
      name                  = "DenyAllOutbound"
      protocols             = ["Any"]
      source_addresses      = ["*"]
      destination_addresses = ["*"]
      destination_ports     = ["*"]
    }
  }
}

# ============================================================================
# WEST EUROPE - PRIORITY 300: OUTBOUND NETWORK RULES (FTP/SFTP)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_we_rcg_ftp" {
  name               = "RCG-CE-DMZ-OUT-FTP-WE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_we_policy.id
  priority           = 300

  network_rule_collection {
    name     = "OUT-FTP-SFTP"
    priority = 310
    action   = "Allow"

    rule {
      name                  = "FTP-WE-dev"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["161.113.228.48"]
      destination_ports     = ["10022"]
    }

    rule {
      name                  = "FTP-WE-prod"
      protocols             = ["TCP"]
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["193.108.76.149", "91.214.5.149"]
      destination_ports     = ["10022"]
    }
  }
}

# ============================================================================
# WEST EUROPE - PRIORITY 4000: DENY ALL INBOUND (Implicit - default deny)
# Note: Azure Firewall denies all unspecified inbound traffic by default.
# NAT rules with wildcard syntax not supported in Azure Firewall Policy.
# ============================================================================
# Deny-all functionality is implicit in Azure Firewall - no explicit rule needed

# ============================================================================
# NORTH EUROPE - PRIORITY 1000: DNAT INBOUND NAT RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_dnat" {
  name               = "RCG-DNAT-NE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 1000

  nat_rule_collection {
    name     = "DNAT-RDS"
    priority = 1001
    action   = "Dnat"

    rule {
      name                = "DNAT-RDS-HTTPS443-UK-NE"
      protocols           = ["TCP"]
      source_ip_groups    = [azurerm_ip_group.ipg_uk_vpn.id]
      destination_address = local.prem_ne_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.12.80"
      translated_port     = "443"
    }

    rule {
      name                = "DNAT-RDS-HTTPS443-IND-NE"
      protocols           = ["TCP"]
      source_ip_groups    = [azurerm_ip_group.ipg_ind_vpn.id]
      destination_address = local.prem_ne_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.12.80"
      translated_port     = "443"
    }

    rule {
      name                = "DNAT-RDS-HTTPS443-HK-NE"
      protocols           = ["TCP"]
      source_ip_groups    = [azurerm_ip_group.ipg_hk_vpn.id]
      destination_address = local.prem_ne_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.12.80"
      translated_port     = "443"
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 100: OUTBOUND APPLICATION RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_app" {
  name               = "RCG-CE-DMZ-OUT-PROD-APP-NE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 100

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-BUSINESS"
    priority = 100
    action   = "Allow"

    rule {
      name             = "Business"
      source_addresses = ["10.200.12.0/26"]
      destination_fqdns = [
        "valuationapi.hometrack.com", "hsbc.server115.net", "hsbcuat.server115.net",
        "api.mls.hometrack.com", "api.pre.mls.hometrack.com", "api.uat.mls.hometrack.com",
        "secure.authenticator.uk.experian.com", "secure.authenticator.uat.uk.experian.com",
        "bankwizardondemand.uk.experian.com", "uat.bankwizardondemand.uk.experian.com",
        "webportal.gb.co.uk", "api.addressy.com", "idm.gb.co.uk",
        "digitalprod-b2b-api.hsbc.co.uk", "digitaldev-b2b-api.p2g.netd2.hsbc.com.hk",
        "rbwm-b2b-api.hsbc.co.uk", "digitaluat-b2b-api.p2g.netd2.hsbc.com.hk",
        "srq1.lms.com", "lmu.lms.com", "hpp.sandbox.globaliris.com",
        "eu.sms.sdi.sinch.com", "sms-pp.sapmobileservices.com",
        "hsbcuk.queue-it.net", "hsbucketst.queue-it.net",
        "*.intermediaries.hsbc.co.uk", "*.intermediaries-nft.hsbc.co.uk",
        "*.intermediaries-sit1.hsbc.co.uk", "*.intermediaries-sit2.hsbc.co.uk",
        "*.intermediaries-uat.hsbc.co.uk"
      ]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-UBUNTU-UPDATES"
    priority = 110
    action   = "Allow"

    rule {
      name              = "Ubuntu"
      source_addresses  = ["10.200.12.0/26"]
      destination_fqdns = ["archive.ubuntu.com", "security.ubuntu.com", "*.archive.ubuntu.com", "*.security.ubuntu.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TLS-CRL-OCSP"
    priority = 120
    action   = "Allow"

    rule {
      name              = "TLS"
      source_addresses  = ["10.200.12.0/24"]
      destination_fqdns = ["ocsp.digicert.com", "crl3.digicert.com", "crl4.digicert.com", "ocsp.sectigo.com", "crl.sectigo.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-AAD-GRAPH"
    priority = 130
    action   = "Allow"

    rule {
      name              = "AAD"
      source_addresses  = ["10.200.12.0/26"]
      destination_fqdns = ["login.microsoftonline.com", "graph.microsoft.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-CROWDSTRIKE-NE"
    priority = 135
    action   = "Allow"

    rule {
      name              = "CrowdStrike"
      source_addresses  = ["10.200.12.64/27"]
      destination_fqdns = ["ts01-lanner-lion.cloudsink.net", "lfodown01-lanner-lion.cloudsink.net", "lfoup01-lanner-lion.cloudsink.net", "assets.falcon.eu-1.crowdstrike.com", "assets-public.falcon.eu-1.crowdstrike.com", "api.eu-1.crowdstrike.com", "firehose.eu-1.crowdstrike.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-TOOLS-PLATFORM"
    priority = 140
    action   = "Allow"

    rule {
      name              = "Platform"
      source_addresses  = ["10.200.60.0/26", "10.200.12.192/26", "10.200.12.0/26"]
      destination_fqdns = ["www.powershellgallery.com", "devopsagentstorage.blob.core.windows.net", "vstagentpackage.azureedge.net", "winatp-gw-weu.microsoft.com", "ava-hsbc.visualstudio.com", "download.microsoft.com", "azure.microsoft.com", "*.nuget.org", "if-api-preprod.hsbc.co.uk", "if-api.hsbc.co.uk", "hap-preprod-api.hsbc.co.uk", "hap-api.hsbc.co.uk", "sourceforge.net", "www.postman.com", "www.red-gate.com", "*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com", "*.agentsvc.azure-automation.net", "*.blob.core.windows.net"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-FW-AZURE-MONITOR"
    priority = 145
    action   = "Allow"

    rule {
      name                  = "Monitor"
      source_addresses      = ["10.200.60.0/26"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-RDS-CONTROL-PLANE"
    priority = 150
    action   = "Allow"

    rule {
      name                  = "RDSControl"
      source_addresses      = ["10.200.12.64/27"]
      destination_fqdn_tags = ["WindowsVirtualDesktop"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-LOG-ANALYTICS"
    priority = 160
    action   = "Allow"

    rule {
      name                  = "LogAnalytics"
      source_addresses      = ["10.200.12.0/24"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-TESTING"
    priority = 170
    action   = "Allow"

    rule {
      name             = "Testing"
      source_addresses = ["10.200.12.30", "10.200.12.43", "10.200.12.44", "10.200.12.35", "10.200.12.36"]
      destination_fqdns = ["api.ipify.org"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  network_rule_collection {
    name     = "OUT-DENY-ALL-NE"
    priority = 4096
    action   = "Deny"

    rule {
      name                  = "DenyAllOutbound"
      protocols             = ["Any"]
      source_addresses      = ["*"]
      destination_addresses = ["*"]
      destination_ports     = ["*"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 300: OUTBOUND NETWORK RULES (FTP/SFTP)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_ftp" {
  name               = "RCG-CE-DMZ-OUT-FTP-NE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 300

  network_rule_collection {
    name     = "OUT-FTP-SFTP"
    priority = 310
    action   = "Allow"

    rule {
      name                  = "FTP-NE-dev"
      protocols             = ["TCP"]
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["161.113.228.48"]
      destination_ports     = ["10022"]
    }

    rule {
      name                  = "FTP-NE-prod"
      protocols             = ["TCP"]
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_addresses = ["193.108.76.149", "91.214.5.149"]
      destination_ports     = ["10022"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 200: NON-PROD OUTBOUND APPLICATION RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_app_nonprod" {
  name               = "RCG-CE-DMZ-OUT-APP-NE-NONPROD"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 200

  application_rule_collection {
    name     = "OUT-APP-TOOLS-PLATFORM-NONPROD"
    priority = 210
    action   = "Allow"

    rule {
      name             = "ToolsPlatformNonProd"
      source_addresses = ["10.210.6.0/24"]
      destination_fqdns = [
        "www.powershellgallery.com", "devopsagentstorage.blob.core.windows.net", "vstagentpackage.azureedge.net",
        "winatp-gw-weu.microsoft.com", "ava-hsbc.visualstudio.com", "download.microsoft.com", "azure.microsoft.com",
        "*.nuget.org", "if-api-preprod.hsbc.co.uk", "if-api.hsbc.co.uk", "hap-preprod-api.hsbc.co.uk", "hap-api.hsbc.co.uk",
        "sourceforge.net", "www.postman.com", "www.red-gate.com",
        "*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com", "*.agentsvc.azure-automation.net",
        "*.blob.core.windows.net", "*.azure.com", "*.microsoft.com", "*.windows.net", "*.microsoftonline.com",
        "*.windowsupdate.com", "ecs.office.com"
      ]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-WHITELIST-TESTING-NONPROD"
    priority = 220
    action   = "Allow"

    rule {
      name             = "TestingNonProd"
      source_addresses = ["10.210.6.0/24", "10.210.0.0/16"]
      destination_fqdns = ["api.ipify.org"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-QUEUEIT-NONPROD"
    priority = 230
    action   = "Allow"

    rule {
      name             = "QueueIT"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = ["*.api.queue-it.net", "*.queue-it.net"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-CERT-CRL-NONPROD"
    priority = 240
    action   = "Allow"

    rule {
      name             = "CertCRL"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = ["crl3.digicert.com", "crl4.digicert.com", "ocsp.digicert.com", "crl.sectigo.com", "ocsp.sectigo.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-AZURE-STORAGE-NONPROD"
    priority = 250
    action   = "Allow"

    rule {
      name             = "AzureStorage"
      source_addresses = ["10.210.5.0/24", "10.210.0.0/16"]
      destination_fqdns = ["*.blob.core.windows.net", "*.file.core.windows.net"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-APP-AZURE-MONITOR-EXTENDED"
    priority = 260
    action   = "Allow"

    rule {
      name             = "MonitorExtended"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = ["*.monitor.azure.com", "*.oms.opinsights.azure.com", "*.ods.opinsights.azure.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 500: OUTBOUND NETWORK RULES (AZURE MANAGEMENT & INTERNET)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_internet" {
  name               = "RCG-CI-DMZ-OUT-INTERNET"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 500

  network_rule_collection {
    name     = "OUT-AZURE-MANAGEMENT"
    priority = 500
    action   = "Allow"

    rule {
      name                  = "AzureManagement"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.6.0/24", "10.200.12.192/26"]
      destination_addresses = ["Storage", "ServiceBus", "AzureActiveDirectory", "AzureCloud", "ServiceFabric"]
      destination_ports     = ["80", "443"]
    }
  }

  network_rule_collection {
    name     = "OUT-SQUID-TO-INTERNET"
    priority = 510
    action   = "Allow"

    rule {
      name                  = "SquidToInternet"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.210.6.0/24"]
      destination_addresses = ["AzureCloud"]
      destination_ports     = ["*"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 600: NON-PROD OUTBOUND NETWORK RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_net_nonprod" {
  name               = "RCG-CI-DMZ-OUT-NET-ST4"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 600

  network_rule_collection {
    name     = "OUT-AZURE-MANAGEMENT-NONPROD"
    priority = 610
    action   = "Allow"

    rule {
      name                  = "AzureManagementNonProd"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.6.0/24", "10.207.6.0/24", "10.212.6.0/24", "10.213.6.0/24"]
      destination_addresses = ["Storage", "ServiceBus", "AzureActiveDirectory", "AzureCloud", "ServiceFabric"]
      destination_ports     = ["80", "443"]
    }
  }

  network_rule_collection {
    name     = "OUT-SQUID-TO-INTERNET-NONPROD"
    priority = 620
    action   = "Allow"

    rule {
      name                  = "SquidToInternetNonProd"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.210.6.0/24", "10.207.6.0/24", "10.212.6.0/24", "10.213.6.0/24"]
      destination_addresses = ["AzureCloud"]
      destination_ports     = ["*"]
    }
  }

  network_rule_collection {
    name     = "OUT-SFTP-OMIGADB-NONPROD"
    priority = 630
    action   = "Allow"

    rule {
      name                  = "SFTPOmigadb"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.5.0/24"]
      destination_addresses = ["161.113.228.48", "161.113.239.62"]
      destination_ports     = ["10022"]
    }
  }

  network_rule_collection {
    name     = "OUT-STORAGE-SMB-NONPROD"
    priority = 640
    action   = "Allow"

    rule {
      name                  = "StorageSMB"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope"]
      destination_ports     = ["445"]
    }
  }

  network_rule_collection {
    name     = "OUT-SQL-NONPROD"
    priority = 650
    action   = "Allow"

    rule {
      name                  = "SQLOutbound"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.18.0/24"]
      destination_addresses = ["SQL"]
      destination_ports     = ["1433"]
    }
  }

  network_rule_collection {
    name     = "OUT-NTP-TIME-SYNC-NONPROD"
    priority = 660
    action   = "Allow"

    rule {
      name                  = "NTPTimeSync"
      protocols             = ["UDP"]
      source_addresses      = ["10.210.18.0/24", "10.210.0.0/16"]
      destination_addresses = ["AzureCloud.ukwest"]
      destination_ports     = ["123"]
    }
  }

  network_rule_collection {
    name     = "OUT-DEVOPS-AGENT-FALLBACK"
    priority = 670
    action   = "Allow"

    rule {
      name                  = "DevOpsAgentFallback"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.0.0/16"]
      source_ip_groups      = [azurerm_ip_group.ipg_ci_devops_agents.id]
      destination_ports     = ["443"]
    }
  }
}
