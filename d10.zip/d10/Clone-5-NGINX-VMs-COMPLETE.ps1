<#
.SYNOPSIS
    Clone 5 NGINX VMs - Complete Marketplace Details Extraction and Application
.DESCRIPTION
    Extracts ALL marketplace information from source VM and applies comprehensively to cloned VM
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId
)

Set-AzContext -SubscriptionId $SubscriptionId | Out-Null

$vmCloneConfig = @(
    @{
        SourceVMName = "SI-RPRXY-VM-54"
        TargetVMName = "SI-RPRXY-VM-59"
        SourceResourceGroup = "si-rprxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.4"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-55"
        TargetVMName = "SI-RPRXY-VM-60"
        SourceResourceGroup = "si-rprxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.5"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-05"
        TargetVMName = "SI-RPRXY-VM-10"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.4"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-06"
        TargetVMName = "SI-RPRXY-VM-11"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.5"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-RPRXY-VM-04"
        TargetVMName = "SI-RPRXY-VM-09"
        SourceResourceGroup = "si-rprxy-we-rg"
        TargetResourceGroup = "si-dmz-rprxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.8"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    }
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $output = "[$timestamp] [$Level] $Message"
    
    switch ($Level) {
        "SUCCESS" { Write-Host $output -ForegroundColor Green }
        "ERROR" { Write-Host $output -ForegroundColor Red }
        "WARNING" { Write-Host $output -ForegroundColor Yellow }
        default { Write-Host $output -ForegroundColor Cyan }
    }
}

function Get-SourceVMMarketplaceDetails {
    param([PSObject]$SourceVM, [string]$SourceVMName)
    
    Write-Log "======= EXTRACTING ALL MARKETPLACE DETAILS =======" "INFO"
    
    $details = @{
        HasPlan = $false
        Publisher = $null
        Product = $null
        Name = $null
        AllProperties = $null
    }
    
    if ($null -eq $SourceVM.Plan) {
        Write-Log "SOURCE VM PLAN OBJECT IS NULL!" "WARNING"
        return $details
    }
    
    Write-Log "Plan object exists: YES" "SUCCESS"
    Write-Log "Plan object type: $($SourceVM.Plan.GetType())" "INFO"
    
    # Extract individual properties
    $details.Publisher = $SourceVM.Plan.Publisher
    $details.Product = $SourceVM.Plan.Product
    $details.Name = $SourceVM.Plan.Name
    
    # Log all properties
    Write-Log "Publisher: '$($details.Publisher)' [Type: $($details.Publisher.GetType())]" "INFO"
    Write-Log "Product: '$($details.Product)' [Type: $($details.Product.GetType())]" "INFO"
    Write-Log "Name: '$($details.Name)' [Type: $($details.Name.GetType())]" "INFO"
    
    # Check for nulls/emptiness
    $publisherEmpty = [string]::IsNullOrWhiteSpace($details.Publisher)
    $productEmpty = [string]::IsNullOrWhiteSpace($details.Product)
    $nameEmpty = [string]::IsNullOrWhiteSpace($details.Name)
    
    Write-Log "Publisher is empty: $publisherEmpty" "INFO"
    Write-Log "Product is empty: $productEmpty" "INFO"
    Write-Log "Name is empty: $nameEmpty" "INFO"
    
    # Get full JSON representation
    $planJson = $SourceVM.Plan | ConvertTo-Json -Depth 10
    Write-Log "Full Plan JSON:`n$planJson" "INFO"
    
    if (-not $publisherEmpty -and -not $productEmpty -and -not $nameEmpty) {
        $details.HasPlan = $true
        Write-Log "✓ ALL MARKETPLACE DETAILS EXTRACTED SUCCESSFULLY" "SUCCESS"
    } else {
        Write-Log "✗ MISSING MARKETPLACE DETAILS!" "ERROR"
    }
    
    Write-Log "===================================================" "INFO"
    
    return $details
}

function New-VMSnapshot {
    param([string]$SnapshotName, [string]$SourceDiskId, [string]$TargetResourceGroup, [string]$Location)
    
    try {
        $existingSnapshot = Get-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction SilentlyContinue
        if ($existingSnapshot) {
            Write-Log "Removing existing snapshot: $SnapshotName" "WARNING"
            Remove-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 3
        }
        
        $snapshotConfig = New-AzSnapshotConfig -SourceResourceId $SourceDiskId -Location $Location -CreateOption Copy
        $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName -ErrorAction Stop
        Write-Log "Snapshot created: $($snapshot.Id)" "SUCCESS"
        return $snapshot
    }
    catch {
        Write-Log "Error creating snapshot: $_" "ERROR"
        throw
    }
}

function New-VMDiskFromSnapshot {
    param([string]$DiskName, [string]$SnapshotId, [string]$TargetResourceGroup, [string]$Location, [string]$DiskType)
    
    try {
        $diskConfig = New-AzDiskConfig -SourceResourceId $SnapshotId -Location $Location -CreateOption Copy -SkuName $DiskType
        $disk = New-AzDisk -Disk $diskConfig -ResourceGroupName $TargetResourceGroup -DiskName $DiskName -ErrorAction Stop
        Write-Log "Disk created: $($disk.Id)" "SUCCESS"
        
        # Verify
        $maxRetries = 15
        $retryCount = 0
        while ($retryCount -lt $maxRetries) {
            $chk = Get-AzDisk -Name $DiskName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($chk) {
                Write-Log "Disk verified" "SUCCESS"
                return $disk
            }
            Start-Sleep -Seconds 2
            $retryCount++
        }
        
        Write-Log "Disk verification timeout" "WARNING"
        return $disk
    }
    catch {
        Write-Log "Error creating disk: $_" "ERROR"
        throw
    }
}

function New-VMNetworkInterface {
    param([string]$NICName, [string]$TargetVNetName, [string]$TargetSubnetName, [string]$TargetResourceGroup, [string]$VNetResourceGroup, [string]$PrivateIP, [string]$Location)
    
    try {
        $vnet = Get-AzVirtualNetwork -Name $TargetVNetName -ResourceGroupName $VNetResourceGroup -ErrorAction Stop
        $subnet = Get-AzVirtualNetworkSubnetConfig -VirtualNetwork $vnet -Name $TargetSubnetName -ErrorAction Stop
        
        $nicConfig = New-AzNetworkInterfaceIpConfig -Name "ipconfig1" -PrivateIpAddress $PrivateIP -Subnet $subnet -Primary
        $nic = New-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -Location $Location -IpConfiguration $nicConfig -ErrorAction Stop
        Write-Log "NIC created: $($nic.Id)" "SUCCESS"
        
        # Verify
        $maxRetries = 10
        $retryCount = 0
        while ($retryCount -lt $maxRetries) {
            $chk = Get-AzNetworkInterface -Name $NICName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($chk) {
                Write-Log "NIC verified" "SUCCESS"
                return $nic
            }
            Start-Sleep -Seconds 1
            $retryCount++
        }
        
        Write-Log "NIC verification timeout" "WARNING"
        return $nic
    }
    catch {
        Write-Log "Error creating NIC: $_" "ERROR"
        throw
    }
}

function New-ClonedVM {
    param(
        [string]$VMName,
        [string]$DiskId,
        [string]$NICId,
        [string]$TargetResourceGroup,
        [string]$Location,
        [string]$VMSize,
        [string]$OSType,
        [PSObject]$MarketplaceDetails
    )
    
    try {
        Write-Log "Creating VM: $VMName" "INFO"
        Write-Log "  Size: $VMSize, OS: $OSType" "INFO"
        
        $vmConfig = New-AzVMConfig -VMName $VMName -VMSize $VMSize
        Write-Log "VM Config created" "INFO"
        
        # CRITICAL: Apply marketplace plan BEFORE disk attachment
        if ($MarketplaceDetails.HasPlan) {
            Write-Log "Applying complete marketplace plan to VM config" "INFO"
            Write-Log "  Publisher: $($MarketplaceDetails.Publisher)" "INFO"
            Write-Log "  Product: $($MarketplaceDetails.Product)" "INFO"
            Write-Log "  Name: $($MarketplaceDetails.Name)" "INFO"
            
            $vmConfig = Set-AzVMPlan -VM $vmConfig `
                -Publisher $MarketplaceDetails.Publisher `
                -Product $MarketplaceDetails.Product `
                -Name $MarketplaceDetails.Name `
                -ErrorAction Stop
            
            Write-Log "✓ Plan applied to VM config" "SUCCESS"
        } else {
            Write-Log "⚠ NO MARKETPLACE PLAN TO APPLY - VM may fail" "WARNING"
        }
        
        # Attach OS disk
        Write-Log "Attaching OS disk" "INFO"
        if ($OSType -eq "Linux") {
            $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $DiskId -CreateOption Attach -Linux -ErrorAction Stop
        } else {
            $vmConfig = Set-AzVMOSDisk -VM $vmConfig -ManagedDiskId $DiskId -CreateOption Attach -Windows -ErrorAction Stop
        }
        Write-Log "OS disk attached" "SUCCESS"
        
        # Attach NIC
        Write-Log "Attaching network interface" "INFO"
        $vmConfig = Add-AzVMNetworkInterface -VM $vmConfig -Id $NICId -Primary -ErrorAction Stop
        Write-Log "NIC attached" "SUCCESS"
        
        # Create VM
        Write-Log "Submitting VM creation to Azure..." "INFO"
        $vm = New-AzVM -ResourceGroupName $TargetResourceGroup -VM $vmConfig -Location $Location -AsJob
        
        Write-Log "VM creation submitted (async, waiting...)" "INFO"
        $vmJob = Get-Job | Where-Object { $_.Command -like "*New-AzVM*" } | Select-Object -First 1
        
        if ($vmJob) {
            $vmJob | Wait-Job | Out-Null
            $vmResult = Receive-Job -Job $vmJob
            
            Write-Log "✓ VM CREATION COMPLETED" "SUCCESS"
            
            # Verify
            Start-Sleep -Seconds 5
            $createdVM = Get-AzVM -Name $VMName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            
            if ($createdVM) {
                Write-Log "✓ VM VERIFIED IN RESOURCE GROUP" "SUCCESS"
                Write-Log "  Provisioning State: $($createdVM.ProvisioningState)" "INFO"
                Write-Log "  PowerState: $($createdVM.PowerState)" "INFO"
                return $createdVM
            } else {
                Write-Log "✗ VM NOT FOUND AFTER CREATION" "ERROR"
                throw "VM creation completed but VM not found in resource group"
            }
        } else {
            throw "VM job not found"
        }
    }
    catch {
        Write-Log "Error creating VM: $_" "ERROR"
        throw
    }
}

# Main execution
Write-Log "========== NGINX VM CLONING WITH COMPLETE MARKETPLACE DETAILS ==========" "INFO"

$successCount = 0
$failureCount = 0

foreach ($vm in $vmCloneConfig) {
    Write-Log "" "INFO"
    Write-Log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" "INFO"
    Write-Log "CLONING: $($vm.SourceVMName) → $($vm.TargetVMName)" "INFO"
    Write-Log "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" "INFO"
    
    try {
        # Get source VM
        Write-Log "Getting source VM..." "INFO"
        $sourceVM = Get-AzVM -Name $vm.SourceVMName -ResourceGroupName $vm.SourceResourceGroup -ErrorAction Stop
        Write-Log "Source VM retrieved" "SUCCESS"
        
        $osDiskId = $sourceVM.StorageProfile.OsDisk.ManagedDisk.Id
        $osType = $sourceVM.StorageProfile.OsDisk.OsType
        $vmSize = $sourceVM.HardwareProfile.VmSize
        
        Write-Log "Source VM properties: Size=$vmSize, OS=$osType" "INFO"
        
        # Extract ALL marketplace details
        $marketplaceDetails = Get-SourceVMMarketplaceDetails -SourceVM $sourceVM -SourceVMName $vm.SourceVMName
        
        # Create snapshot
        $snapshotName = "$($vm.TargetVMName)-snap"
        $snapshot = New-VMSnapshot -SnapshotName $snapshotName -SourceDiskId $osDiskId -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location
        
        # Create disk
        $diskName = "$($vm.TargetVMName)-osdisk"
        $disk = New-VMDiskFromSnapshot -DiskName $diskName -SnapshotId $snapshot.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -DiskType $vm.DiskType
        
        # Create NIC
        $nicName = "$($vm.TargetVMName)-nic"
        $nic = New-VMNetworkInterface -NICName $nicName -TargetVNetName $vm.TargetVNetName -TargetSubnetName $vm.TargetSubnetName -TargetResourceGroup $vm.TargetResourceGroup -VNetResourceGroup $vm.VNetResourceGroup -PrivateIP $vm.TargetPrivateIP -Location $vm.Location
        
        # Create VM with marketplace details
        $clonedVM = New-ClonedVM -VMName $vm.TargetVMName -DiskId $disk.Id -NICId $nic.Id -TargetResourceGroup $vm.TargetResourceGroup -Location $vm.Location -VMSize $vmSize -OSType $osType -MarketplaceDetails $marketplaceDetails
        
        Write-Log "✓ SUCCESS: $($vm.TargetVMName) cloned successfully" "SUCCESS"
        $successCount++
    }
    catch {
        Write-Log "✗ FAILED: $($vm.TargetVMName)" "ERROR"
        Write-Log "  Error: $_" "ERROR"
        $failureCount++
    }
}

Write-Log "" "INFO"
Write-Log "╔════════════════════════════════════════════════╗" "INFO"
Write-Log "║          EXECUTION COMPLETE                    ║" "INFO"
Write-Log "║  Success: $successCount | Failed: $failureCount" "INFO"
Write-Log "╚════════════════════════════════════════════════╝" "INFO"
