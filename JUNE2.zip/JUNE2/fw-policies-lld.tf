# Premium Firewall Policies - NE ONLY (North Europe)
# SI-CEDMZ-FWPLCY-NE - Existing policy, we add/update RCGs only

# ============================================================================
# DATA SOURCES
# ============================================================================

data "azurerm_resource_group" "cedmz_ne" {
  name = "MIP-SI-NE-RG"
}

# Firewall Public IP (Static - hardcoded)
locals {
  prem_ne_pip_address = "74.234.51.102"
}

# ============================================================================
# IP GROUPS - Reference existing VPN source groups (in WE RG)
# ============================================================================

data "azurerm_ip_group" "ipg_uk_vpn" {
  name                = "IPG-UK-VPN"
  resource_group_name = "MIP-SI-WE-RG"
}

data "azurerm_ip_group" "ipg_ind_vpn" {
  name                = "IPG-IND-VPN"
  resource_group_name = "MIP-SI-WE-RG"
}

data "azurerm_ip_group" "ipg_hk_vpn" {
  name                = "IPG-HK-VPN"
  resource_group_name = "MIP-SI-WE-RG"
}

# ============================================================================
# REFERENCE EXISTING PREMIUM NE FIREWALL POLICY (data source only)
# ============================================================================

data "azurerm_firewall_policy" "prem_ne_policy" {
  name                = "SI-CEDMZ-FWPLCY-NE"
  resource_group_name = data.azurerm_resource_group.cedmz_ne.name
}

# ============================================================================
# NORTH EUROPE - PRIORITY 1000: DNAT INBOUND NAT RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_dnat" {
  name               = "RCG-DNAT-NE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 1000

  nat_rule_collection {
    name     = "DNAT-RDS"
    priority = 1001
    action   = "Dnat"

    rule {
      name                = "DNAT-RDS-HTTPS443-UK-NE"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.ipg_uk_vpn.id]
      destination_address = local.prem_ne_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }

    rule {
      name                = "DNAT-RDS-HTTPS443-IND-NE"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.ipg_ind_vpn.id]
      destination_address = local.prem_ne_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }

    rule {
      name                = "DNAT-RDS-HTTPS443-HK-NE"
      protocols           = ["TCP"]
      source_ip_groups    = [data.azurerm_ip_group.ipg_hk_vpn.id]
      destination_address = local.prem_ne_pip_address
      destination_ports   = ["443"]
      translated_address  = "10.200.11.80"
      translated_port     = "443"
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 100: OUTBOUND APPLICATION RULES - PROD
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_app" {
  name               = "RCG-CE-DMZ-OUT-PROD-APP-NE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 100

  application_rule_collection {
    name     = "BUSINESS-APPS-PROD"
    priority = 110
    action   = "Allow"

    rule {
      name             = "BusinessAppsProd"
      source_addresses = ["10.200.0.0/16", "10.201.0.0/16"]
      destination_fqdns = [
        "portal.azure.com", "login.microsoftonline.com",
        "management.azure.com", "*.database.windows.net"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "UbuntuUpdatesProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "archive.ubuntu.com", "security.ubuntu.com", "*.ubuntu.com"
      ]
      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "TLSCertificatesProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "ocsp.digicert.com", "crl4.digicert.com", "crl3.digicert.com"
      ]
      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "AzureActiveDirectoryProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "login.microsoftonline.com", "*.msauth.net"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "CrowdStrikeProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "*.crowdstrike.com", "sensor.crowdstrike.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "DevToolsProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "*.github.com", "api.github.com", "raw.githubusercontent.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "MonitoringProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "*.insights.monitoring.azure.com", "*.monitoring.azure.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "RDSProd"
      source_addresses = ["10.200.11.80/32"]
      destination_fqdns = [
        "*.rdgateway.windows.net", "*.wvd.microsoft.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "LogAnalyticsProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "*.ods.opinsights.azure.com", "*.oms.opinsights.azure.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "TestingServicesProd"
      source_addresses = ["10.200.0.0/16"]
      destination_fqdns = [
        "*.testing.azure.com", "test.azureservices.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 200: OUTBOUND APPLICATION RULES - NON-PROD
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_app_nonprod" {
  name               = "RCG-CE-DMZ-OUT-APP-NE-NONPROD"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 200

  application_rule_collection {
    name     = "TOOLS-NONPROD"
    priority = 210
    action   = "Allow"

    rule {
      name             = "DevToolsNonProd"
      source_addresses = ["10.210.0.0/16", "10.212.0.0/16"]
      destination_fqdns = [
        "*.github.com", "api.github.com", "raw.githubusercontent.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "TestingServicesNonProd"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "*.testing.azure.com", "test.azureservices.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "QueueITNonProd"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "queueit.com", "*.queueit.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "CRLValidationNonProd"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "ocsp.digicert.com", "crl4.digicert.com", "crl3.digicert.com"
      ]
      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "StorageAccessNonProd"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "*.blob.core.windows.net", "*.table.core.windows.net"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name             = "MonitoringNonProd"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "*.insights.monitoring.azure.com", "*.monitoring.azure.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 300: SFTP OUTBOUND
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_ftp" {
  name               = "RCG-CE-DMZ-OUT-FTP-NE"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 300

  network_rule_collection {
    name     = "OUT-SFTP-PROD"
    priority = 310
    action   = "Allow"

    rule {
      name                  = "SFTPProd"
      protocols             = ["TCP"]
      source_addresses      = ["10.200.5.0/24"]
      destination_addresses = ["161.113.228.48", "161.113.239.62"]
      destination_ports     = ["22"]
    }

    rule {
      name                  = "SFTPDev"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.5.0/24"]
      destination_addresses = ["161.113.228.48", "161.113.239.62"]
      destination_ports     = ["10022"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 500: AZURE MANAGEMENT & INTERNET (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_internet" {
  name               = "RCG-CI-DMZ-OUT-INTERNET"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 500

  network_rule_collection {
    name     = "OUT-AZURE-MANAGEMENT"
    priority = 510
    action   = "Allow"

    rule {
      name                  = "AzureManagement"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.6.0/24", "10.207.6.0/24", "10.212.6.0/24", "10.213.6.0/24"]
      destination_addresses = ["AzureCloud", "Storage", "ServiceBus"]
      destination_ports     = ["80", "443"]
    }

    rule {
      name                  = "SquidInternet"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.5.0/24"]
      destination_addresses = ["*"]
      destination_ports     = ["80", "443"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 600: NETWORK RULES (ST4 Non-Prod)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "prem_ne_rcg_net_nonprod" {
  name               = "RCG-CI-DMZ-OUT-NET-ST4"
  firewall_policy_id = data.azurerm_firewall_policy.prem_ne_policy.id
  priority           = 600

  network_rule_collection {
    name     = "OUT-AZURE-MANAGEMENT-NONPROD"
    priority = 610
    action   = "Allow"

    rule {
      name                  = "AzureManagementNonProd"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.6.0/24", "10.207.6.0/24", "10.212.6.0/24", "10.213.6.0/24"]
      destination_addresses = ["Storage", "ServiceBus", "AzureActiveDirectory", "AzureCloud", "ServiceFabric"]
      destination_ports     = ["80", "443"]
    }

    rule {
      name                  = "SquidToInternetNonProd"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.210.6.0/24", "10.207.6.0/24", "10.212.6.0/24", "10.213.6.0/24"]
      destination_addresses = ["AzureCloud"]
      destination_ports     = ["*"]
    }

    rule {
      name                  = "SFTPOmigadb"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.5.0/24"]
      destination_addresses = ["161.113.228.48", "161.113.239.62"]
      destination_ports     = ["10022"]
    }

    rule {
      name                  = "StorageSMB"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.0.0/16"]
      destination_addresses = ["Storage.NorthEurope", "Storage.WestEurope"]
      destination_ports     = ["445"]
    }

    rule {
      name                  = "SQLOutbound"
      protocols             = ["TCP"]
      source_addresses      = ["10.210.18.0/24"]
      destination_addresses = ["SQL"]
      destination_ports     = ["1433"]
    }

    rule {
      name                  = "NTPTimeSync"
      protocols             = ["UDP"]
      source_addresses      = ["10.210.18.0/24", "10.210.0.0/16"]
      destination_addresses = ["AzureCloud.ukwest"]
      destination_ports     = ["123"]
    }

    rule {
      name                  = "DevOpsAgentFallback"
      protocols             = ["TCP"]
      source_ip_groups      = [data.azurerm_ip_group.ipg_ci_devops_agents.id]
      destination_addresses = ["*"]
      destination_ports     = ["443"]
    }
  }
}
