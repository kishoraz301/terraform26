# Standard Firewall Policies - NE ONLY (North Europe)
# SI-CIDMZ-FWPLCY-STD-NE - New policy creation for CI DMZ

# ============================================================================
# DATA SOURCES
# ============================================================================

data "azurerm_resource_group" "cidmz_ne" {
  name = "MIP-SI-NE-RG"
}

# ============================================================================
# IP GROUPS - Reference existing CI DMZ Standard Firewall IP groups (NE)
# ============================================================================

data "azurerm_ip_group" "ipg_ci_devops_agents" {
  name                = "IPG-CI-DEVOPS-AGENTS"
  resource_group_name = data.azurerm_resource_group.cidmz_ne.name
}

data "azurerm_ip_group" "ipg_crowdstrike" {
  name                = "IPG-CROWDSTRIKE"
  resource_group_name = data.azurerm_resource_group.cidmz_ne.name
}

# ============================================================================
# REFERENCE EXISTING STANDARD FIREWALL POLICY (NE) - already created
# ============================================================================

data "azurerm_firewall_policy" "std_ne_policy" {
  name                = "SI-CIDMZ-FWPLCY-STD-NE"
  resource_group_name = data.azurerm_resource_group.cidmz_ne.name
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31000: INBOUND NETWORK RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_inbound" {
  name               = "RCG-CI-NE-IN-NET-ALLOW"
  firewall_policy_id = data.azurerm_firewall_policy.std_ne_policy.id
  priority           = 31000

  network_rule_collection {
    name     = "INBOUND-FROM-CE-DMZ"
    priority = 31010
    action   = "Allow"

    rule {
      name                  = "FromCEDMZ"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.0.0/16"]
      destination_addresses = ["10.210.0.0/16"]
      destination_ports     = ["*"]
    }

    rule {
      name                  = "InternalCIDMZ"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.210.0.0/16"]
      destination_addresses = ["10.210.0.0/16"]
      destination_ports     = ["*"]
    }

    rule {
      name                  = "HealthCheck"
      protocols             = ["TCP"]
      source_addresses      = ["168.63.129.16/32"]
      destination_addresses = ["10.210.0.0/16"]
      destination_ports     = ["80", "443"]
    }

    rule {
      name                  = "DNS"
      protocols             = ["UDP"]
      source_addresses      = ["10.210.0.0/16"]
      destination_addresses = ["*"]
      destination_ports     = ["53"]
    }

    rule {
      name                  = "AdminAccess"
      protocols             = ["TCP"]
      source_addresses      = ["10.0.0.0/8"]
      destination_addresses = ["10.210.0.0/16"]
      destination_ports     = ["22", "3389", "5985", "5986"]
    }
  }

  network_rule_collection {
    name     = "INBOUND-DENY-ALL"
    priority = 31020
    action   = "Deny"

    rule {
      name                  = "DenyAll"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["*"]
      destination_addresses = ["*"]
      destination_ports     = ["*"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31100: OUTBOUND NETWORK RULES (INTERNAL)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_out_net" {
  name               = "RCG-CI-NE-OUT-NET-ALLOW"
  firewall_policy_id = data.azurerm_firewall_policy.std_ne_policy.id
  priority           = 31100

  network_rule_collection {
    name     = "OUT-INTERNAL"
    priority = 31110
    action   = "Allow"

    rule {
      name                  = "InternalToFW"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.210.0.0/16"]
      destination_addresses = ["10.210.0.0/16"]
      destination_ports     = ["*"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31200: OUTBOUND APPLICATION RULES
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_out_app" {
  name               = "RCG-CI-NE-OUT-APP-ALLOW"
  firewall_policy_id = data.azurerm_firewall_policy.std_ne_policy.id
  priority           = 31200

  application_rule_collection {
    name     = "OUT-ENTRA-ID"
    priority = 31210
    action   = "Allow"

    rule {
      name             = "EntraID"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "login.microsoftonline.com",
        "login.windows.net",
        "graph.microsoft.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-AZURE-SERVICES"
    priority = 31220
    action   = "Allow"

    rule {
      name             = "AzureCP"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "management.azure.com",
        "*.management.azure.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-MONITORING"
    priority = 31230
    action   = "Allow"

    rule {
      name             = "Monitor"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "*.insights.monitoring.azure.com",
        "*.monitoring.azure.com"
      ]
      protocols {
        type = "Https"
        port = 443
      }
    }
  }

  application_rule_collection {
    name     = "OUT-CERTIFICATES"
    priority = 31240
    action   = "Allow"

    rule {
      name             = "CRL-OCSP"
      source_addresses = ["10.210.0.0/16"]
      destination_fqdns = [
        "ocsp.digicert.com",
        "crl3.digicert.com",
        "crl4.digicert.com"
      ]
      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}
