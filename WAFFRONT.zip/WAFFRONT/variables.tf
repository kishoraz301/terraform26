variable "primary_subscription_id" {
  type      = string
  sensitive = true
}

variable "secondary_subscription_id" {
  type      = string
  sensitive = true
}

# AFD profile, WAF policies, and custom domains live in the ceDMZ RG per LLD 4.3.8
variable "afd_resource_group_name" {
  type    = string
  default = "si-cedmz-we-01-rg"
}

variable "location" {
  type    = string
  default = "westeurope"
}

# AppGW PIPs are in the AppGW resource groups (phase-08)
variable "we_appgw_resource_group_name" {
  type    = string
  default = "si-dmz-appgw-we-01-rg"
}

variable "ne_appgw_resource_group_name" {
  type    = string
  default = "si-dmz-appgw-ne-01-rg"
}

variable "we_resource_group_name" {
  type    = string
  default = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  type    = string
  default = "MIP-SI-NE-RG"
}

variable "frontdoor_sku" {
  type    = string
  default = "Premium_AzureFrontDoor"
}

variable "waf_mode" {
  type    = string
  default = "Detection"
}

variable "rate_limit_threshold" {
  type    = number
  default = 2000
}

variable "tags" {
  type    = map(string)
  default = {}
}

