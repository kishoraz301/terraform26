output "frontdoor_id" {
  value = azurerm_cdn_frontdoor_profile.global_frontdoor.id
}

output "we_endpoint_fqdn" {
  value = azurerm_cdn_frontdoor_endpoint.we_endpoint.host_name
}

output "ne_endpoint_fqdn" {
  value = azurerm_cdn_frontdoor_endpoint.ne_endpoint.host_name
}

output "waf_adv_id" {
  value = azurerm_cdn_frontdoor_firewall_policy.waf_adv.id
}

output "waf_lms_id" {
  value = azurerm_cdn_frontdoor_firewall_policy.waf_lms.id
}

output "waf_hsbcpapi_id" {
  value = azurerm_cdn_frontdoor_firewall_policy.waf_hsbcpapi.id
}
