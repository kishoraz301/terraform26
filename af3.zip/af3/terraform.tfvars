# Azure Subscription Configuration
primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"

# Resource Group Names
afd_resource_group_name      = "si-cedmz-we-01-rg"     # LLD 4.3.8: AFD profile RG — created by this phase
location                     = "westeurope"
we_appgw_resource_group_name = "MIP-SI-WE-RG"          # Phase-08: PIP lives here
ne_appgw_resource_group_name = "MIP-SI-NE-RG"          # Phase-08: PIP lives here (NE)
we_resource_group_name       = "MIP-SI-WE-RG"
ne_resource_group_name       = "MIP-SI-NE-RG"

# Front Door Configuration
frontdoor_sku = "Premium_AzureFrontDoor"
waf_mode      = "Detection"  # LLD: Day-1 Detection; change to Prevention after tuning

tags = {
  Environment = "Production"
  ManagedBy   = "Terraform"
  Phase       = "11"
}
