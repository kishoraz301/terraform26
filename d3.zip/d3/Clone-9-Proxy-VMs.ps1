<#
.SYNOPSIS
    Clone 9 Squid Proxy VMs (4 NE + 5 WE) to production targets using snapshot approach
    
.DESCRIPTION
    This script clones 9 proxy VMs from production source RGs to target RGs
    - North Europe: 4 PROXY VMs
    - West Europe: 5 PROXY VMs
    Based on tested POC Clone-VM-From-Snapshot.ps1 pattern
    
.PARAMETER SubscriptionId
    Azure subscription ID
    
.EXAMPLE
    .\Clone-9-Proxy-VMs.ps1 -SubscriptionId "b3179146-e675-480d-aa38-23ec90529400"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId
)

Set-AzContext -SubscriptionId $SubscriptionId | Out-Null

# VM Configuration - 9 Proxy VMs (4 NE + 5 WE)
$vmCloneConfig = @(
    # North Europe - 4 PROXY VMs
    @{
        SourceVMName = "SI-proxy-vm-51"
        TargetVMName = "si-proxy-vm-56"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.35"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-52"
        TargetVMName = "si-proxy-vm-57"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.36"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-53"
        TargetVMName = "si-proxy-vm-58"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.43"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-54"
        TargetVMName = "si-proxy-vm-59"
        SourceResourceGroup = "si-proxy-ne-rg"
        TargetResourceGroup = "si-dmz-rprxy-ne-01-rg"
        VNetResourceGroup = "MIP-SI-NE-RG"
        TargetVNetName = "MIP-SI-NE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-NE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.12.44"
        Location = "North Europe"
        DiskType = "StandardSSD_LRS"
    },
    # West Europe - 5 PROXY VMs
    @{
        SourceVMName = "SI-proxy-vm-01"
        TargetVMName = "si-proxy-vm-06"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.35"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-02"
        TargetVMName = "si-proxy-vm-07"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.36"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-03"
        TargetVMName = "si-proxy-vm-08"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.43"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "SI-proxy-vm-04"
        TargetVMName = "si-proxy-vm-09"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.44"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    },
    @{
        SourceVMName = "si-proxy-vm-05"
        TargetVMName = "si-proxy-vm-10"
        SourceResourceGroup = "si-proxy-we-rg"
        TargetResourceGroup = "si-dmz-proxy-we-01-rg"
        VNetResourceGroup = "MIP-SI-WE-RG"
        TargetVNetName = "MIP-SI-WE-cIDMZ-vnet"
        TargetSubnetName = "MIP-SI-WE-cIDMZ-Proxy-dmz-snet"
        TargetPrivateIP = "10.200.11.45"
        Location = "West Europe"
        DiskType = "StandardSSD_LRS"
    }
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $output = "[$timestamp] [$Level] $Message"
    
    switch ($Level) {
        "SUCCESS" { Write-Host $output -ForegroundColor Green }
        "ERROR" { Write-Host $output -ForegroundColor Red }
        "WARNING" { Write-Host $output -ForegroundColor Yellow }
        default { Write-Host $output -ForegroundColor Cyan }
    }
}

function New-VMSnapshot {
    param([string]$SnapshotName, [string]$SourceDiskId, [string]$TargetResourceGroup, [string]$Location, [string]$SourceVMName)
    
    try {
        Write-Log "Creating snapshot: $SnapshotName"
        $snapshotConfig = New-AzSnapshotConfig -SourceResourceId $SourceDiskId -Location $Location -CreateOption Copy
        $snapshot = New-AzSnapshot -Snapshot $snapshotConfig -ResourceGroupName $TargetResourceGroup -SnapshotName $SnapshotName
        Write-Log "Snapshot created successfully: $($snapshot.Id)" SUCCESS
        return $snapshot.Id
    }
    catch {
        Write-Log "Error creating snapshot: $_" ERROR
        throw
    }
}

function New-VMDiskFromSnapshot {
    param([string]$DiskName, [string]$SnapshotId, [string]$TargetResourceGroup, [string]$Location, [string]$DiskType)
    
    try {
        Write-Log "Creating managed disk from snapshot: $DiskName"
        $diskConfig = New-AzDiskConfig -SourceResourceId $SnapshotId -Location $Location -CreateOption Copy -SkuName $DiskType
        $disk = New-AzDisk -Disk $diskConfig -ResourceGroupName $TargetResourceGroup -DiskName $DiskName
        Write-Log "Disk created successfully: $($disk.Id)" SUCCESS
        
        # Verify disk is available
        Write-Log "Verifying disk is available..."
        $retries = 15
        for ($i = 1; $i -le $retries; $i++) {
            $diskStatus = (Get-AzDisk -ResourceGroupName $TargetResourceGroup -DiskName $DiskName).ProvisioningState
            if ($diskStatus -eq "Succeeded") {
                Write-Log "Disk verified and available" SUCCESS
                return $disk.Id
            }
            Start-Sleep -Seconds 2
        }
        throw "Disk did not become available after $retries retries"
    }
    catch {
        Write-Log "Error creating disk: $_" ERROR
        throw
    }
}

function New-VMNetworkInterface {
    param([string]$NicName, [string]$TargetResourceGroup, [string]$VNetResourceGroup, [string]$TargetVNetName, [string]$TargetSubnetName, [string]$TargetPrivateIP, [string]$Location)
    
    try {
        Write-Log "Creating network interface: $NicName"
        $vnet = Get-AzVirtualNetwork -Name $TargetVNetName -ResourceGroupName $VNetResourceGroup
        $subnet = Get-AzVirtualNetworkSubnetConfig -Name $TargetSubnetName -VirtualNetwork $vnet
        $nicConfig = New-AzNetworkInterfaceIpConfig -Name "ipconfig1" -PrivateIpAddress $TargetPrivateIP -Subnet $subnet -PrivateIpAddressVersion IPv4
        $nic = New-AzNetworkInterface -Name $NicName -ResourceGroupName $TargetResourceGroup -Location $Location -IpConfiguration $nicConfig
        Write-Log "Network interface created successfully: $($nic.Id)" SUCCESS
        
        # Verify NIC is available
        Write-Log "Verifying network interface is available..."
        $retries = 10
        for ($i = 1; $i -le $retries; $i++) {
            $nicStatus = (Get-AzNetworkInterface -Name $NicName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue).ProvisioningState
            if ($nicStatus -eq "Succeeded") {
                Write-Log "Network interface verified and available" SUCCESS
                return $nic.Id
            }
            Start-Sleep -Seconds 1
        }
        throw "NIC did not become available after $retries retries"
    }
    catch {
        Write-Log "Error creating network interface: $_" ERROR
        throw
    }
}

function New-ClonedVM {
    param([string]$TargetVMName, [string]$OsDiskId, [string]$NicId, [string]$TargetResourceGroup, [string]$Location, [string]$VMSize, [string]$OSType)
    
    try {
        Write-Log "Creating VM: $TargetVMName (Size: $VMSize, OS: $OSType)"
        $vm = New-AzVMConfig -VMName $TargetVMName -VMSize $VMSize
        $vm = Add-AzVMNetworkInterface -VM $vm -Id $NicId -Primary
        $vm = Set-AzVMOSDisk -VM $vm -ManagedDiskId $OsDiskId -CreateOption Attach -Linux:($OSType -eq "Linux")
        New-AzVM -VM $vm -ResourceGroupName $TargetResourceGroup -Location $Location
        Write-Log "VM created successfully:" SUCCESS
        return $true
    }
    catch {
        Write-Log "Error creating VM: $_" ERROR
        throw
    }
}

# Main execution
Write-Log "========================================" INFO
Write-Log "PROXY VM CLONING - 9 VMs (4 NE + 5 WE)" INFO
Write-Log "========================================" INFO

$successCount = 0
$failCount = 0

foreach ($config in $vmCloneConfig) {
    Write-Log "" INFO
    Write-Log "Cloning: $($config.SourceVMName) -> $($config.TargetVMName)" INFO
    Write-Log "Source RG: $($config.SourceResourceGroup) | Target RG: $($config.TargetResourceGroup)" INFO
    
    try {
        # Get source VM info
        Write-Log "Getting source VM info..."
        $sourceVM = Get-AzVM -Name $config.SourceVMName -ResourceGroupName $config.SourceResourceGroup -ErrorAction Stop
        $vmSize = $sourceVM.HardwareProfile.VmSize
        $osType = if ($sourceVM.StorageProfile.OsDisk.OsType) { $sourceVM.StorageProfile.OsDisk.OsType } else { "Linux" }
        $sourceDiskId = $sourceVM.StorageProfile.OsDisk.ManagedDisk.Id
        Write-Log "Source VM size: $vmSize, OS: $osType" SUCCESS
        
        # Create snapshot
        $snapshotName = "$($config.TargetVMName)-snap"
        $snapshotId = New-VMSnapshot -SnapshotName $snapshotName -SourceDiskId $sourceDiskId -TargetResourceGroup $config.TargetResourceGroup -Location $config.Location -SourceVMName $config.SourceVMName
        
        # Create disk from snapshot
        $diskName = "$($config.TargetVMName)-osdisk"
        $osDiskId = New-VMDiskFromSnapshot -DiskName $diskName -SnapshotId $snapshotId -TargetResourceGroup $config.TargetResourceGroup -Location $config.Location -DiskType $config.DiskType
        
        # Create network interface
        $nicName = "$($config.TargetVMName)-nic"
        $nicId = New-VMNetworkInterface -NicName $nicName -TargetResourceGroup $config.TargetResourceGroup -VNetResourceGroup $config.VNetResourceGroup -TargetVNetName $config.TargetVNetName -TargetSubnetName $config.TargetSubnetName -TargetPrivateIP $config.TargetPrivateIP -Location $config.Location
        
        # Create cloned VM
        New-ClonedVM -TargetVMName $config.TargetVMName -OsDiskId $osDiskId -NicId $nicId -TargetResourceGroup $config.TargetResourceGroup -Location $config.Location -VMSize $vmSize -OSType $osType
        Write-Log "SUCCESS: $($config.TargetVMName) cloned successfully" SUCCESS
        $successCount++
    }
    catch {
        Write-Log "FAILED: $($config.TargetVMName) - $_" ERROR
        $failCount++
    }
}

Write-Log "" INFO
Write-Log "========================================" INFO
Write-Log "EXECUTION COMPLETE" INFO
Write-Log "Successfully cloned: $successCount" SUCCESS
Write-Log "Failed: $failCount" ERROR
Write-Log "========================================" INFO
