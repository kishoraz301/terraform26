# Azure Subscription Configuration
primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"  # Can be same as primary

# Resource Group Names
we_resource_group_name = "MIP-SI-WE-RG"
ne_resource_group_name = "MIP-SI-NE-RG"

# Front Door Configuration
frontdoor_sku         = "Premium_AzureFrontDoor"
waf_mode              = "Prevention"
rate_limit_threshold  = 2000

# Firewall Configuration
firewall_sku = "Standard"  # Options: Standard, Premium

# Application Gateway Configuration
appgw_capacity       = 2
appgw_autoscale_min  = 1
appgw_autoscale_max  = 10

# Load Balancer Configuration
lb_probe_interval  = 15
lb_probe_threshold = 2

# Front Door Configuration
frontdoor_sku         = "Premium_AzureFrontDoor"  # Options: Standard_AzureFrontDoor, Premium_AzureFrontDoor
waf_mode              = "Prevention"               # Options: Detection, Prevention
rate_limit_threshold  = 2000                       # requests per minute per IP
