# Phase 11: Azure Front Door (Global ingress + WAF + DDoS)
# Deploy after Phase 08: Application Gateways

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_public_ip" "we_appgw_pip" {
  name                = "MIP-SI-WE-AppGW-frontend-pip"
  resource_group_name = data.azurerm_resource_group.we.name
}

data "azurerm_public_ip" "ne_appgw_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-AppGW-frontend-pip"
  resource_group_name = var.ne_resource_group_name
}

# ============================================================================
# Azure Front Door with WAF
# ============================================================================

resource "azurerm_cdn_frontdoor_profile" "global_frontdoor" {
  name                = "mip-si-global-frontdoor"
  resource_group_name = data.azurerm_resource_group.we.name
  sku_name            = var.frontdoor_sku
}

# West Europe endpoint
resource "azurerm_cdn_frontdoor_endpoint" "we_endpoint" {
  name                    = "mip-si-we-endpoint"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
}

# North Europe endpoint
resource "azurerm_cdn_frontdoor_endpoint" "ne_endpoint" {
  name                    = "mip-si-ne-endpoint"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
}

# Global endpoint (both regions)
resource "azurerm_cdn_frontdoor_endpoint" "global_endpoint" {
  name                    = "mip-si-global"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
}

# Origin group
resource "azurerm_cdn_frontdoor_origin_group" "app_origins" {
  name                     = "mip-si-app-origins"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.global_frontdoor.id
  session_affinity_enabled = false

  load_balancing {
    sample_size                     = 4
    successful_samples_required     = 3
  }

  health_probe {
    interval_in_seconds = 100
    path                = "/health"
    protocol            = "Https"
    request_type        = "GET"
  }
}

# West Europe origin
resource "azurerm_cdn_frontdoor_origin" "we_origin" {
  name                            = "mip-si-we-appgw"
  cdn_frontdoor_origin_group_id   = azurerm_cdn_frontdoor_origin_group.app_origins.id
  enabled                         = true
  host_name                       = data.azurerm_public_ip.we_appgw_pip.ip_address
  http_port                       = 80
  https_port                      = 443
  origin_host_header              = "we-app.hsbc.local"
  priority                        = 1
  certificate_name_check_enabled  = true
}

# North Europe origin
resource "azurerm_cdn_frontdoor_origin" "ne_origin" {
  name                            = "mip-si-ne-appgw"
  cdn_frontdoor_origin_group_id   = azurerm_cdn_frontdoor_origin_group.app_origins.id
  enabled                         = true
  host_name                       = data.azurerm_public_ip.ne_appgw_pip.ip_address
  http_port                       = 80
  https_port                      = 443
  origin_host_header              = "ne-app.hsbc.local"
  priority                        = 2
  certificate_name_check_enabled  = true
}

# WAF Policy
resource "azurerm_cdn_frontdoor_firewall_policy" "waf_policy" {
  name                              = "mipsifdwaf"
  resource_group_name               = data.azurerm_resource_group.we.name
  sku_name                          = var.frontdoor_sku
  enabled                           = true
  mode                              = var.waf_mode
  redirect_url                      = "https://example.com/waf-blocked"
  custom_block_response_status_code = 403

  managed_rule {
    type    = "Microsoft_DefaultRuleSet"
    version = "2.0"
    action  = "Block"
  }

  managed_rule {
    type    = "Microsoft_BotManagerRuleSet"
    version = "1.0"
    action  = "Block"
  }
}

# Routing rule for HTTPS
resource "azurerm_cdn_frontdoor_route" "https_route" {
  name                          = "mip-si-https-route"
  cdn_frontdoor_endpoint_id     = azurerm_cdn_frontdoor_endpoint.global_endpoint.id
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.app_origins.id
  cdn_frontdoor_origin_ids      = [azurerm_cdn_frontdoor_origin.we_origin.id, azurerm_cdn_frontdoor_origin.ne_origin.id]
  enabled                       = true

  forwarding_protocol = "HttpsOnly"
  patterns_to_match   = ["/*"]
  supported_protocols = ["Http", "Https"]
  https_redirect_enabled = true
}

