# Azure Subscription Configuration
primary_subscription_id   = "9bde6346-5250-49f9-a010-3ac07609cb70"
secondary_subscription_id = "9bde6346-5250-49f9-a010-3ac07609cb70"  # Can be same as primary

# Environment
environment = "production"

# Region Configuration
primary_region   = "westeurope"
secondary_region = "northeurope"

# Resource Group Names
we_resource_group_name = "MIP-SI-WE-RG"
ne_resource_group_name = "MIP-SI-NE-RG"

# Network Configuration
we_cedmz_address_space = "10.200.50.0/24"
we_cidmz_address_space = "10.200.11.0/24"
ne_cedmz_address_space = "10.200.60.0/24"
ne_cidmz_address_space = "10.200.12.0/24"

custom_dns_servers = ["8.8.8.8", "8.8.4.4"]

# DDoS Protection (optional)
enable_ddos_protection = false

# Firewall Configuration
firewall_sku = "Standard"  # Options: Standard, Premium

# Application Gateway Configuration
appgw_capacity       = 2
appgw_autoscale_min  = 1
appgw_autoscale_max  = 10

# Load Balancer Configuration
lb_probe_interval  = 15
lb_probe_threshold = 2

# Front Door Configuration
frontdoor_sku         = "Premium_AzureFrontDoor"  # Options: Standard_AzureFrontDoor, Premium_AzureFrontDoor
waf_mode              = "Prevention"               # Options: Detection, Prevention
rate_limit_threshold  = 2000                       # requests per minute per IP
