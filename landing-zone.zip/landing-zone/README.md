# MIP-SI Multi-Region Azure Landing Zone - Terraform IaC

A production-grade, multi-region Azure landing zone deployment using Terraform with a **phased approach** for controlled, incremental infrastructure rollout across West Europe (primary) and North Europe (secondary) regions.

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Repository Structure](#repository-structure)
- [Prerequisites](#prerequisites)
- [Setup Instructions](#setup-instructions)
- [Deployment Phases](#deployment-phases)
- [Configuration](#configuration)
- [Deployment Workflow](#deployment-workflow)
- [Troubleshooting](#troubleshooting)
- [Cost Optimization](#cost-optimization)
- [Security Best Practices](#security-best-practices)
- [Post-Deployment](#post-deployment)

---

## Overview

This repository provides a **phased, modular Terraform configuration** for deploying a production-ready Azure landing zone with:

- **Multi-region deployment** (West Europe + North Europe)
- **DMZ-style network segmentation** (ceDMZ for perimeter, ciDMZ for internal)
- **Defense-in-depth security** (NSGs, Azure Firewalls, WAF, DDoS)
- **Global ingress & failover** (Azure Front Door with Premium SKU)
- **Private internal LB** (Proxy tier load balancing)
- **Per-phase deployment** (12 phases, deploy one at a time)

### Key Features

✅ **Dual-region architecture** with independent failover capability  
✅ **Network segmentation** with ceDMZ (perimeter) and ciDMZ (internal)  
✅ **4 Azure Firewalls** (2 per region) with comprehensive rule sets  
✅ **2 Application Gateways** (Standard_v2 + WAF_v2) with autoscaling  
✅ **Global Azure Front Door** (Premium) with WAF and rate limiting  
✅ **VNet peering** with forwarded traffic enabled  
✅ **Custom route tables** with firewall routing  
✅ **8 Static Public IPs** (one per major resource)  
✅ **Production-ready defaults** (deny-by-default NSGs, TLS 1.2+, threat detection)

---

## Architecture

### High-Level Design

```
┌─────────────────────────────────────────────────────────────────┐
│                    Azure Front Door (Global)                      │
│              Premium SKU, WAF, DDoS Protection                    │
└──────────┬────────────────────────────────────┬──────────────────┘
           │                                    │
    ┌──────▼──────┐                      ┌──────▼──────┐
    │  WE Region  │                      │  NE Region  │
    │  (Primary)  │                      │(Secondary)  │
    └──────┬──────┘                      └──────┬──────┘
           │                                    │
    ┌──────▼──────────────┐          ┌──────────▼──────┐
    │   ceDMZ VNet        │          │   ceDMZ VNet    │
    │ (10.200.50.0/24)    │          │ (10.200.60.0/24)│
    │  - AFW (perimeter)  │          │  - AFW          │
    │  - Internet facing  │          │  - Internet      │
    └──────┬──────────────┘          └──────┬──────────┘
           │ Peering                        │ Peering
    ┌──────▼──────────────┐          ┌──────▼──────────┐
    │   ciDMZ VNet        │          │   ciDMZ VNet    │
    │ (10.200.11.0/24)    │          │ (10.200.12.0/24)│
    │  - AFW (internal)   │          │  - AFW          │
    │  - AppGW (WAF)      │          │  - AppGW (WAF)  │
    │  - LB (proxy)       │          │  - LB (proxy)   │
    │  - RDS/Jump boxes   │          │  - RDS/Jump boxes│
    └─────────────────────┘          └──────────────────┘
```

### Network Tiers

| Tier | Name | Purpose | Subnets per Region |
|------|------|---------|-------------------|
| **ceDMZ** | Customer Edge DMZ | Perimeter/Edge security, inbound ingress | 2 (AFW + Reserved) |
| **ciDMZ** | Corporate Internal DMZ | Application hosting, internal services | 5 (Proxy, RDS, AFW, AppGW, Reserved) |

### Resources by Phase

| Phase | Resource Type | Count | Per-Region | Purpose |
|-------|---------------|-------|-----------|---------|
| 01 | Resource Groups | 2 | 1 each | Container for regional resources |
| 02 | Virtual Networks | 4 | 2 each | Network isolation (ceDMZ + ciDMZ) |
| 03 | Subnets | 14 | 7 each | Network segmentation |
| 04 | NSGs | 10 | 5 each | Layer 4 access control |
| 05 | Public IPs | 8 | 4 each | Static external addresses |
| 06 | Azure Firewalls | 4 | 2 each | Perimeter + internal firewalling |
| 07 | Load Balancers | 2 | 1 each | Proxy tier internal LB |
| 08 | App Gateways | 2 | 1 each | Layer 7 + WAF protection |
| 09 | VNet Peerings | 4 | 2 each | Regional VNet connectivity |
| 10 | Route Tables | 4 | 2 each | Network routing policies |
| 11 | Front Door | 1 | Global | Global ingress + WAF + failover |
| 12 | FW Policies | 2 | 1 each | Firewall rule sets |

---

## Repository Structure

```
landing-zone/
├── README.md                              # This file
├── terraform.tfvars.example               # Example variable file (COPY & CUSTOMIZE)
├── .gitignore                             # Git exclusions
│
├── global/                                # Shared configuration
│   ├── locals.tf                          # Common local values
│   ├── variables.tf                       # Global variables
│   ├── providers.tf                       # Provider configuration
│   ├── subscriptions.tf                   # Subscription variables
│   └── outputs.tf                         # Global outputs
│
├── phases/                                # Deployment phases (deploy sequentially)
│   │
│   ├── phase-01-resource-groups/
│   │   ├── main.tf                        # 2x Resource Groups
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── README.md (optional per-phase docs)
│   │
│   ├── phase-02-virtual-networks/
│   │   ├── main.tf                        # 4x VNets (ceDMZ + ciDMZ per region)
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-03-subnets/
│   │   ├── main.tf                        # 14x Subnets
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-04-network-security-groups/
│   │   ├── main.tf                        # 10x NSGs with rules
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-05-public-ips/
│   │   ├── main.tf                        # 8x Static Public IPs
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-06-azure-firewalls/
│   │   ├── main.tf                        # 4x Azure Firewalls
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-07-load-balancers/
│   │   ├── main.tf                        # 2x Internal LBs (proxy tier)
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-08-application-gateways/
│   │   ├── main.tf                        # 2x AppGWs (WAF_v2)
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-09-vnet-peerings/
│   │   ├── main.tf                        # 4x Peerings (ceDMZ ↔ ciDMZ)
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-10-route-tables/
│   │   ├── main.tf                        # 4x Route Tables + Associations
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   ├── phase-11-front-door/
│   │   ├── main.tf                        # 1x Front Door + WAF + Endpoints
│   │   ├── variables.tf
│   │   └── outputs.tf
│   │
│   └── phase-12-firewall-policies/
│       ├── main.tf                        # 2x FW Policies + Rules
│       ├── variables.tf
│       └── outputs.tf
│
├── modules/                               # Reusable modules (optional future use)
│   ├── network/                           # Network module
│   └── security/                          # Security module
│
└── tfvars/                                # Variable files by environment
    ├── base.tfvars                        # Shared values
    ├── westeurope.tfvars                  # WE-specific values
    └── northeurope.tfvars                 # NE-specific values
```

---

## Prerequisites

### Software Requirements

- **Terraform** >= 1.0 ([Install](https://www.terraform.io/downloads.html))
- **Azure CLI** >= 2.45 ([Install](https://learn.microsoft.com/cli/azure/install-azure-cli))
- **jq** (optional, for parsing outputs)

### Azure Requirements

1. **Two Azure Subscriptions** (or same subscription with sufficient limits)
   - One for West Europe (primary)
   - One for North Europe (secondary)
   - Minimum permissions: **Owner** or **Contributor** + **User Access Administrator**

2. **Terraform State Backend** (Recommended for production)
   - Azure Storage Account for remote state
   - Storage Container: `tfstate`
   - Blob name pattern: `landing-zone/terraform.tfstate`

3. **Quotas & Limits** (verify per region)
   - vCPUs: min. 20 per region
   - Public IPs: 8+
   - Virtual Networks: 4+
   - Application Gateways: 2+
   - Azure Firewalls: 2+

---

## Setup Instructions

### Step 1: Navigate to Repository

```powershell
# Repository already exists locally
Set-Location "c:\KM\2026\HSBC\Terraform\landing-zone"
```

### Step 2: Authenticate to Azure (PowerShell)

```powershell
az login
az account set --subscription "<primary-subscription-id>"

# Verify subscription
az account show
```

### Step 3: Prepare Terraform Variables (PowerShell)

```powershell
# Copy example to actual tfvars file
Copy-Item terraform.tfvars.example terraform.tfvars

# Edit with VS Code
code terraform.tfvars
```

**Edit `terraform.tfvars` with your values - REQUIRED:**
- `primary_subscription_id`
- `secondary_subscription_id`
- Any custom DNS servers, SKUs, etc.

### Step 4: State Management

**For staging:** Local state (default) is configured. Each phase will create:
- `terraform.tfstate` (current state)
- `terraform.tfstate.backup` (previous state)
- `.terraform.lock.hcl` (dependency lock)

These are already excluded from Git via `.gitignore`.

**For production migration to remote state:**

When ready to move to production, use Azure Storage as the Terraform backend:

```powershell
# Create storage account for state (one-time production setup)
$RESOURCE_GROUP="rg-terraform-state"
$STORAGE_ACCOUNT="satterraformstate"
$CONTAINER="tfstate"

az group create -n $RESOURCE_GROUP -l westeurope
az storage account create -n $STORAGE_ACCOUNT -g $RESOURCE_GROUP --sku Standard_LRS
az storage container create -n $CONTAINER --account-name $STORAGE_ACCOUNT

# Create backend configuration in each phase directory
$backendConfig = @"
terraform {
  backend "azurerm" {
    resource_group_name  = "$RESOURCE_GROUP"
    storage_account_name = "$STORAGE_ACCOUNT"
    container_name       = "$CONTAINER"
    key                  = "phase-01/terraform.tfstate"
  }
}
"@

Set-Content -Path "phases/phase-01-resource-groups/backend.tf" -Value $backendConfig

# Re-initialize Terraform to migrate state
Set-Location phases/phase-01-resource-groups
terraform init
```

---

## Deployment Phases

### Overview

Deploy **one phase at a time** in order. Each phase builds on the previous one.

**⚠️ IMPORTANT:** Do NOT skip phases or deploy out of order.

| Phase | Name | Duration | Dependencies | Critical |
|-------|------|----------|--------------|----------|
| 01 | Resource Groups | 1 min | None | ✅ |
| 02 | Virtual Networks | 2 min | Phase 01 | ✅ |
| 03 | Subnets | 3 min | Phase 02 | ✅ |
| 04 | NSGs | 5 min | Phase 03 | ✅ |
| 05 | Public IPs | 2 min | Phase 03 | ✅ |
| 06 | Azure Firewalls | 8 min | Phase 03, 04, 05 | ✅ |
| 07 | Load Balancers | 3 min | Phase 03, 05 | ❌ |
| 08 | App Gateways | 10 min | Phase 03, 05 | ✅ |
| 09 | VNet Peerings | 1 min | Phase 02 | ❌ |
| 10 | Route Tables | 3 min | Phase 02, 06 | ✅ |
| 11 | Front Door | 5 min | Phase 08 | ✅ |
| 12 | FW Policies | 3 min | Phase 06 | ✅ |
| **Total** | | **~46 min** | | |

### Detailed Phase Breakdown

#### Phase 01: Resource Groups ⭐ START HERE

```powershell
Set-Location phases/phase-01-resource-groups

# Initialize Terraform (first time only)
terraform init

# Validate configuration
terraform validate

# Preview changes
terraform plan

# Apply
terraform apply

# Output resource IDs
terraform output
```

**Creates:** 2 Resource Groups
- `MIP-SI-WE-RG` (West Europe)
- `MIP-SI-NE-RG` (North Europe)

---

#### Phase 02: Virtual Networks

```powershell
Set-Location ../phase-02-virtual-networks
terraform init
terraform plan
terraform apply
```

**Creates:** 4 VNets
- WE ceDMZ: 10.200.50.0/24
- WE ciDMZ: 10.200.11.0/24
- NE ceDMZ: 10.200.60.0/24
- NE ciDMZ: 10.200.12.0/24

---

#### Phase 03: Subnets

```powershell
Set-Location ../phase-03-subnets
terraform init
terraform plan
terraform apply
```

**Creates:** 14 Subnets (7 per region)

**WE Subnets:**
- ceDMZ-AFW: 10.200.50.0/26 (Firewall)
- ceDMZ-Reserved: 10.200.50.64/26
- ciDMZ-Proxy: 10.200.11.0/26 (Proxy/ForwardProxy)
- ciDMZ-RDS: 10.200.11.64/27 (Jump/RDS)
- ciDMZ-AFWstd: 10.200.11.96/26 (Internal Firewall)
- ciDMZ-AppGW: 10.200.11.160/27 (Application Gateway)
- ciDMZ-Reserved: 10.200.11.192/26

(NE mirrors with 10.200.12.x and 10.200.60.x)

---

#### Phase 04: Network Security Groups

```powershell
Set-Location ../phase-04-network-security-groups
terraform init
terraform plan
terraform apply
```

**Creates:** 10 NSGs (5 per region)
- Deny-by-default rules
- Allow rules for HTTP/HTTPS, DNS, RDP, SSH, WinRM
- Internal traffic (10.0.0.0/8)

---

#### Phase 05: Public IPs

```powershell
Set-Location ../phase-05-public-ips
terraform init
terraform plan
terraform apply
```

**Creates:** 8 Static Public IPs (Standard SKU)
- 4 per region
- ceDMZ-AFW, ciDMZ-AFWstd, LB-frontend, AppGW-frontend per region

---

#### Phase 06: Azure Firewalls

```powershell
Set-Location ../phase-06-azure-firewalls
terraform init
terraform plan
terraform apply  # ~8 minutes
```

**Creates:** 4 Azure Firewalls (Standard SKU)
- WE ceDMZ (perimeter)
- WE ciDMZ (internal)
- NE ceDMZ (perimeter)
- NE ciDMZ (internal)

⏱️ **This phase takes the longest (~8 min per firewall)**

---

#### Phase 07: Load Balancers

```powershell
Set-Location ../phase-07-load-balancers
terraform init
terraform plan
terraform apply
```

**Creates:** 2 Internal Load Balancers
- WE ciDMZ-LB: 10.200.11.10
- NE ciDMZ-LB: 10.200.12.10
- Both for proxy tier (Squid 3128)

---

#### Phase 08: Application Gateways

```powershell
Set-Location ../phase-08-application-gateways
terraform init
terraform plan
terraform apply  # ~10 minutes
```

**Creates:** 2 Application Gateways (WAF_v2)
- WE ciDMZ-AppGW
- NE ciDMZ-AppGW
- WAF mode: Prevention (OWASP 3.1)
- Autoscaling: 1-10 instances
- Backend pools with example IPs

⏱️ **This phase takes ~10 minutes per AppGW**

---

#### Phase 09: VNet Peerings

```powershell
Set-Location ../phase-09-vnet-peerings
terraform init
terraform plan
terraform apply
```

**Creates:** 4 VNet Peerings (2 per region)
- ceDMZ ↔ ciDMZ (westeurope)
- ceDMZ ↔ ciDMZ (northeurope)
- Forwards traffic enabled

---

#### Phase 10: Route Tables

```powershell
Set-Location ../phase-10-route-tables
terraform init
terraform plan
terraform apply
```

**Creates:** 4 Route Tables + 10 Subnet Associations
- ceDMZ routes: default → Internet
- ciDMZ routes: default → Internal AFW, cross-region → VNet peering

---

#### Phase 11: Front Door

```powershell
Set-Location ../phase-11-front-door
terraform init
terraform plan
terraform apply  # ~5 minutes
```

**Creates:** 1 Azure Front Door (Premium)
- Global ingress endpoint
- Regional endpoints (WE + NE)
- WAF policy (OWASP 3.1)
- Rate limit: 2000 req/min/IP
- Failover based on health probes

---

#### Phase 12: Firewall Policies

```powershell
Set-Location ../phase-12-firewall-policies
terraform init
terraform plan
terraform apply
```

**Creates:** 2 Firewall Policies + Rule Collections
- NAT rules (HTTP/HTTPS inbound DNAT)
- Network rules (DNS, NTP, internal)
- Application rules (Azure services)

---

## Configuration

### Main Variables (terraform.tfvars)

```hcl
# Azure Subscriptions (REQUIRED)
primary_subscription_id   = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
secondary_subscription_id = "yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy"

# Regions (default: WE + NE)
primary_region   = "westeurope"
secondary_region = "northeurope"

# Environment
environment = "production"

# Network Address Spaces
we_cedmz_address_space = "10.200.50.0/24"
we_cidmz_address_space = "10.200.11.0/24"
ne_cedmz_address_space = "10.200.60.0/24"
ne_cidmz_address_space = "10.200.12.0/24"

# DNS
custom_dns_servers = ["8.8.8.8", "8.8.4.4"]  # or use your corporate DNS

# Security
firewall_sku  = "Standard"  # or "Premium"
waf_mode      = "Prevention"  # or "Detection"
enable_ddos_protection = false

# Scaling
appgw_capacity      = 2
appgw_autoscale_min = 1
appgw_autoscale_max = 10

# Front Door
frontdoor_sku        = "Premium_AzureFrontDoor"
rate_limit_threshold = 2000

# Protection
enable_resource_lock = true

# Custom Tags
tags = {
  CostCenter = "Finance-Code"
  Owner      = "CloudTeam"
}
```

### Variable Hierarchy

Variables are resolved in this order (last wins):
1. `global/variables.tf` (defaults)
2. `terraform.tfvars` (overrides)
3. `-var` flag (CLI override)
4. Environment variables (`TF_VAR_*`)

---

## Deployment Workflow

### Quick Deploy (All Phases at Once)

⚠️ **Not recommended for production, but possible:**

```powershell
Set-Location phases

$phases = Get-ChildItem -Directory -Filter "phase-*-*" | Sort-Object Name

foreach ($phase in $phases) {
  Write-Host "Deploying $($phase.Name)..."
  Set-Location $phase.FullName
  terraform init
  terraform plan -out=tfplan
  terraform apply tfplan
  Set-Location ..
}
```

### Safe Deploy (Recommended)

```powershell
# safe-deploy.ps1

$phases = @(
  "phase-01-resource-groups",
  "phase-02-virtual-networks",
  "phase-03-subnets",
  "phase-04-network-security-groups",
  "phase-05-public-ips",
  "phase-06-azure-firewalls",
  "phase-07-load-balancers",
  "phase-08-application-gateways",
  "phase-09-vnet-peerings",
  "phase-10-route-tables",
  "phase-11-front-door",
  "phase-12-firewall-policies"
)

foreach ($phase in $phases) {
  Write-Host "╔════════════════════════════════════════╗"
  Write-Host "║  Deploying: $phase"
  Write-Host "╚════════════════════════════════════════╝"
  
  Set-Location "phases/$phase"
  
  # Validate
  terraform validate
  if ($LASTEXITCODE -ne 0) { exit 1 }
  
  # Plan with approval
  terraform plan -out=tfplan
  Read-Host "Review plan. Press Enter to continue or Ctrl+C to abort"
  
  # Apply
  terraform apply tfplan
  
  # Save outputs
  terraform output -json | Set-Content "../../outputs-${phase}.json"
  
  Set-Location ../..
  
  Write-Host "✅ Phase complete. Waiting 30 seconds..."
  Start-Sleep -Seconds 30
}

Write-Host "🎉 All phases deployed successfully!"
```

---

## Troubleshooting

### Common Issues

#### Issue 1: Terraform State Lock

```powershell
# If state is locked:
terraform force-unlock <LOCK_ID>

# Or reset local state (dev only):
Remove-Item -Path .terraform -Recurse -Force
terraform init
```

#### Issue 2: Subscription Not Found

```powershell
# Verify subscription exists
az account list --output table

# Set correct subscription
az account set --subscription "<subscription-id>"

# Update terraform.tfvars
# primary_subscription_id = "<correct-id>"
```

#### Issue 3: Resource Already Exists

```powershell
# Option A: Import existing resource
terraform import azurerm_resource_group.we /subscriptions/.../resourceGroups/MIP-SI-WE-RG

# Option B: Rename in state
terraform state mv <old-name> <new-name>

# Option C: Destroy and recreate
terraform destroy -target=azurerm_resource_group.we
terraform apply
```

#### Issue 4: Firewall Deployment Timeout

Azure Firewalls can take 10+ minutes. If timeout occurs:

```powershell
# Check current status
az network firewall show -g MIP-SI-WE-RG -n MIP-SI-WE-ceDMZ-AFW

# Increase timeout in Terraform
$env:TF_CLI_ARGS = "-lock-timeout=20m"
terraform apply -lock-timeout=20m
```

#### Issue 5: WAF Rules Not Applied

WAF rules attach to AppGW:

```powershell
# Verify AppGW has WAF policy
az network application-gateway show -g MIP-SI-WE-RG -n MIP-SI-WE-ciDMZ-AppGW --query "webApplicationFirewallConfiguration"

# Check WAF rules
az network application-gateway waf-config show -g MIP-SI-WE-RG -n MIP-SI-WE-ciDMZ-AppGW
```

### Debug Commands

```powershell
# Validate all Terraform files
Get-ChildItem phases -Filter "phase-*-*" -Directory | ForEach-Object {
  Write-Host "Validating $($_.Name)..."
  Set-Location $_.FullName
  terraform validate
  Set-Location ../..
}

# Check Azure resources
az resource list -g MIP-SI-WE-RG --output table
az resource list -g MIP-SI-NE-RG --output table

# Verify network connectivity
az network vnet show -g MIP-SI-WE-RG -n MIP-SI-WE-ceDMZ-vnet
az network vnet peering list -g MIP-SI-WE-RG --vnet-name MIP-SI-WE-ceDMZ-vnet

# Check NSG rules
az network nsg rule list -g MIP-SI-WE-RG --nsg-name MIP-SI-WE-ceDMZ-AFW-nsg --output table
```

---

## Cost Optimization

### Cost-Saving Measures

1. **Use Standard Firewall** instead of Premium
   ```hcl
   firewall_sku = "Standard"  # Save ~$0.50/hour per firewall
   ```

2. **Reduce AppGW Capacity**
   ```hcl
   appgw_capacity       = 1
   appgw_autoscale_max  = 5  # Instead of 10
   ```

3. **Use DDoS Protection Standard** (free at network level)
   ```hcl
   enable_ddos_protection = true  # Minimal additional cost
   ```

4. **Use Standard Front Door** (if acceptable)
   ```hcl
   frontdoor_sku = "Standard_AzureFrontDoor"  # -$20/day
   ```

5. **Single Region (Dev/Test)**
   - Comment out secondary region resources
   - Deploy only Phase 01-08, skip phase 11 (Front Door)
   - Estimated cost: ~$1,500/month

### Monthly Cost Breakdown

| Resource | Count | Monthly | Notes |
|----------|-------|---------|-------|
| Azure Firewall (Standard) | 4 | $1,460 | $32.50/day each |
| App Gateway (WAF_v2) | 2 | $600 | $10/day base + data |
| Front Door (Premium) | 1 | $1,100 | $36.70/day |
| Public IPs | 8 | $32 | $4/month each |
| VNets/Subnets/NSGs | - | ~$50 | Minimal |
| **TOTAL** | | **~$3,242** | Prod + both regions |

---

## Security Best Practices

### Network Security

✅ **Implemented in this template:**
- NSGs with deny-by-default inbound rules
- Azure Firewalls in perimeter and internal tiers
- Application Gateway WAF enabled (OWASP 3.1)
- Front Door WAF with rate limiting (2000 req/min/IP)
- NTP, DNS, SMB inspection
- Threat intelligence alerts enabled

### Additional Hardening

```hcl
# 1. Enable DDoS Protection Standard
enable_ddos_protection = true

# 2. Use Premium Firewall (threat prevention)
firewall_sku = "Premium"

# 3. Enable resource locks
enable_resource_lock = true

# 4. Configure private endpoints for PaaS (future phases)

# 5. Enable NSG flow logs
# (Not in template; add manually)

# 6. Configure Azure Monitor/Sentinel
# (Not in template; add manually)
```

### Firewall Rules

**Default deny + explicit allow:**

```
┌─────────────────────────────────┐
│ Internet < ─ [ceDMZ Firewall]  │ ← Perimeter defense
│ HTTP/HTTPS/DNS                  │
└────────┬────────────────────────┘
         │ (allowed)
┌────────▼────────────────────────┐
│ ciDMZ [ AppGW + LB ]            │ ← Layer 7 inspection
```

---

## Post-Deployment

### Validation Checklist

- [ ] All 12 phases deployed successfully
- [ ] Resource Groups created (WE + NE)
- [ ] 4 VNets created with correct CIDR blocks
- [ ] 14 Subnets created with correct routing
- [ ] 10 NSGs applied to subnets
- [ ] 4 Firewalls provisioned and rule-collected
- [ ] 2 AppGateways in WAF mode
- [ ] Front Door endpoint accessible
- [ ] Health probes passing
- [ ] Route tables routing through firewalls
- [ ] No NSG deny rules blocking legitimate traffic

### Post-Deployment Steps

1. **Test Connectivity**
   ```powershell
   # Test from AppGW backend VMs to Firewall
   az vm run-command invoke -g MIP-SI-WE-RG -n <vm> --command-id RunPowerShellScript --scripts "Test-NetConnection <firewall-ip> -p 53"
   ```

2. **Verify Firewall Rules**
   ```powershell
   az network firewall policy rule-collection-group list -g MIP-SI-WE-RG --policy-name MIP-SI-WE-FW-Policy
   ```

3. **Configure SSL Certificates**
   - Install certificates on AppGateways
   - Update listeners to use HTTPS
   - Test TLS handshake

4. **Add Backend Pools**
   - Deploy VMs/app services
   - Add to AppGW backend pools
   - Test health probes

5. **Enable Monitoring**
   ```powershell
   # Enable diagnostic logs
   az monitor metrics list -g MIP-SI-WE-RG `
     --resource-type Microsoft.Network/azureFirewalls `
     --metric "FirewallHealth"
   ```

6. **Document Endpoints**
   ```powershell
   # Export key endpoints
   terraform output -json | Set-Content deployment-summary.json
   ```

### Useful Post-Deploy Commands

```powershell
# Get all public IPs
az network public-ip list -g MIP-SI-WE-RG --query "[].{Name:name, IP:ipAddress}" -o table

# Get AppGW health status
az network application-gateway show -g MIP-SI-WE-RG -n MIP-SI-WE-ciDMZ-AppGW --query "backendHealthHttp"

# Get Front Door status
az cdn endpoint show -g MIP-SI-WE-RG -p mip-si-global-frontdoor -n mip-si-global

# List firewall rules
az network firewall policy rule-collection-group list -g MIP-SI-WE-RG --policy-name MIP-SI-WE-FW-Policy
```

---

## Maintenance & Updates

### Regular Tasks

Weekly:
- [ ] Review NSG/Firewall logs for anomalies
- [ ] Check health probe status

Monthly:
- [ ] Review cost allocation
- [ ] Test disaster recovery (secondary region)
- [ ] Patch management planning

Quarterly:
- [ ] security audit
- [ ] Capacity review
- [ ] Update Terraform variables

### Updating Resources

To modify a specific resource:

```powershell
# Example: Change AppGW capacity
Set-Location phases/phase-08-application-gateways
# Edit main.tf or terraform.tfvars
terraform plan
terraform apply
```

### Destroying Resources

⚠️ **Reverse order of deployment (Phase 12 → Phase 01):**

```powershell
# Destroy Front Door (Phase 11 first)
Set-Location phases/phase-11-front-door
terraform destroy

# Then Phase 10, 09, etc.
# Finally Phase 01
Set-Location ../phase-01-resource-groups
terraform destroy
```

---

## Support & References

### Documentation Links

- [Azure Firewall](https://learn.microsoft.com/en-us/azure/firewall/)
- [Application Gateway](https://learn.microsoft.com/en-us/azure/application-gateway/)
- [Azure Front Door](https://learn.microsoft.com/en-us/azure/frontdoor/)
- [Terraform Azure Provider](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs)
- [Azure VNet Peering](https://learn.microsoft.com/en-us/azure/virtual-network/virtual-network-peering-overview)

### Getting Help

1. **Check Terraform Logs**
   ```powershell
   $env:TF_LOG = "DEBUG"
   terraform apply 2>&1 | Tee-Object -FilePath debug.log
   ```

2. **Validate Azure Resources**
   ```powershell
   az account show
   az group list
   az network vnet list
   ```

3. **Review Azure Activity Log**
   ```powershell
   az monitor activity-log list --resource-group MIP-SI-WE-RG --max-items 20
   ```

---

## License & Attribution

- **Template:** MIP-SI Multi-Region Landing Zone
- **Provider:** Terraform HashiCorp Azure Provider v4.0+
- **Maintainer:** HSBC Cloud Team
- **Last Updated:** March 2026

---

## Changelog

### v1.0 (March 2026)
- Initial 12-phase production-grade template
- Dual-region support (WE + NE)
- DMZ-style network segmentation
- Full WAF + DDoS protections
- Global ingress with Front Door

---

**🎉 Ready to deploy!**  
Start with **Phase 01** and follow the sequence. Happy deploying! 🚀
