output "we_lb_id" {
  value = azurerm_lb.we_cidmz_lb.id
}

output "we_lb_private_ip" {
  value = azurerm_lb.we_cidmz_lb.frontend_ip_configuration[0].private_ip_address
}

output "we_lb_backend_pool_id" {
  value = azurerm_lb_backend_address_pool.we_proxy_pool.id
}

output "ne_lb_id" {
  value = azurerm_lb.ne_cidmz_lb.id
}

output "ne_lb_private_ip" {
  value = azurerm_lb.ne_cidmz_lb.frontend_ip_configuration[0].private_ip_address
}

output "ne_lb_backend_pool_id" {
  value = azurerm_lb_backend_address_pool.ne_proxy_pool.id
}
