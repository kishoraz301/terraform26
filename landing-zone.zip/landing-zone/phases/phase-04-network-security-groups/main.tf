# Phase 04: Network Security Groups (NSGs)
# Deploy after Phase 03: Subnets
# Creates 4 NSGs for Proxy and RDS subnets in both West Europe and North Europe regions
# Each NSG includes detailed inbound and outbound rules with specific IP ranges, ports, and service tags

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# ============================================================================
# WEST EUROPE - NSGs
# ============================================================================

# ============================================================================
# WE Proxy DMZ NSG (MIP-SI-WE-Pxy-dmz-nsg) - Subnet: 10.200.11.0/26
# ============================================================================

resource "azurerm_network_security_group" "we_proxy_nsg" {
  name                = "MIP-SI-WE-Pxy-dmz-nsg"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  tags = merge(
    local.default_tags,
    { Subnet = "Proxy-DMZ", Region = "West Europe" }
  )
}

# ============================================================================
# WE Proxy Inbound Rules
# ============================================================================

# Allow-LINUX-SSH (Priority 100)
resource "azurerm_network_security_rule" "we_proxy_allow_ssh" {
  name                        = "Allow-LINUX-SSH"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "22"
  source_address_prefixes     = ["10.100.1.12", "10.150.1.12", "10.150.10.0/27", "10.100.10.0/27"]
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-NGINX-HTTPS (Priority 110)
resource "azurerm_network_security_rule" "we_proxy_allow_nginx_https" {
  name                        = "Allow-NGINX-HTTPS"
  priority                    = 110
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.160/27"
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-INTERNAL-to-SQUID-PROXY (Priority 120)
resource "azurerm_network_security_rule" "we_proxy_allow_squid" {
  name                        = "Allow-INTERNAL-to-SQUID-PROXY"
  priority                    = 120
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "3128", "8080"]
  source_address_prefix       = "10.100.0.0/16"
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-AZURELB-to-SQUID-PROXY (Priority 130)
resource "azurerm_network_security_rule" "we_proxy_allow_azurelb_squid" {
  name                        = "Allow-AZURELB-to-SQUID-PROXY"
  priority                    = 130
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3128"
  source_address_prefix       = "AzureLoadBalancer"
  destination_address_prefix  = "10.200.11.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Deny-All-Inbound (Priority 4096)
resource "azurerm_network_security_rule" "we_proxy_deny_inbound" {
  name                        = "Deny-All-Inbound"
  priority                    = 4096
  direction                   = "Inbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# ============================================================================
# WE Proxy Outbound Rules
# ============================================================================

# Allow-NGINX-to-CINTERNAL (Priority 200)
resource "azurerm_network_security_rule" "we_proxy_allow_nginx_cinternal" {
  name                        = "Allow-NGINX-to-CINTERNAL"
  priority                    = 200
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "10.100.0.0/16"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-SQUID-to-AFW-WEB (Priority 210)
resource "azurerm_network_security_rule" "we_proxy_allow_squid_afw" {
  name                        = "Allow-SQUID-to-AFW-WEB"
  priority                    = 210
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "10.200.50.0/26"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-DNS (Priority 230)
resource "azurerm_network_security_rule" "we_proxy_allow_dns" {
  name                        = "Allow-DNS"
  priority                    = 230
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "53"
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "AzureDNS"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-SFTP (Priority 240)
resource "azurerm_network_security_rule" "we_proxy_allow_sftp" {
  name                        = "Allow-SFTP"
  priority                    = 240
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "10022"
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefixes = ["161.113.228.48", "193.108.76.149", "91.214.5.149"]
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-Ubuntu-update (Priority 310) - to public Ubuntu repos
resource "azurerm_network_security_rule" "we_proxy_allow_ubuntu_public" {
  name                        = "Allow-Ubuntu-update"
  priority                    = 310
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Allow-UBUNTU-UPDATES-AZURE (Priority 320)
resource "azurerm_network_security_rule" "we_proxy_allow_ubuntu_azure" {
  name                        = "Allow-UBUNTU-UPDATES-AZURE"
  priority                    = 320
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.11.0/26"
  destination_address_prefixes = ["AzureCloud.WestEurope", "AzureCloud.NorthEurope"]
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# Deny-All-Outbound (Priority 4096)
resource "azurerm_network_security_rule" "we_proxy_deny_outbound" {
  name                        = "Deny-All-Outbound"
  priority                    = 4096
  direction                   = "Outbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_proxy_nsg.name
}

# ============================================================================
# WE RDS NSG (MIP-SI-WE-RDS-snet) - Subnet: 10.200.11.64/27
# ============================================================================

resource "azurerm_network_security_group" "we_rds_nsg" {
  name                = "MIP-SI-WE-RDS-snet"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  tags = merge(
    local.default_tags,
    { Subnet = "RDS", Region = "West Europe" }
  )
}

# ============================================================================
# WE RDS Inbound Rules
# ============================================================================

# Allow-IN-RDS-UK-VPN (Priority 200)
resource "azurerm_network_security_rule" "we_rds_allow_uk_vpn" {
  name                        = "Allow-IN-RDS-UK-VPN"
  priority                    = 200
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["27.110.72.0/23", "27.110.74.0/24", "27.110.75.0/25", "27.110.75.128/26", "27.110.75.192/27", "27.110.75.224/28", "27.110.75.240/29", "27.110.75.248/30", "27.110.75.252/32", "27.110.76.0/24", "27.110.77.0/25", "27.110.77.128/26", "27.110.77.192/27", "27.110.77.224/28", "27.110.77.240/29", "27.110.77.248/30", "27.110.77.252/32", "27.110.78.0/24", "27.110.79.0/25", "27.110.79.128/26", "27.110.79.192/27", "27.110.79.200/30", "27.110.79.204/31", "27.110.79.206/32", "27.110.79.207/32", "27.110.79.208/28", "27.110.79.224/27", "203.112.80.0/20", "161.113.192.0/19"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-IN-RDS-IND-VPN (Priority 210)
resource "azurerm_network_security_rule" "we_rds_allow_ind_vpn" {
  name                        = "Allow-IN-RDS-IND-VPN"
  priority                    = 210
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["203.171.222.0/29", "203.171.222.8/32", "203.171.222.9/32", "203.171.222.10/32", "203.171.222.12/30", "203.171.222.16/28", "203.171.222.32/27", "203.171.222.64/26", "203.171.222.128/25", "203.171.209.0/29", "203.171.209.8/30", "203.171.209.13/32", "203.171.209.14/32", "203.171.209.15/32", "203.171.209.16/28", "203.171.209.32/27", "203.171.209.64/26", "203.171.209.128/25", "103.171.66.0/27", "103.171.66.32/30", "103.171.66.33/32", "103.171.66.64/26", "103.171.66.128/25", "103.171.67.0/24", "103.54.135.32/28"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-IN-RDS-HK-VPN (Priority 230)
resource "azurerm_network_security_rule" "we_rds_allow_hk_vpn" {
  name                        = "Allow-IN-RDS-HK-VPN"
  priority                    = 230
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["91.214.4.0/24", "91.214.5.0/26", "91.214.5.64/28", "91.214.5.80/30", "91.214.5.84/32", "91.214.5.85/32", "91.214.5.88/29", "91.214.5.96/27", "91.214.5.128/25", "91.214.6.0/23", "193.108.72.0/22", "193.108.76.0/26", "193.108.76.64/28", "193.108.76.80/30", "193.108.76.84/32", "193.108.76.85/32", "193.108.76.88/29", "193.108.76.96/27", "193.108.76.128/25", "193.108.77.0/24", "193.108.78.0/23", "161.113.224.0/19"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-IN-RDS-SKYHIGH-VPN (Priority 240)
resource "azurerm_network_security_rule" "we_rds_allow_skyhigh_vpn" {
  name                        = "Allow-IN-RDS-SKYHIGH-VPN"
  priority                    = 240
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefixes     = ["161.69.53.62", "161.69.54.62", "161.69.55.62", "161.69.57.62", "161.69.60.62", "161.69.65.62", "161.69.66.62", "161.69.67.62", "161.69.71.62", "161.69.88.62", "161.69.89.62", "161.69.90.62", "161.69.91.62", "161.69.92.62", "161.69.108.62", "161.69.114.62", "161.69.116.62", "161.69.119.62", "161.69.68.62", "161.69.69.62", "161.69.93.62"]
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-AZFIREWALL (Priority 250)
resource "azurerm_network_security_rule" "we_rds_allow_azfirewall" {
  name                        = "Allow-AZFIREWALL"
  priority                    = 250
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.50.0/26"
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-MGMT-ADMIN-RDS (Priority 270)
resource "azurerm_network_security_rule" "we_rds_allow_mgmt_admin" {
  name                        = "Allow-MGMT-ADMIN-RDS"
  priority                    = 270
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "IPG-Admin-JumpHosts"
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-IN-RDS-INTERNAL (Priority 280)
resource "azurerm_network_security_rule" "we_rds_allow_internal" {
  name                        = "Allow-IN-RDS-INTERNAL"
  priority                    = 280
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefix       = "IPG-RDS-Internal-Mgmt"
  destination_address_prefix  = "10.200.11.64/27"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Deny-All-Inbound (Priority 4096)
resource "azurerm_network_security_rule" "we_rds_deny_inbound" {
  name                        = "Deny-All-Inbound"
  priority                    = 4096
  direction                   = "Inbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# ============================================================================
# WE RDS Outbound Rules
# ============================================================================

# Allow-SESSIONHOSTS-RDP-TCP (Priority 100)
resource "azurerm_network_security_rule" "we_rds_allow_sessionhosts_rdp_tcp" {
  name                        = "Allow-SESSIONHOSTS-RDP-TCP"
  priority                    = 100
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefixes = ["10.100.1.11", "10.100.1.12", "10.100.1.14"]
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-SESSIONHOSTS-RDP-UDP (Priority 110)
resource "azurerm_network_security_rule" "we_rds_allow_sessionhosts_rdp_udp" {
  name                        = "Allow-SESSIONHOSTS-RDP-UDP"
  priority                    = 110
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefixes = ["10.100.1.11", "10.100.1.12", "10.100.1.14"]
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-To-Firewall-Direct (Priority 120)
resource "azurerm_network_security_rule" "we_rds_allow_firewall_direct" {
  name                        = "Allow-To-Firewall-Direct"
  priority                    = 120
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureFirewall"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-RD-CONNECTIONBROKER (Priority 130)
resource "azurerm_network_security_rule" "we_rds_allow_connectionbroker" {
  name                        = "Allow-RD-CONNECTIONBROKER"
  priority                    = 130
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5504"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "10.100.1.10"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-RD-WMIDC (Priority 140)
resource "azurerm_network_security_rule" "we_rds_allow_wmidc" {
  name                        = "Allow-RD-WMIDC"
  priority                    = 140
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefixes = ["10.100.0.0/24", "10.100.1.0/24", "10.100.2.0/24"]
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP (Priority 150)
resource "azurerm_network_security_rule" "we_rds_allow_dc_tcp" {
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP"
  priority                    = 150
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "80", "88", "135", "139", "389", "443", "445", "464", "636", "5000-5100", "49152-65535"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP (Priority 160)
resource "azurerm_network_security_rule" "we_rds_allow_dc_udp" {
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP"
  priority                    = 160
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "88", "123", "137", "138", "389", "464"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-NGINX-To-AppBackend (Priority 170)
resource "azurerm_network_security_rule" "we_rds_allow_nginx_app" {
  name                        = "Allow-NGINX-To-AppBackend"
  priority                    = 170
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "App-Subnet"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-AZUREBACKUP (Priority 4015)
resource "azurerm_network_security_rule" "we_rds_allow_azurebackup" {
  name                        = "Allow-AZUREBACKUP"
  priority                    = 4015
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureBackup"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-AZUREMONITOR (Priority 4018)
resource "azurerm_network_security_rule" "we_rds_allow_azuremonitor" {
  name                        = "Allow-AZUREMONITOR"
  priority                    = 4018
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureMonitor"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-MDE (Priority 4019)
resource "azurerm_network_security_rule" "we_rds_allow_mde" {
  name                        = "Allow-MDE"
  priority                    = 4019
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "MicrosoftDefenderForEndpoint"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-AAD (Priority 4020)
resource "azurerm_network_security_rule" "we_rds_allow_aad" {
  name                        = "Allow-AAD"
  priority                    = 4020
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "AzureActiveDirectory"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Allow-CROWDSTRIKE (Priority 4025)
resource "azurerm_network_security_rule" "we_rds_allow_crowdstrike" {
  name                        = "Allow-CROWDSTRIKE"
  priority                    = 4025
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.11.64/27"
  destination_address_prefix  = "IPG-CrowdStrike-Cloud"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# Deny-All-Outbound (Priority 4096)
resource "azurerm_network_security_rule" "we_rds_deny_outbound" {
  name                        = "Deny-All-Outbound"
  priority                    = 4096
  direction                   = "Outbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.we.name
  network_security_group_name = azurerm_network_security_group.we_rds_nsg.name
}

# ============================================================================
# NORTH EUROPE - NSGs
# ============================================================================

# ============================================================================
# NE Proxy DMZ NSG (MIP-SI-NE-Pxy-dmz-nsg) - Subnet: 10.200.12.0/26
# ============================================================================

resource "azurerm_network_security_group" "ne_proxy_nsg" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-Pxy-dmz-nsg"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  tags = merge(
    local.default_tags,
    { Subnet = "Proxy-DMZ", Region = "North Europe" }
  )
}

# ============================================================================
# NE Proxy Inbound Rules
# ============================================================================

# Allow-LINUX-SSH (Priority 100)
resource "azurerm_network_security_rule" "ne_proxy_allow_ssh" {
  provider                    = azurerm.secondary
  name                        = "Allow-LINUX-SSH"
  priority                    = 100
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "22"
  source_address_prefixes     = ["10.150.1.12", "10.150.10.0/27"]
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-NGINX-HTTPS (Priority 110)
resource "azurerm_network_security_rule" "ne_proxy_allow_nginx_https" {
  provider                    = azurerm.secondary
  name                        = "Allow-NGINX-HTTPS"
  priority                    = 110
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.160/27"
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-INTERNAL-to-SQUID-PROXY (Priority 120)
resource "azurerm_network_security_rule" "ne_proxy_allow_squid" {
  provider                    = azurerm.secondary
  name                        = "Allow-INTERNAL-to-SQUID-PROXY"
  priority                    = 120
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "3128", "8080"]
  source_address_prefix       = "10.150.0.0/16"
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-AZURELB-to-SQUID-PROXY (Priority 130)
resource "azurerm_network_security_rule" "ne_proxy_allow_azurelb_squid" {
  provider                    = azurerm.secondary
  name                        = "Allow-AZURELB-to-SQUID-PROXY"
  priority                    = 130
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3128"
  source_address_prefix       = "AzureLoadBalancer"
  destination_address_prefix  = "10.200.12.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Deny-All-Inbound (Priority 4096)
resource "azurerm_network_security_rule" "ne_proxy_deny_inbound" {
  provider                    = azurerm.secondary
  name                        = "Deny-All-Inbound"
  priority                    = 4096
  direction                   = "Inbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# ============================================================================
# NE Proxy Outbound Rules
# ============================================================================

# Allow-NGINX-to-CINTERNAL (Priority 200)
resource "azurerm_network_security_rule" "ne_proxy_allow_nginx_cinternal" {
  provider                    = azurerm.secondary
  name                        = "Allow-NGINX-to-CINTERNAL"
  priority                    = 200
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefix  = "10.150.0.0/16"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-SQUID-to-AFW-NEB (Priority 210)
resource "azurerm_network_security_rule" "ne_proxy_allow_squid_afw" {
  provider                    = azurerm.secondary
  name                        = "Allow-SQUID-to-AFW-NEB"
  priority                    = 210
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefix  = "10.200.60.0/26"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-DNS (Priority 230)
resource "azurerm_network_security_rule" "ne_proxy_allow_dns" {
  provider                    = azurerm.secondary
  name                        = "Allow-DNS"
  priority                    = 230
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "53"
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefix  = "AzureDNS"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-SFTP (Priority 240)
resource "azurerm_network_security_rule" "ne_proxy_allow_sftp" {
  provider                    = azurerm.secondary
  name                        = "Allow-SFTP"
  priority                    = 240
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "10022"
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefixes = ["161.113.228.48", "193.108.76.149", "91.214.5.149"]
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-Ubuntu-update (Priority 310) - to public Ubuntu repos
resource "azurerm_network_security_rule" "ne_proxy_allow_ubuntu_public" {
  provider                    = azurerm.secondary
  name                        = "Allow-Ubuntu-update"
  priority                    = 310
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Allow-UBUNTU-UPDATES-AZURE (Priority 320)
resource "azurerm_network_security_rule" "ne_proxy_allow_ubuntu_azure" {
  provider                    = azurerm.secondary
  name                        = "Allow-UBUNTU-UPDATES-AZURE"
  priority                    = 320
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.12.0/26"
  destination_address_prefixes = ["AzureCloud.NorthEurope"]
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# Deny-All-Outbound (Priority 4096)
resource "azurerm_network_security_rule" "ne_proxy_deny_outbound" {
  provider                    = azurerm.secondary
  name                        = "Deny-All-Outbound"
  priority                    = 4096
  direction                   = "Outbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_proxy_nsg.name
}

# ============================================================================
# NE RDS NSG (MIP-SI-NE-RDS-snet) - Subnet: 10.200.12.64/27
# ============================================================================

resource "azurerm_network_security_group" "ne_rds_nsg" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-RDS-snet"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  tags = merge(
    local.default_tags,
    { Subnet = "RDS", Region = "North Europe" }
  )
}

# ============================================================================
# NE RDS Inbound Rules
# ============================================================================

# Allow-IN-RDS-UK-VPN (Priority 200)
resource "azurerm_network_security_rule" "ne_rds_allow_uk_vpn" {
  provider            = azurerm.secondary
  name                = "Allow-IN-RDS-UK-VPN"
  priority            = 200
  direction           = "Inbound"
  access              = "Allow"
  protocol            = "Tcp"
  source_port_range   = "*"
  destination_port_range = "443"
  source_address_prefixes = ["27.110.72.0/23", "27.110.74.0/24", "27.110.75.0/25", "27.110.75.128/26", "27.110.75.192/27", "27.110.75.224/28", "27.110.75.240/29", "27.110.75.248/30", "27.110.75.252/32", "27.110.76.0/24", "27.110.77.0/25", "27.110.77.128/26", "27.110.77.192/27", "27.110.77.224/28", "27.110.77.240/29", "27.110.77.248/30", "27.110.77.252/32", "27.110.78.0/24", "27.110.79.0/25", "27.110.79.128/26", "27.110.79.192/27", "27.110.79.200/30", "27.110.79.204/31", "27.110.79.206/32", "27.110.79.207/32", "27.110.79.208/28", "27.110.79.224/27", "203.112.80.0/20", "161.113.192.0/19"]
  destination_address_prefix = "10.200.12.64/27"
  resource_group_name = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-IN-RDS-Ind-VPN (Priority 210)
resource "azurerm_network_security_rule" "ne_rds_allow_ind_vpn" {
  provider            = azurerm.secondary
  name                = "Allow-IN-RDS-Ind-VPN"
  priority            = 210
  direction           = "Inbound"
  access              = "Allow"
  protocol            = "Tcp"
  source_port_range   = "*"
  destination_port_range = "443"
  source_address_prefixes = ["203.171.222.0/29", "203.171.222.8/32", "203.171.222.9/32", "203.171.222.10/32", "203.171.222.12/30", "203.171.222.16/28", "203.171.222.32/27", "203.171.222.64/26", "203.171.222.128/25", "203.171.209.0/29", "203.171.209.8/30", "203.171.209.13/32", "203.171.209.14/32", "203.171.209.15/32", "203.171.209.16/28", "203.171.209.32/27", "203.171.209.64/26", "203.171.209.128/25", "103.171.66.0/27", "103.171.66.32/30", "103.171.66.33/32", "103.171.66.64/26", "103.171.66.128/25", "103.171.67.0/24", "103.54.135.32/28"]
  destination_address_prefix = "10.200.12.64/27"
  resource_group_name = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-IN-RDS-HK-VPN (Priority 230)
resource "azurerm_network_security_rule" "ne_rds_allow_hk_vpn" {
  provider            = azurerm.secondary
  name                = "Allow-IN-RDS-HK-VPN"
  priority            = 230
  direction           = "Inbound"
  access              = "Allow"
  protocol            = "Tcp"
  source_port_range   = "*"
  destination_port_range = "443"
  source_address_prefixes = ["91.214.4.0/24", "91.214.5.0/26", "91.214.5.64/28", "91.214.5.80/30", "91.214.5.84/32", "91.214.5.85/32", "91.214.5.88/29", "91.214.5.96/27", "91.214.5.128/25", "91.214.6.0/23", "193.108.72.0/22", "193.108.76.0/26", "193.108.76.64/28", "193.108.76.80/30", "193.108.76.84/32", "193.108.76.85/32", "193.108.76.88/29", "193.108.76.96/27", "193.108.76.128/25", "193.108.77.0/24", "193.108.78.0/23", "161.113.224.0/19"]
  destination_address_prefix = "10.200.12.64/27"
  resource_group_name = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-IN-RDS-SKYHIGH-VPN (Priority 240)
resource "azurerm_network_security_rule" "ne_rds_allow_skyhigh_vpn" {
  provider            = azurerm.secondary
  name                = "Allow-IN-RDS-SKYHIGH-VPN"
  priority            = 240
  direction           = "Inbound"
  access              = "Allow"
  protocol            = "Tcp"
  source_port_range   = "*"
  destination_port_range = "443"
  source_address_prefixes = ["161.69.53.62", "161.69.54.62", "161.69.55.62", "161.69.57.62", "161.69.60.62", "161.69.65.62", "161.69.66.62", "161.69.67.62", "161.69.71.62", "161.69.88.62", "161.69.89.62", "161.69.90.62", "161.69.91.62", "161.69.92.62", "161.69.108.62", "161.69.114.62", "161.69.116.62", "161.69.119.62", "161.69.68.62", "161.69.69.62", "161.69.93.62"]
  destination_address_prefix = "10.200.12.64/27"
  resource_group_name = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-AZFIREWALL (Priority 250)
resource "azurerm_network_security_rule" "ne_rds_allow_azfirewall" {
  provider                    = azurerm.secondary
  name                        = "Allow-AZFIREWALL"
  priority                    = 250
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.60.0/26"
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-MGMT-ADMIN-RDS (Priority 270)
resource "azurerm_network_security_rule" "ne_rds_allow_mgmt_admin" {
  provider                    = azurerm.secondary
  name                        = "Allow-MGMT-ADMIN-RDS"
  priority                    = 270
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "IPG-Admin-JumpHosts"
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-IN-RDS-INTERNAL (Priority 280)
resource "azurerm_network_security_rule" "ne_rds_allow_internal" {
  provider                    = azurerm.secondary
  name                        = "Allow-IN-RDS-INTERNAL"
  priority                    = 280
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefix       = "IPG-RDS-Internal-Mgmt"
  destination_address_prefix  = "10.200.12.64/27"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Deny-All-Inbound (Priority 4096)
resource "azurerm_network_security_rule" "ne_rds_deny_inbound" {
  provider                    = azurerm.secondary
  name                        = "Deny-All-Inbound"
  priority                    = 4096
  direction                   = "Inbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# ============================================================================
# NE RDS Outbound Rules
# ============================================================================

# Allow-SESSIONHOSTS-RDP-TCP (Priority 100)
resource "azurerm_network_security_rule" "ne_rds_allow_sessionhosts_rdp_tcp" {
  provider                    = azurerm.secondary
  name                        = "Allow-SESSIONHOSTS-RDP-TCP"
  priority                    = 100
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefixes = ["10.150.1.11", "10.150.1.12", "10.150.1.14"]
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-SESSIONHOSTS-RDP-UDP (Priority 110)
resource "azurerm_network_security_rule" "ne_rds_allow_sessionhosts_rdp_udp" {
  provider                    = azurerm.secondary
  name                        = "Allow-SESSIONHOSTS-RDP-UDP"
  priority                    = 110
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_range      = "3389"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefixes = ["10.150.1.11", "10.150.1.12", "10.150.1.14"]
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-To-Firewall-Direct (Priority 120)
resource "azurerm_network_security_rule" "ne_rds_allow_firewall_direct" {
  provider                    = azurerm.secondary
  name                        = "Allow-To-Firewall-Direct"
  priority                    = 120
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureFirewall"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-RD-CONNECTIONBROKER (Priority 130)
resource "azurerm_network_security_rule" "ne_rds_allow_connectionbroker" {
  provider                    = azurerm.secondary
  name                        = "Allow-RD-CONNECTIONBROKER"
  priority                    = 130
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5504"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "10.150.1.10"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-RD-WMIDC (Priority 140)
resource "azurerm_network_security_rule" "ne_rds_allow_wmidc" {
  provider                    = azurerm.secondary
  name                        = "Allow-RD-WMIDC"
  priority                    = 140
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "5985"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefixes = ["10.150.0.0/24", "10.150.1.0/24", "10.150.2.0/24"]
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP (Priority 150)
resource "azurerm_network_security_rule" "ne_rds_allow_dc_tcp" {
  provider                    = azurerm.secondary
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-TCP"
  priority                    = 150
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "80", "88", "135", "139", "389", "443", "445", "464", "636", "5000-5100", "49152-65535"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP (Priority 160)
resource "azurerm_network_security_rule" "ne_rds_allow_dc_udp" {
  provider                    = azurerm.secondary
  name                        = "Allow-DC-DNS-KERB-LDAP-GC-RPC-UDP"
  priority                    = 160
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Udp"
  source_port_range           = "*"
  destination_port_ranges     = ["53", "88", "123", "137", "138", "389", "464"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "VirtualNetwork"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-NGINX-To-AppBackend (Priority 170)
resource "azurerm_network_security_rule" "ne_rds_allow_nginx_app" {
  provider                    = azurerm.secondary
  name                        = "Allow-NGINX-To-AppBackend"
  priority                    = 170
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_ranges     = ["80", "443"]
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "App-Subnet"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-AZUREBACKUP (Priority 4015)
resource "azurerm_network_security_rule" "ne_rds_allow_azurebackup" {
  provider                    = azurerm.secondary
  name                        = "Allow-AZUREBACKUP"
  priority                    = 4015
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureBackup"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-AZUREMONITOR (Priority 4018)
resource "azurerm_network_security_rule" "ne_rds_allow_azuremonitor" {
  provider                    = azurerm.secondary
  name                        = "Allow-AZUREMONITOR"
  priority                    = 4018
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureMonitor"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-MDE (Priority 4019)
resource "azurerm_network_security_rule" "ne_rds_allow_mde" {
  provider                    = azurerm.secondary
  name                        = "Allow-MDE"
  priority                    = 4019
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "MicrosoftDefenderForEndpoint"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-AAD (Priority 4020)
resource "azurerm_network_security_rule" "ne_rds_allow_aad" {
  provider                    = azurerm.secondary
  name                        = "Allow-AAD"
  priority                    = 4020
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "AzureActiveDirectory"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Allow-CROWDSTRIKE (Priority 4025)
resource "azurerm_network_security_rule" "ne_rds_allow_crowdstrike" {
  provider                    = azurerm.secondary
  name                        = "Allow-CROWDSTRIKE"
  priority                    = 4025
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "10.200.12.64/27"
  destination_address_prefix  = "IPG-CrowdStrike-Cloud"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}

# Deny-All-Outbound (Priority 4096)
resource "azurerm_network_security_rule" "ne_rds_deny_outbound" {
  provider                    = azurerm.secondary
  name                        = "Deny-All-Outbound"
  priority                    = 4096
  direction                   = "Outbound"
  access                      = "Deny"
  protocol                    = "*"
  source_port_range           = "*"
  destination_port_range      = "*"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = data.azurerm_resource_group.ne.name
  network_security_group_name = azurerm_network_security_group.ne_rds_nsg.name
}
