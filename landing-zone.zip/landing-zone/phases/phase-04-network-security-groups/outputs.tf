# ============================================================================
# West Europe NSG Outputs
# ============================================================================

output "we_proxy_nsg_id" {
  description = "West Europe Proxy DMZ NSG ID"
  value       = azurerm_network_security_group.we_proxy_nsg.id
}

output "we_proxy_nsg_name" {
  description = "West Europe Proxy DMZ NSG Name"
  value       = azurerm_network_security_group.we_proxy_nsg.name
}

output "we_rds_nsg_id" {
  description = "West Europe RDS NSG ID"
  value       = azurerm_network_security_group.we_rds_nsg.id
}

output "we_rds_nsg_name" {
  description = "West Europe RDS NSG Name"
  value       = azurerm_network_security_group.we_rds_nsg.name
}

# ============================================================================
# North Europe NSG Outputs
# ============================================================================

output "ne_proxy_nsg_id" {
  description = "North Europe Proxy DMZ NSG ID"
  value       = azurerm_network_security_group.ne_proxy_nsg.id
}

output "ne_proxy_nsg_name" {
  description = "North Europe Proxy DMZ NSG Name"
  value       = azurerm_network_security_group.ne_proxy_nsg.name
}

output "ne_rds_nsg_id" {
  description = "North Europe RDS NSG ID"
  value       = azurerm_network_security_group.ne_rds_nsg.id
}

output "ne_rds_nsg_name" {
  description = "North Europe RDS NSG Name"
  value       = azurerm_network_security_group.ne_rds_nsg.name
}

# ============================================================================
# Summary Output
# ============================================================================

output "nsg_summary" {
  description = "Summary of all NSGs created in Phase 04"
  value = {
    west_europe = {
      proxy_dmz = {
        name = azurerm_network_security_group.we_proxy_nsg.name
        id   = azurerm_network_security_group.we_proxy_nsg.id
      }
      rds = {
        name = azurerm_network_security_group.we_rds_nsg.name
        id   = azurerm_network_security_group.we_rds_nsg.id
      }
    }
    north_europe = {
      proxy_dmz = {
        name = azurerm_network_security_group.ne_proxy_nsg.name
        id   = azurerm_network_security_group.ne_proxy_nsg.id
      }
      rds = {
        name = azurerm_network_security_group.ne_rds_nsg.name
        id   = azurerm_network_security_group.ne_rds_nsg.id
      }
    }
  }
}
