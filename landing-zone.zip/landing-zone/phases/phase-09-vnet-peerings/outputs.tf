output "we_cedmz_cidmz_peering_id" {
  value = azurerm_virtual_network_peering.we_cedmz_to_cidmz.id
}

output "ne_cedmz_cidmz_peering_id" {
  value = azurerm_virtual_network_peering.ne_cedmz_to_cidmz.id
}
