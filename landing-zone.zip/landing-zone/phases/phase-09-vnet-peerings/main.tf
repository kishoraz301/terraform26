# Phase 09: VNet Peerings (4 peer relationships)
# Deploy after Phase 02: Virtual Networks

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

data "azurerm_virtual_network" "we_cedmz" {
  name                = "MIP-SI-WE-ceDMZ-vnet"
  resource_group_name = var.we_resource_group_name
}

data "azurerm_virtual_network" "we_cidmz" {
  name                = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name = var.we_resource_group_name
}

data "azurerm_virtual_network" "ne_cedmz" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ceDMZ-vnet"
  resource_group_name = var.ne_resource_group_name
}

data "azurerm_virtual_network" "ne_cidmz" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name = var.ne_resource_group_name
}

# West Europe: ceDMZ to ciDMZ peering
resource "azurerm_virtual_network_peering" "we_cedmz_to_cidmz" {
  name                      = "MIP-SI-WE-ceDMZ-to-ciDMZ"
  resource_group_name       = var.we_resource_group_name
  virtual_network_name      = data.azurerm_virtual_network.we_cedmz.name
  remote_virtual_network_id = data.azurerm_virtual_network.we_cidmz.id
  allow_virtual_network_access = true
  allow_forwarded_traffic   = true
  allow_gateway_transit     = false
  use_remote_gateways       = false
}

# West Europe: ciDMZ to ceDMZ peering (reciprocal)
resource "azurerm_virtual_network_peering" "we_cidmz_to_cedmz" {
  name                      = "MIP-SI-WE-ciDMZ-to-ceDMZ"
  resource_group_name       = var.we_resource_group_name
  virtual_network_name      = data.azurerm_virtual_network.we_cidmz.name
  remote_virtual_network_id = data.azurerm_virtual_network.we_cedmz.id
  allow_virtual_network_access = true
  allow_forwarded_traffic   = true
  allow_gateway_transit     = false
  use_remote_gateways       = false
}

# North Europe: ceDMZ to ciDMZ peering
resource "azurerm_virtual_network_peering" "ne_cedmz_to_cidmz" {
  provider                   = azurerm.secondary
  name                      = "MIP-SI-NE-ceDMZ-to-ciDMZ"
  resource_group_name       = var.ne_resource_group_name
  virtual_network_name      = data.azurerm_virtual_network.ne_cedmz.name
  remote_virtual_network_id = data.azurerm_virtual_network.ne_cidmz.id
  allow_virtual_network_access = true
  allow_forwarded_traffic   = true
  allow_gateway_transit     = false
  use_remote_gateways       = false
}

# North Europe: ciDMZ to ceDMZ peering (reciprocal)
resource "azurerm_virtual_network_peering" "ne_cidmz_to_cedmz" {
  provider                   = azurerm.secondary
  name                      = "MIP-SI-NE-ciDMZ-to-ceDMZ"
  resource_group_name       = var.ne_resource_group_name
  virtual_network_name      = data.azurerm_virtual_network.ne_cidmz.name
  remote_virtual_network_id = data.azurerm_virtual_network.ne_cedmz.id
  allow_virtual_network_access = true
  allow_forwarded_traffic   = true
  allow_gateway_transit     = false
  use_remote_gateways       = false
}
