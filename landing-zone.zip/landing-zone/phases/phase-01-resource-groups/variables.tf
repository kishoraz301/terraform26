# Import global variables
variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
}

variable "primary_region" {
  description = "Primary Azure region"
  type        = string
  default     = "westeurope"
}

variable "secondary_region" {
  description = "Secondary Azure region"
  type        = string
  default     = "northeurope"
}

variable "primary_subscription_id" {
  description = "Primary subscription ID"
  type        = string
  sensitive   = true
}

variable "secondary_subscription_id" {
  description = "Secondary subscription ID"
  type        = string
  sensitive   = true
}

variable "we_resource_group_name" {
  description = "West Europe Resource Group name"
  type        = string
  default     = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  description = "North Europe Resource Group name"
  type        = string
  default     = "MIP-SI-NE-RG"
}

# Local variables (mirroring global)
locals {
  default_tags = {
    Project     = "HSBC"
    Environment = var.environment
    Namespace   = "MIP-SI"
    ManagedBy   = "Terraform"
    CreatedDate = formatdate("YYYY-MM-DD", timestamp())
  }
}
