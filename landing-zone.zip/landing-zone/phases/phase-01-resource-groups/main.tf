# Phase 01: Resource Groups
# This is the foundational phase. Deploy this first before any other resources.
#
# SHARED CONFIGURATION: This phase uses shared configuration from the root directory:
# - Providers: See ../../../providers.tf
# - Variables: See ../../../variables.tf  
# - Locals: See ../../../locals.tf
# For consolidation details, see ../../../CONSOLIDATION_GUIDE.md

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

# Data source to get current client config
data "azurerm_client_config" "current" {}

# West Europe Resource Group - Primary Region
resource "azurerm_resource_group" "we" {
  name       = var.we_resource_group_name
  location   = var.primary_region
  
  tags = merge(
    local.default_tags,
    {
      Region = "Primary (West Europe)"
    }
  )
}

# North Europe Resource Group - Secondary Region
resource "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  
  name     = var.ne_resource_group_name
  location = var.secondary_region
  
  tags = merge(
    local.default_tags,
    {
      Region = "Secondary (North Europe)"
    }
  )
}

