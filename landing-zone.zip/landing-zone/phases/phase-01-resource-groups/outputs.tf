output "we_resource_group_name" {
  description = "West Europe Resource Group name"
  value       = azurerm_resource_group.we.name
}

output "we_resource_group_id" {
  description = "West Europe Resource Group ID"
  value       = azurerm_resource_group.we.id
}

output "ne_resource_group_name" {
  description = "North Europe Resource Group name"
  value       = azurerm_resource_group.ne.name
}

output "ne_resource_group_id" {
  description = "North Europe Resource Group ID"
  value       = azurerm_resource_group.ne.id
}
