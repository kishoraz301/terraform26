output "we_cedmz_rt_id" {
  value = azurerm_route_table.we_cedmz_rt.id
}

output "we_cidmz_rt_id" {
  value = azurerm_route_table.we_cidmz_rt.id
}

output "ne_cedmz_rt_id" {
  value = azurerm_route_table.ne_cedmz_rt.id
}

output "ne_cidmz_rt_id" {
  value = azurerm_route_table.ne_cidmz_rt.id
}
