# Phase 10: Route Tables (4 total: 2 per region)
# Deploy after Phase 02, 06: Virtual Networks, Azure Firewalls

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# ============================================================================
# WEST EUROPE - Route Tables
# ============================================================================

# WE ceDMZ Route Table
resource "azurerm_route_table" "we_cedmz_rt" {
  name                = "MIP-SI-WE-ceDMZ-RT"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  route {
    name           = "Default-to-Internet"
    address_prefix = "0.0.0.0/0"
    next_hop_type  = "Internet"
  }

  tags = merge(
    local.default_tags,
    { Tier = "ceDMZ", Region = "West Europe" }
  )
}

# WE ciDMZ Route Table
resource "azurerm_route_table" "we_cidmz_rt" {
  name                = "MIP-SI-WE-ciDMZ-RT"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  route {
    name                   = "Default-to-Internal-Firewall"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.200.11.196"
  }



  tags = merge(
    local.default_tags,
    { Tier = "ciDMZ", Region = "West Europe" }
  )
}

# ============================================================================
# NORTH EUROPE - Route Tables
# ============================================================================

resource "azurerm_route_table" "ne_cedmz_rt" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ceDMZ-RT"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  route {
    name           = "Default-to-Internet"
    address_prefix = "0.0.0.0/0"
    next_hop_type  = "Internet"
  }

  tags = merge(
    local.default_tags,
    { Tier = "ceDMZ", Region = "North Europe" }
  )
}

resource "azurerm_route_table" "ne_cidmz_rt" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-RT"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  route {
    name                   = "Default-to-Internal-Firewall"
    address_prefix         = "0.0.0.0/0"
    next_hop_type          = "VirtualAppliance"
    next_hop_in_ip_address = "10.200.12.196"
  }



  tags = merge(
    local.default_tags,
    { Tier = "ciDMZ", Region = "North Europe" }
  )
}

# ============================================================================
# Route Table Subnet Associations
# ============================================================================

# WE ceDMZ associations
resource "azurerm_subnet_route_table_association" "we_cedmz_afw_rta" {
  subnet_id      = data.azurerm_subnet.we_cedmz_afw.id
  route_table_id = azurerm_route_table.we_cedmz_rt.id
}

resource "azurerm_subnet_route_table_association" "we_cedmz_reserved_rta" {
  subnet_id      = data.azurerm_subnet.we_cedmz_reserved.id
  route_table_id = azurerm_route_table.we_cedmz_rt.id
}

# WE ciDMZ associations
resource "azurerm_subnet_route_table_association" "we_cidmz_proxy_rta" {
  subnet_id      = data.azurerm_subnet.we_cidmz_proxy.id
  route_table_id = azurerm_route_table.we_cidmz_rt.id
}

resource "azurerm_subnet_route_table_association" "we_cidmz_rds_rta" {
  subnet_id      = data.azurerm_subnet.we_cidmz_rds.id
  route_table_id = azurerm_route_table.we_cidmz_rt.id
}

# NE ceDMZ associations
resource "azurerm_subnet_route_table_association" "ne_cedmz_afw_rta" {
  provider       = azurerm.secondary
  subnet_id      = data.azurerm_subnet.ne_cedmz_afw.id
  route_table_id = azurerm_route_table.ne_cedmz_rt.id
}

resource "azurerm_subnet_route_table_association" "ne_cedmz_reserved_rta" {
  provider       = azurerm.secondary
  subnet_id      = data.azurerm_subnet.ne_cedmz_reserved.id
  route_table_id = azurerm_route_table.ne_cedmz_rt.id
}

# NE ciDMZ associations
resource "azurerm_subnet_route_table_association" "ne_cidmz_proxy_rta" {
  provider       = azurerm.secondary
  subnet_id      = data.azurerm_subnet.ne_cidmz_proxy.id
  route_table_id = azurerm_route_table.ne_cidmz_rt.id
}

resource "azurerm_subnet_route_table_association" "ne_cidmz_rds_rta" {
  provider       = azurerm.secondary
  subnet_id      = data.azurerm_subnet.ne_cidmz_rds.id
  route_table_id = azurerm_route_table.ne_cidmz_rt.id
}

# Data sources for subnets
data "azurerm_subnet" "we_cedmz_afw" {
  name                 = "AzureFirewallSubnet"
  virtual_network_name = "MIP-SI-WE-ceDMZ-vnet"
  resource_group_name  = var.we_resource_group_name
}

data "azurerm_subnet" "we_cedmz_reserved" {
  name                 = "MIP-SI-WE-ceDMZ-Reserved-snet"
  virtual_network_name = "MIP-SI-WE-ceDMZ-vnet"
  resource_group_name  = var.we_resource_group_name
}

data "azurerm_subnet" "we_cidmz_proxy" {
  name                 = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
  virtual_network_name = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name  = var.we_resource_group_name
}

data "azurerm_subnet" "we_cidmz_rds" {
  name                 = "MIP-SI-WE-ciDMZ-RDS-snet"
  virtual_network_name = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name  = var.we_resource_group_name
}

data "azurerm_subnet" "we_cidmz_appgw" {
  name                 = "MIP-SI-WE-ciDMZ-AppGW-snet"
  virtual_network_name = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name  = var.we_resource_group_name
}

data "azurerm_subnet" "ne_cedmz_afw" {
  provider             = azurerm.secondary
  name                 = "AzureFirewallSubnet"
  virtual_network_name = "MIP-SI-NE-ceDMZ-vnet"
  resource_group_name  = var.ne_resource_group_name
}

data "azurerm_subnet" "ne_cedmz_reserved" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ceDMZ-Reserved-snet"
  virtual_network_name = "MIP-SI-NE-ceDMZ-vnet"
  resource_group_name  = var.ne_resource_group_name
}

data "azurerm_subnet" "ne_cidmz_proxy" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"
  virtual_network_name = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name  = var.ne_resource_group_name
}

data "azurerm_subnet" "ne_cidmz_rds" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-RDS-snet"
  virtual_network_name = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name  = var.ne_resource_group_name
}

data "azurerm_subnet" "ne_cidmz_appgw" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-AppGW-snet"
  virtual_network_name = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name  = var.ne_resource_group_name
}

