output "we_appgw_id" {
  value = azurerm_application_gateway.we_appgw.id
}

output "we_appgw_public_ip" {
  value = azurerm_application_gateway.we_appgw.frontend_ip_configuration[0]
}

output "ne_appgw_id" {
  value = azurerm_application_gateway.ne_appgw.id
}

output "ne_appgw_public_ip" {
  value = azurerm_application_gateway.ne_appgw.frontend_ip_configuration[0]
}
