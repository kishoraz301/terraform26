# Phase 05: Public IP Addresses
# Deploy after Phase 03: Subnets
# Creates 8 Public IPs: 4 per region (Standard, Static)

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# ============================================================================
# WEST EUROPE - Public IPs (4)
# ============================================================================

resource "azurerm_public_ip" "we_cedmz_afw_pip" {
  name                = "MIP-SI-WE-ceDMZ-AFW-pip"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "ceDMZ-AFW", Region = "West Europe" }
  )
}

resource "azurerm_public_ip" "we_cidmz_afwstd_pip" {
  name                = "MIP-SI-WE-ciDMZ-AFWstd-pip"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "ciDMZ-AFWstd", Region = "West Europe" }
  )
}

resource "azurerm_public_ip" "we_lb_frontend_pip" {
  name                = "MIP-SI-WE-LB-frontend-pip"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "LB-Frontend", Region = "West Europe" }
  )
}

resource "azurerm_public_ip" "we_appgw_frontend_pip" {
  name                = "MIP-SI-WE-AppGW-frontend-pip"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "AppGW-Frontend", Region = "West Europe" }
  )
}

# ============================================================================
# NORTH EUROPE - Public IPs (4)
# ============================================================================

resource "azurerm_public_ip" "ne_cedmz_afw_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ceDMZ-AFW-pip"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "ceDMZ-AFW", Region = "North Europe" }
  )
}

resource "azurerm_public_ip" "ne_cidmz_afwstd_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-AFWstd-pip"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "ciDMZ-AFWstd", Region = "North Europe" }
  )
}

resource "azurerm_public_ip" "ne_lb_frontend_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-LB-frontend-pip"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "LB-Frontend", Region = "North Europe" }
  )
}

resource "azurerm_public_ip" "ne_appgw_frontend_pip" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-AppGW-frontend-pip"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1", "2", "3"]

  tags = merge(
    local.default_tags,
    { Resource = "AppGW-Frontend", Region = "North Europe" }
  )
}

