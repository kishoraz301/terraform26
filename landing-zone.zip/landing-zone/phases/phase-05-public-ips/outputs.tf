output "we_cedmz_afw_pip_id" {
  value = azurerm_public_ip.we_cedmz_afw_pip.id
}

output "we_cedmz_afw_pip_address" {
  value = azurerm_public_ip.we_cedmz_afw_pip.ip_address
}

output "we_cidmz_afwstd_pip_id" {
  value = azurerm_public_ip.we_cidmz_afwstd_pip.id
}

output "we_cidmz_afwstd_pip_address" {
  value = azurerm_public_ip.we_cidmz_afwstd_pip.ip_address
}

output "we_lb_frontend_pip_id" {
  value = azurerm_public_ip.we_lb_frontend_pip.id
}

output "we_lb_frontend_pip_address" {
  value = azurerm_public_ip.we_lb_frontend_pip.ip_address
}

output "we_appgw_frontend_pip_id" {
  value = azurerm_public_ip.we_appgw_frontend_pip.id
}

output "we_appgw_frontend_pip_address" {
  value = azurerm_public_ip.we_appgw_frontend_pip.ip_address
}

output "ne_cedmz_afw_pip_id" {
  value = azurerm_public_ip.ne_cedmz_afw_pip.id
}

output "ne_cedmz_afw_pip_address" {
  value = azurerm_public_ip.ne_cedmz_afw_pip.ip_address
}

output "ne_cidmz_afwstd_pip_id" {
  value = azurerm_public_ip.ne_cidmz_afwstd_pip.id
}

output "ne_cidmz_afwstd_pip_address" {
  value = azurerm_public_ip.ne_cidmz_afwstd_pip.ip_address
}

output "ne_lb_frontend_pip_id" {
  value = azurerm_public_ip.ne_lb_frontend_pip.id
}

output "ne_lb_frontend_pip_address" {
  value = azurerm_public_ip.ne_lb_frontend_pip.ip_address
}

output "ne_appgw_frontend_pip_id" {
  value = azurerm_public_ip.ne_appgw_frontend_pip.id
}

output "ne_appgw_frontend_pip_address" {
  value = azurerm_public_ip.ne_appgw_frontend_pip.ip_address
}

output "public_ips_summary" {
  description = "Summary of all Public IPs"
  value = {
    we = {
      cedmz_afw_address    = azurerm_public_ip.we_cedmz_afw_pip.ip_address
      cidmz_afwstd_address = azurerm_public_ip.we_cidmz_afwstd_pip.ip_address
      lb_frontend_address  = azurerm_public_ip.we_lb_frontend_pip.ip_address
      appgw_frontend_address = azurerm_public_ip.we_appgw_frontend_pip.ip_address
    }
    ne = {
      cedmz_afw_address    = azurerm_public_ip.ne_cedmz_afw_pip.ip_address
      cidmz_afwstd_address = azurerm_public_ip.ne_cidmz_afwstd_pip.ip_address
      lb_frontend_address  = azurerm_public_ip.ne_lb_frontend_pip.ip_address
      appgw_frontend_address = azurerm_public_ip.ne_appgw_frontend_pip.ip_address
    }
  }
}
