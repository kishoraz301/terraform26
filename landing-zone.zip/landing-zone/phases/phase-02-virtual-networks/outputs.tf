output "we_cedmz_vnet_id" {
  description = "West Europe ceDMZ VNet ID"
  value       = azurerm_virtual_network.we_cedmz_vnet.id
}

output "we_cedmz_vnet_name" {
  description = "West Europe ceDMZ VNet name"
  value       = azurerm_virtual_network.we_cedmz_vnet.name
}

output "we_cidmz_vnet_id" {
  description = "West Europe ciDMZ VNet ID"
  value       = azurerm_virtual_network.we_cidmz_vnet.id
}

output "we_cidmz_vnet_name" {
  description = "West Europe ciDMZ VNet name"
  value       = azurerm_virtual_network.we_cidmz_vnet.name
}

output "ne_cedmz_vnet_id" {
  description = "North Europe ceDMZ VNet ID"
  value       = azurerm_virtual_network.ne_cedmz_vnet.id
}

output "ne_cedmz_vnet_name" {
  description = "North Europe ceDMZ VNet name"
  value       = azurerm_virtual_network.ne_cedmz_vnet.name
}

output "ne_cidmz_vnet_id" {
  description = "North Europe ciDMZ VNet ID"
  value       = azurerm_virtual_network.ne_cidmz_vnet.id
}

output "ne_cidmz_vnet_name" {
  description = "North Europe ciDMZ VNet name"
  value       = azurerm_virtual_network.ne_cidmz_vnet.name
}

output "we_cedmz_vnet_address_space" {
  description = "West Europe ceDMZ VNet address space"
  value       = azurerm_virtual_network.we_cedmz_vnet.address_space
}

output "we_cidmz_vnet_address_space" {
  description = "West Europe ciDMZ VNet address space"
  value       = azurerm_virtual_network.we_cidmz_vnet.address_space
}

output "ne_cedmz_vnet_address_space" {
  description = "North Europe ceDMZ VNet address space"
  value       = azurerm_virtual_network.ne_cedmz_vnet.address_space
}

output "ne_cidmz_vnet_address_space" {
  description = "North Europe ciDMZ VNet address space"
  value       = azurerm_virtual_network.ne_cidmz_vnet.address_space
}
