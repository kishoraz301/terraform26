variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
}

variable "primary_region" {
  description = "Primary Azure region"
  type        = string
  default     = "westeurope"
}

variable "secondary_region" {
  description = "Secondary Azure region"
  type        = string
  default     = "northeurope"
}

variable "primary_subscription_id" {
  description = "Primary subscription ID"
  type        = string
  sensitive   = true
}

variable "secondary_subscription_id" {
  description = "Secondary subscription ID"
  type        = string
  sensitive   = true
}

variable "we_resource_group_name" {
  description = "West Europe Resource Group name"
  type        = string
  default     = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  description = "North Europe Resource Group name"
  type        = string
  default     = "MIP-SI-NE-RG"
}

variable "we_cedmz_address_space" {
  description = "West Europe ceDMZ address space"
  type        = string
  default     = "10.200.50.0/24"
}

variable "we_cidmz_address_space" {
  description = "West Europe ciDMZ address space"
  type        = string
  default     = "10.200.11.0/24"
}

variable "ne_cedmz_address_space" {
  description = "North Europe ceDMZ address space"
  type        = string
  default     = "10.200.60.0/24"
}

variable "ne_cidmz_address_space" {
  description = "North Europe ciDMZ address space"
  type        = string
  default     = "10.200.12.0/24"
}

variable "custom_dns_servers" {
  description = "Custom DNS servers for VNets"
  type        = list(string)
  default     = ["8.8.8.8", "8.8.4.4"]
}

variable "enable_ddos_protection" {
  description = "Enable DDoS Protection Standard on VNets"
  type        = bool
  default     = false
}

locals {
  default_tags = {
    Project     = "HSBC"
    Environment = var.environment
    Namespace   = "MIP-SI"
    ManagedBy   = "Terraform"
    CreatedDate = formatdate("YYYY-MM-DD", timestamp())
  }
}

