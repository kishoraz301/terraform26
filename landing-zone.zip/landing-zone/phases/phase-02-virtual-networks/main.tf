# Phase 02: Virtual Networks (VNets)
# Deploy after Phase 01: Resource Groups
# Creates 4 VNets: WE ceDMZ, WE ciDMZ, NE ceDMZ, NE ciDMZ
#
# SHARED CONFIGURATION: This phase uses shared configuration from the root directory:
# - Providers: See ../../../providers.tf
# - Variables: See ../../../variables.tf  
# - Locals: See ../../../locals.tf
# For consolidation details, see ../../../CONSOLIDATION_GUIDE.md

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

# Data sources to reference Resource Groups from Phase 01
data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

# ============================================================================
# WEST EUROPE - Primary Region
# ============================================================================

# WE ceDMZ VNet (Customer Edge DMZ - Perimeter)
resource "azurerm_virtual_network" "we_cedmz_vnet" {
  name                = "MIP-SI-WE-ceDMZ-vnet"
  address_space       = [var.we_cedmz_address_space]
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  dns_servers = var.custom_dns_servers

  tags = merge(
    local.default_tags,
    {
      VNetType = "ceDMZ (Customer Edge / Perimeter)"
      Region   = "West Europe"
    }
  )
}

# WE ciDMZ VNet (Corporate Internal DMZ)
resource "azurerm_virtual_network" "we_cidmz_vnet" {
  name                = "MIP-SI-WE-ciDMZ-vnet"
  address_space       = [var.we_cidmz_address_space]
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  dns_servers = var.custom_dns_servers

  tags = merge(
    local.default_tags,
    {
      VNetType = "ciDMZ (Corporate Internal DMZ)"
      Region   = "West Europe"
    }
  )
}

# ============================================================================
# NORTH EUROPE - Secondary Region
# ============================================================================

# NE ceDMZ VNet (Customer Edge DMZ - Perimeter)
resource "azurerm_virtual_network" "ne_cedmz_vnet" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ceDMZ-vnet"
  address_space       = [var.ne_cedmz_address_space]
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  dns_servers = var.custom_dns_servers

  tags = merge(
    local.default_tags,
    {
      VNetType = "ceDMZ (Customer Edge / Perimeter)"
      Region   = "North Europe"
    }
  )
}

# NE ciDMZ VNet (Corporate Internal DMZ)
resource "azurerm_virtual_network" "ne_cidmz_vnet" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-vnet"
  address_space       = [var.ne_cidmz_address_space]
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  dns_servers = var.custom_dns_servers

  tags = merge(
    local.default_tags,
    {
      VNetType = "ciDMZ (Corporate Internal DMZ)"
      Region   = "North Europe"
    }
  )
}

# Optional: DDoS Protection (if enabled)
resource "azurerm_network_ddos_protection_plan" "we_ddos" {
  count               = var.enable_ddos_protection ? 1 : 0
  name                = "MIP-SI-WE-ddos-plan"
  location            = data.azurerm_resource_group.we.location
  resource_group_name = data.azurerm_resource_group.we.name

  tags = merge(
    local.default_tags,
    {
      Region = "West Europe"
    }
  )
}

resource "azurerm_network_ddos_protection_plan" "ne_ddos" {
  count               = var.enable_ddos_protection ? 1 : 0
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ddos-plan"
  location            = data.azurerm_resource_group.ne.location
  resource_group_name = data.azurerm_resource_group.ne.name

  tags = merge(
    local.default_tags,
    {
      Region = "North Europe"
    }
  )
}
