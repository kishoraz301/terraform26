variable "primary_subscription_id" {
  type      = string
  sensitive = true
}

variable "secondary_subscription_id" {
  type      = string
  sensitive = true
}

variable "we_resource_group_name" {
  type    = string
  default = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  type    = string
  default = "MIP-SI-NE-RG"
}

variable "frontdoor_sku" {
  type    = string
  default = "Premium_AzureFrontDoor"
}

variable "waf_mode" {
  type    = string
  default = "Prevention"
}

variable "rate_limit_threshold" {
  type    = number
  default = 2000
}

locals {
  default_tags = {
    Project     = "HSBC"
    Environment = "production"
    Namespace   = "MIP-SI"
    ManagedBy   = "Terraform"
    CreatedDate = formatdate("YYYY-MM-DD", timestamp())
  }
}

