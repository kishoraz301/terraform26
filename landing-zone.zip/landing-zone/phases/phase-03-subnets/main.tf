# Phase 03: Subnets
# Deploy after Phase 02: Virtual Networks
# Creates 14 subnets: 7 per region (2 in ceDMZ, 5 in ciDMZ)

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}

# Data sources
data "azurerm_resource_group" "we" {
  name = var.we_resource_group_name
}

data "azurerm_resource_group" "ne" {
  provider = azurerm.secondary
  name     = var.ne_resource_group_name
}

data "azurerm_virtual_network" "we_cedmz" {
  name                = "MIP-SI-WE-ceDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.we.name
}

data "azurerm_virtual_network" "we_cidmz" {
  name                = "MIP-SI-WE-ciDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.we.name
}

data "azurerm_virtual_network" "ne_cedmz" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ceDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.ne.name
}

data "azurerm_virtual_network" "ne_cidmz" {
  provider            = azurerm.secondary
  name                = "MIP-SI-NE-ciDMZ-vnet"
  resource_group_name = data.azurerm_resource_group.ne.name
}

# ============================================================================
# WEST EUROPE - ceDMZ Subnets (2)
# ============================================================================

resource "azurerm_subnet" "we_cedmz_afw_snet" {
  name                 = "AzureFirewallSubnet"
  resource_group_name  = data.azurerm_resource_group.we.name
  virtual_network_name = data.azurerm_virtual_network.we_cedmz.name
  address_prefixes     = ["10.200.50.0/26"]

  service_endpoints = ["Microsoft.Storage", "Microsoft.Sql", "Microsoft.EventHub"]
}

resource "azurerm_subnet" "we_cedmz_reserved_snet" {
  name                 = "MIP-SI-WE-ceDMZ-Reserved-snet"
  resource_group_name  = data.azurerm_resource_group.we.name
  virtual_network_name = data.azurerm_virtual_network.we_cedmz.name
  address_prefixes     = ["10.200.50.64/26"]

  service_endpoints = ["Microsoft.Storage"]
}

# ============================================================================
# WEST EUROPE - ciDMZ Subnets (5)
# ============================================================================

resource "azurerm_subnet" "we_cidmz_proxy_snet" {
  name                 = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet"
  resource_group_name  = data.azurerm_resource_group.we.name
  virtual_network_name = data.azurerm_virtual_network.we_cidmz.name
  address_prefixes     = ["10.200.11.0/26"]

  service_endpoints = ["Microsoft.Storage", "Microsoft.Sql"]
}

resource "azurerm_subnet" "we_cidmz_rds_snet" {
  name                 = "MIP-SI-WE-ciDMZ-RDS-snet"
  resource_group_name  = data.azurerm_resource_group.we.name
  virtual_network_name = data.azurerm_virtual_network.we_cidmz.name
  address_prefixes     = ["10.200.11.64/27"]

  service_endpoints = ["Microsoft.Storage"]
}

resource "azurerm_subnet" "we_cidmz_afwstd_snet" {
  name                 = "AzureFirewallSubnet"
  resource_group_name  = data.azurerm_resource_group.we.name
  virtual_network_name = data.azurerm_virtual_network.we_cidmz.name
  address_prefixes     = ["10.200.11.192/26"]

  service_endpoints = ["Microsoft.Storage", "Microsoft.Sql"]


}

resource "azurerm_subnet" "we_cidmz_appgw_snet" {
  name                 = "MIP-SI-WE-ciDMZ-AppGW-snet"
  resource_group_name  = data.azurerm_resource_group.we.name
  virtual_network_name = data.azurerm_virtual_network.we_cidmz.name
  address_prefixes     = ["10.200.11.160/27"]

  service_endpoints = ["Microsoft.Storage"]
}


# ============================================================================
# NORTH EUROPE - ceDMZ Subnets (2)
# ============================================================================

resource "azurerm_subnet" "ne_cedmz_afw_snet" {
  provider             = azurerm.secondary
  name                 = "AzureFirewallSubnet"
  resource_group_name  = data.azurerm_resource_group.ne.name
  virtual_network_name = data.azurerm_virtual_network.ne_cedmz.name
  address_prefixes     = ["10.200.60.0/26"]

  service_endpoints = ["Microsoft.Storage", "Microsoft.Sql", "Microsoft.EventHub"]


}

resource "azurerm_subnet" "ne_cedmz_reserved_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ceDMZ-Reserved-snet"
  resource_group_name  = data.azurerm_resource_group.ne.name
  virtual_network_name = data.azurerm_virtual_network.ne_cedmz.name
  address_prefixes     = ["10.200.60.64/26"]

  service_endpoints = ["Microsoft.Storage"]
}

# ============================================================================
# NORTH EUROPE - ciDMZ Subnets (5)
# ============================================================================

resource "azurerm_subnet" "ne_cidmz_proxy_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet"
  resource_group_name  = data.azurerm_resource_group.ne.name
  virtual_network_name = data.azurerm_virtual_network.ne_cidmz.name
  address_prefixes     = ["10.200.12.0/26"]

  service_endpoints = ["Microsoft.Storage", "Microsoft.Sql"]
}

resource "azurerm_subnet" "ne_cidmz_rds_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-RDS-snet"
  resource_group_name  = data.azurerm_resource_group.ne.name
  virtual_network_name = data.azurerm_virtual_network.ne_cidmz.name
  address_prefixes     = ["10.200.12.64/27"]

  service_endpoints = ["Microsoft.Storage"]
}

resource "azurerm_subnet" "ne_cidmz_afwstd_snet" {
  provider             = azurerm.secondary
  name                 = "AzureFirewallSubnet"
  resource_group_name  = data.azurerm_resource_group.ne.name
  virtual_network_name = data.azurerm_virtual_network.ne_cidmz.name
  address_prefixes     = ["10.200.12.192/26"]

  service_endpoints = ["Microsoft.Storage", "Microsoft.Sql"]


}

resource "azurerm_subnet" "ne_cidmz_appgw_snet" {
  provider             = azurerm.secondary
  name                 = "MIP-SI-NE-ciDMZ-AppGW-snet"
  resource_group_name  = data.azurerm_resource_group.ne.name
  virtual_network_name = data.azurerm_virtual_network.ne_cidmz.name
  address_prefixes     = ["10.200.12.160/27"]

  service_endpoints = ["Microsoft.Storage"]
}



