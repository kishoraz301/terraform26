output "we_cedmz_afw_subnet_id" {
  value = azurerm_subnet.we_cedmz_afw_snet.id
}

output "we_cedmz_afw_subnet_name" {
  value = azurerm_subnet.we_cedmz_afw_snet.name
}

output "we_cidmz_proxy_subnet_id" {
  value = azurerm_subnet.we_cidmz_proxy_snet.id
}

output "we_cidmz_proxy_subnet_name" {
  value = azurerm_subnet.we_cidmz_proxy_snet.name
}

output "we_cidmz_rds_subnet_id" {
  value = azurerm_subnet.we_cidmz_rds_snet.id
}

output "we_cidmz_rds_subnet_name" {
  value = azurerm_subnet.we_cidmz_rds_snet.name
}

output "we_cidmz_afwstd_subnet_id" {
  value = azurerm_subnet.we_cidmz_afwstd_snet.id
}

output "we_cidmz_afwstd_subnet_name" {
  value = azurerm_subnet.we_cidmz_afwstd_snet.name
}

output "we_cidmz_appgw_subnet_id" {
  value = azurerm_subnet.we_cidmz_appgw_snet.id
}

output "we_cidmz_appgw_subnet_name" {
  value = azurerm_subnet.we_cidmz_appgw_snet.name
}

output "ne_cedmz_afw_subnet_id" {
  value = azurerm_subnet.ne_cedmz_afw_snet.id
}

output "ne_cedmz_afw_subnet_name" {
  value = azurerm_subnet.ne_cedmz_afw_snet.name
}

output "ne_cidmz_proxy_subnet_id" {
  value = azurerm_subnet.ne_cidmz_proxy_snet.id
}

output "ne_cidmz_proxy_subnet_name" {
  value = azurerm_subnet.ne_cidmz_proxy_snet.name
}

output "ne_cidmz_rds_subnet_id" {
  value = azurerm_subnet.ne_cidmz_rds_snet.id
}

output "ne_cidmz_rds_subnet_name" {
  value = azurerm_subnet.ne_cidmz_rds_snet.name
}

output "ne_cidmz_afwstd_subnet_id" {
  value = azurerm_subnet.ne_cidmz_afwstd_snet.id
}

output "ne_cidmz_afwstd_subnet_name" {
  value = azurerm_subnet.ne_cidmz_afwstd_snet.name
}

output "ne_cidmz_appgw_subnet_id" {
  value = azurerm_subnet.ne_cidmz_appgw_snet.id
}

output "ne_cidmz_appgw_subnet_name" {
  value = azurerm_subnet.ne_cidmz_appgw_snet.name
}

# Summary output
output "subnets_summary" {
  description = "Summary of all created subnets"
  value = {
    we_cedmz = {
      afw      = azurerm_subnet.we_cedmz_afw_snet.name
    }
    we_cidmz = {
      proxy    = azurerm_subnet.we_cidmz_proxy_snet.name
      rds      = azurerm_subnet.we_cidmz_rds_snet.name
      afwstd   = azurerm_subnet.we_cidmz_afwstd_snet.name
      appgw    = azurerm_subnet.we_cidmz_appgw_snet.name
    }
    ne_cedmz = {
      afw      = azurerm_subnet.ne_cedmz_afw_snet.name
    }
    ne_cidmz = {
      proxy    = azurerm_subnet.ne_cidmz_proxy_snet.name
      rds      = azurerm_subnet.ne_cidmz_rds_snet.name
      afwstd   = azurerm_subnet.ne_cidmz_afwstd_snet.name
      appgw    = azurerm_subnet.ne_cidmz_appgw_snet.name
    }
  }
}
