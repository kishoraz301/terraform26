output "we_firewall_policy_id" {
  value = azurerm_firewall_policy.we_firewall_policy.id
}

output "ne_firewall_policy_id" {
  value = azurerm_firewall_policy.ne_firewall_policy.id
}
