# SHARED LOCALS - CENTRALIZED
# Used by all 12 phases - Single source of truth for constants and naming conventions
# Each phase can add phase-specific locals as needed

locals {
  # ============================================================================
  # NAMING & IDENTITY CONSTANTS
  # ============================================================================
  
  namespace    = "MIP-SI"
  project_code = "HSBC"
  environment  = var.environment

  # ============================================================================
  # REGION REFERENCE
  # ============================================================================
  
  regions = {
    primary   = var.primary_region
    secondary = var.secondary_region
  }

  # ============================================================================
  # DEFAULT TAGS - APPLIED TO ALL RESOURCES
  # ============================================================================

  default_tags = {
    Project     = local.project_code
    Environment = local.environment
    Namespace   = local.namespace
    ManagedBy   = "Terraform"
    CreatedDate = formatdate("YYYY-MM-DD", timestamp())
  }

  # ============================================================================
  # NETWORK CONFIGURATION - ADDRESS SPACES
  # ============================================================================

  # Maps region and tier to VNet address spaces
  address_spaces = {
    we = {
      ceDMZ = var.we_cedmz_address_space  # 10.200.50.0/24
      ciDMZ = var.we_cidmz_address_space  # 10.200.11.0/24
    }
    ne = {
      ceDMZ = var.ne_cedmz_address_space  # 10.200.60.0/24
      ciDMZ = var.ne_cidmz_address_space  # 10.200.12.0/24
    }
  }

  # ============================================================================
  # SUBNET CONFIGURATION - NAMES & PREFIXES
  # ============================================================================

  subnets = {
    we = {
      ceDMZ = {
        afw      = { name = "AzureFirewallSubnet", prefix = "10.200.50.0/26" }
        reserved = { name = "MIP-SI-WE-ceDMZ-Reserved-snet", prefix = "10.200.50.64/26" }
      }
      ciDMZ = {
        proxy    = { name = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet", prefix = "10.200.11.0/26" }
        rds      = { name = "MIP-SI-WE-ciDMZ-RDS-snet", prefix = "10.200.11.64/27" }
        afw      = { name = "AzureFirewallSubnet", prefix = "10.200.11.192/26" }
        appgw    = { name = "MIP-SI-WE-ciDMZ-AppGW-snet", prefix = "10.200.11.160/27" }
        reserved = { name = "MIP-SI-WE-ciDMZ-Reserved-snet", prefix = "10.200.11.224/27" }
      }
    }
    ne = {
      ceDMZ = {
        afw      = { name = "AzureFirewallSubnet", prefix = "10.200.60.0/26" }
        reserved = { name = "MIP-SI-NE-ceDMZ-Reserved-snet", prefix = "10.200.60.64/26" }
      }
      ciDMZ = {
        proxy    = { name = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet", prefix = "10.200.12.0/26" }
        rds      = { name = "MIP-SI-NE-ciDMZ-RDS-snet", prefix = "10.200.12.64/27" }
        afw      = { name = "AzureFirewallSubnet", prefix = "10.200.12.192/26" }
        appgw    = { name = "MIP-SI-NE-ciDMZ-AppGW-snet", prefix = "10.200.12.160/27" }
        reserved = { name = "MIP-SI-NE-ciDMZ-Reserved-snet", prefix = "10.200.12.224/27" }
      }
    }
  }

  # ============================================================================
  # NETWORK SECURITY - DEFAULTS & RANGES
  # ============================================================================

  # Default deny rule for NSGs
  nsg_deny_all_inbound = {
    name                       = "Deny-All-Inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }

  # Internal (protected) network ranges
  internal_ranges = ["10.0.0.0/8"]

  # ============================================================================
  # COMMON PORTS & SERVICE DEFINITIONS
  # ============================================================================

  ports = {
    http                  = 80
    https                 = 443
    dns                   = 53
    squid_proxy           = 3128
    ssh                   = 22
    rdp                   = 3389
    rds_gateway           = 443
    winrm_http            = 5985
    winrm_https           = 5986
    gateway_manager_start = 65200
    gateway_manager_end   = 65535
  }

  # ============================================================================
  # DNS CONFIGURATION
  # ============================================================================

  dns_servers = var.custom_dns_servers
}
