terraform {
  required_version = ">= 1.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

provider "azurerm" {
  features {
    virtual_machine {
      graceful_shutdown = true
    }
    
    app_service {
      purge_soft_delete_on_destroy = true
    }
    
    key_vault {
      purge_soft_delete_on_destroy       = true
      recover_soft_deleted_key_vaults    = true
    }
  }

  skip_provider_registration = false
}

# Alias for primary region
provider "azurerm" {
  alias = "primary"
  
  features {
    virtual_machine {
      graceful_shutdown = true
    }
  }
  
  subscription_id = var.primary_subscription_id
}

# Alias for secondary region
provider "azurerm" {
  alias = "secondary"
  
  features {
    virtual_machine {
      graceful_shutdown = true
    }
  }
  
  subscription_id = var.secondary_subscription_id
}
