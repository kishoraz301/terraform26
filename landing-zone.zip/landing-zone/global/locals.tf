locals {
  # Global naming convention and tagging
  namespace = "MIP-SI"
  environment = var.environment
  project_code = "HSBC"
  
  # Azure regions
  regions = {
    primary   = var.primary_region
    secondary = var.secondary_region
  }

  # Default tags applied to all resources
  default_tags = {
    Project     = local.project_code
    Environment = var.environment
    Namespace   = local.namespace
    ManagedBy   = "Terraform"
    CreatedDate = formatdate("YYYY-MM-DD", timestamp())
  }

  # Network configuration constants
  dns_servers = var.custom_dns_servers

  # Address space mapping
  address_spaces = {
    we = {
      ceDMZ = var.we_cedmz_address_space
      ciDMZ = var.we_cidmz_address_space
    }
    ne = {
      ceDMZ = var.ne_cedmz_address_space
      ciDMZ = var.ne_cidmz_address_space
    }
  }

  # Subnet configuration
  subnets = {
    we = {
      ceDMZ = {
        afw      = { name = "MIP-SI-WE-ceDMZ-AFW-snet", prefix = "10.200.50.0/26" }
        reserved = { name = "MIP-SI-WE-ceDMZ-Reserved-snet", prefix = "10.200.50.64/26" }
      }
      ciDMZ = {
        proxy   = { name = "MIP-SI-WE-ciDMZ-Proxy-dmz-snet", prefix = "10.200.11.0/26" }
        rds     = { name = "MIP-SI-WE-ciDMZ-RDS-snet", prefix = "10.200.11.64/27" }
        afwstd  = { name = "MIP-SI-WE-ciDMZ-AFWstd-snet", prefix = "10.200.11.96/26" }
        appgw   = { name = "MIP-SI-WE-ciDMZ-AppGW-snet", prefix = "10.200.11.160/27" }
        reserved = { name = "MIP-SI-WE-ciDMZ-Reserved-snet", prefix = "10.200.11.192/26" }
      }
    }
    ne = {
      ceDMZ = {
        afw      = { name = "MIP-SI-NE-ceDMZ-AFW-snet", prefix = "10.200.60.0/26" }
        reserved = { name = "MIP-SI-NE-ceDMZ-Reserved-snet", prefix = "10.200.60.64/26" }
      }
      ciDMZ = {
        proxy   = { name = "MIP-SI-NE-ciDMZ-Proxy-dmz-snet", prefix = "10.200.12.0/26" }
        rds     = { name = "MIP-SI-NE-ciDMZ-RDS-snet", prefix = "10.200.12.64/27" }
        afwstd  = { name = "MIP-SI-NE-ciDMZ-AFWstd-snet", prefix = "10.200.12.96/26" }
        appgw   = { name = "MIP-SI-NE-ciDMZ-AppGW-snet", prefix = "10.200.12.160/27" }
        reserved = { name = "MIP-SI-NE-ciDMZ-Reserved-snet", prefix = "10.200.12.192/26" }
      }
    }
  }

  # NSG rule defaults
  nsg_deny_all_inbound = {
    name                       = "Deny-All-Inbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }

  # Internal network ranges
  internal_ranges = ["10.0.0.0/8"]

  # Common ports
  ports = {
    http           = 80
    https          = 443
    dns            = 53
    squid          = 3128
    ssh            = 22
    rdp            = 3389
    rds_gw         = 443
    winrm_http     = 5985
    winrm_https    = 5986
    gateway_manager_start = 65200
    gateway_manager_end   = 65535
  }
}
