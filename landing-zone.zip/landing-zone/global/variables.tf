variable "environment" {
  description = "Environment name (e.g., production, staging)"
  type        = string
  default     = "production"
  
  validation {
    condition     = contains(["production", "staging", "development"], var.environment)
    error_message = "Environment must be production, staging, or development."
  }
}

variable "primary_region" {
  description = "Primary Azure region"
  type        = string
  default     = "westeurope"
}

variable "secondary_region" {
  description = "Secondary Azure region for disaster recovery"
  type        = string
  default     = "northeurope"
}

variable "custom_dns_servers" {
  description = "Custom DNS servers for VNets"
  type        = list(string)
  default     = ["8.8.8.8", "8.8.4.4"]
}

# West Europe region configuration
variable "we_cedmz_address_space" {
  description = "West Europe ceDMZ VNet address space"
  type        = string
  default     = "10.200.50.0/24"
}

variable "we_cidmz_address_space" {
  description = "West Europe ciDMZ VNet address space"
  type        = string
  default     = "10.200.11.0/24"
}

variable "we_resource_group_name" {
  description = "West Europe Resource Group name"
  type        = string
  default     = "MIP-SI-WE-RG"
}

# North Europe region configuration
variable "ne_cedmz_address_space" {
  description = "North Europe ceDMZ VNet address space"
  type        = string
  default     = "10.200.60.0/24"
}

variable "ne_cidmz_address_space" {
  description = "North Europe ciDMZ VNet address space"
  type        = string
  default     = "10.200.12.0/24"
}

variable "ne_resource_group_name" {
  description = "North Europe Resource Group name"
  type        = string
  default     = "MIP-SI-NE-RG"
}

# Network Security
variable "enable_ddos_protection" {
  description = "Enable DDoS Protection Standard on VNets"
  type        = bool
  default     = false
}

variable "firewall_sku" {
  description = "Azure Firewall SKU"
  type        = string
  default     = "Standard"
  
  validation {
    condition     = contains(["Standard", "Premium"], var.firewall_sku)
    error_message = "Firewall SKU must be Standard or Premium."
  }
}

variable "appgw_capacity" {
  description = "Application Gateway initial capacity"
  type        = number
  default     = 2
  
  validation {
    condition     = var.appgw_capacity >= 1 && var.appgw_capacity <= 10
    error_message = "AppGW capacity must be between 1 and 10."
  }
}

variable "appgw_autoscale_min" {
  description = "Application Gateway autoscale minimum"
  type        = number
  default     = 1
}

variable "appgw_autoscale_max" {
  description = "Application Gateway autoscale maximum"
  type        = number
  default     = 10
}

# Load Balancer configuration
variable "lb_probe_interval" {
  description = "Load Balancer health probe interval in seconds"
  type        = number
  default     = 15
}

variable "lb_probe_threshold" {
  description = "Load Balancer health probe unhealthy threshold"
  type        = number
  default     = 2
}

# Front Door configuration
variable "frontdoor_sku" {
  description = "Azure Front Door SKU"
  type        = string
  default     = "Premium_AzureFrontDoor"
  
  validation {
    condition     = contains(["Standard_AzureFrontDoor", "Premium_AzureFrontDoor"], var.frontdoor_sku)
    error_message = "Front Door SKU must be Standard_AzureFrontDoor or Premium_AzureFrontDoor."
  }
}

variable "waf_mode" {
  description = "WAF mode (Detection or Prevention)"
  type        = string
  default     = "Prevention"
  
  validation {
    condition     = contains(["Detection", "Prevention"], var.waf_mode)
    error_message = "WAF mode must be Detection or Prevention."
  }
}

variable "rate_limit_threshold" {
  description = "WAF rate limit threshold per minute per IP"
  type        = number
  default     = 2000
}

variable "enable_resource_lock" {
  description = "Enable resource locks on critical resources"
  type        = bool
  default     = true
}

variable "tags" {
  description = "Additional tags to apply to resources"
  type        = map(string)
  default     = {}
}
