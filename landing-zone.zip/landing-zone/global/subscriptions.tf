variable "primary_subscription_id" {
  description = "Azure Subscription ID for primary region"
  type        = string
  sensitive   = true
}

variable "secondary_subscription_id" {
  description = "Azure Subscription ID for secondary region"
  type        = string
  sensitive   = true
}
