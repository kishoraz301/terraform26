output "we_resource_group_id" {
  description = "West Europe Resource Group ID"
  value       = "/subscriptions/${var.primary_subscription_id}/resourceGroups/${azurerm_resource_group.we.name}"
}

output "ne_resource_group_id" {
  description = "North Europe Resource Group ID"
  value       = "/subscriptions/${var.secondary_subscription_id}/resourceGroups/${azurerm_resource_group.ne.name}"
}

output "namespace" {
  description = "Namespace used for resource naming"
  value       = local.namespace
}
