# SHARED VARIABLES - CENTRALIZED
# Used by all 12 phases - Reduces duplication across phase directories
# Each phase can add phase-specific variables as needed

# ============================================================================
# SUBSCRIPTION & REGION CONFIGURATION
# ============================================================================

variable "primary_subscription_id" {
  description = "Azure subscription ID for primary region (West Europe)"
  type        = string
  sensitive   = true
}

variable "secondary_subscription_id" {
  description = "Azure subscription ID for secondary region (North Europe)"
  type        = string
  sensitive   = true
}

variable "primary_region" {
  description = "Primary Azure region (e.g., westeurope)"
  type        = string
  default     = "westeurope"
}

variable "secondary_region" {
  description = "Secondary Azure region for disaster recovery (e.g., northeurope)"
  type        = string
  default     = "northeurope"
}

variable "environment" {
  description = "Environment name (production, staging, development)"
  type        = string
  default     = "production"

  validation {
    condition     = contains(["production", "staging", "development"], var.environment)
    error_message = "Environment must be production, staging, or development."
  }
}

# ============================================================================
# RESOURCE GROUP CONFIGURATION
# ============================================================================

variable "we_resource_group_name" {
  description = "West Europe Resource Group name"
  type        = string
  default     = "MIP-SI-WE-RG"
}

variable "ne_resource_group_name" {
  description = "North Europe Resource Group name"
  type        = string
  default     = "MIP-SI-NE-RG"
}

# ============================================================================
# NETWORK CONFIGURATION
# ============================================================================

variable "we_cedmz_address_space" {
  description = "West Europe ceDMZ (Customer Edge DMZ) VNet address space"
  type        = string
  default     = "10.200.50.0/24"
}

variable "we_cidmz_address_space" {
  description = "West Europe ciDMZ (Corporate Internal DMZ) VNet address space"
  type        = string
  default     = "10.200.11.0/24"
}

variable "ne_cedmz_address_space" {
  description = "North Europe ceDMZ (Customer Edge DMZ) VNet address space"
  type        = string
  default     = "10.200.60.0/24"
}

variable "ne_cidmz_address_space" {
  description = "North Europe ciDMZ (Corporate Internal DMZ) VNet address space"
  type        = string
  default     = "10.200.12.0/24"
}

variable "custom_dns_servers" {
  description = "Custom DNS servers for VNets (e.g., [8.8.8.8, 8.8.4.4])"
  type        = list(string)
  default     = ["8.8.8.8", "8.8.4.4"]
}

variable "enable_ddos_protection" {
  description = "Enable DDoS Protection Standard on VNets"
  type        = bool
  default     = false
}

# ============================================================================
# SECURITY & FIREWALL CONFIGURATION
# ============================================================================

variable "firewall_sku" {
  description = "Azure Firewall SKU (Standard or Premium)"
  type        = string
  default     = "Standard"

  validation {
    condition     = contains(["Standard", "Premium"], var.firewall_sku)
    error_message = "Firewall SKU must be Standard or Premium."
  }
}

# ============================================================================
# APPLICATION GATEWAY CONFIGURATION
# ============================================================================

variable "appgw_capacity" {
  description = "Application Gateway initial capacity (1-100)"
  type        = number
  default     = 2

  validation {
    condition     = var.appgw_capacity >= 1 && var.appgw_capacity <= 100
    error_message = "AppGW capacity must be between 1 and 100."
  }
}

variable "appgw_autoscale_min" {
  description = "Application Gateway autoscale minimum (1-100)"
  type        = number
  default     = 1

  validation {
    condition     = var.appgw_autoscale_min >= 1 && var.appgw_autoscale_min <= 100
    error_message = "AppGW autoscale min must be between 1 and 100."
  }
}

variable "appgw_autoscale_max" {
  description = "Application Gateway autoscale maximum (1-100)"
  type        = number
  default     = 10

  validation {
    condition     = var.appgw_autoscale_max >= 1 && var.appgw_autoscale_max <= 100
    error_message = "AppGW autoscale max must be between 1 and 100."
  }
}

# ============================================================================
# LOAD BALANCER CONFIGURATION
# ============================================================================

variable "lb_probe_interval" {
  description = "Load Balancer health probe interval in seconds"
  type        = number
  default     = 15
}

variable "lb_probe_threshold" {
  description = "Load Balancer health probe failure threshold"
  type        = number
  default     = 2
}

# ============================================================================
# FRONT DOOR CONFIGURATION
# ============================================================================

variable "frontdoor_sku" {
  description = "Azure Front Door SKU"
  type        = string
  default     = "Premium_AzureFrontDoor"

  validation {
    condition     = contains(["Standard_AzureFrontDoor", "Premium_AzureFrontDoor"], var.frontdoor_sku)
    error_message = "Front Door SKU must be Standard_AzureFrontDoor or Premium_AzureFrontDoor."
  }
}

variable "waf_mode" {
  description = "WAF protection mode (Detection or Prevention)"
  type        = string
  default     = "Prevention"

  validation {
    condition     = contains(["Detection", "Prevention"], var.waf_mode)
    error_message = "WAF mode must be Detection or Prevention."
  }
}

variable "rate_limit_threshold" {
  description = "Rate limiting threshold (requests per minute per IP)"
  type        = number
  default     = 2000

  validation {
    condition     = var.rate_limit_threshold > 0
    error_message = "Rate limit threshold must be greater than 0."
  }
}
