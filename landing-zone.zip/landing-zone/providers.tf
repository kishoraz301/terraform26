# SHARED PROVIDER CONFIGURATION
# Used by all 12 phases - DO NOT DUPLICATE IN PHASE DIRECTORIES

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }
}

# Primary Provider (West Europe)
provider "azurerm" {
  features {}
  subscription_id = var.primary_subscription_id
}

# Secondary Provider (North Europe)
provider "azurerm" {
  alias           = "secondary"
  features {}
  subscription_id = var.secondary_subscription_id
}
