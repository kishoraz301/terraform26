function Deploy-Phase {
  param([int]$PhaseNum)
  
  # Ensure Azure CLI is in PATH
  $env:PATH = "C:\KM\2026\AZ CLI\bin;" + $env:PATH
  
  $phases = @{
    3 = "phase-03-subnets"
    4 = "phase-04-network-security-groups"
    5 = "phase-05-public-ips"
    6 = "phase-06-azure-firewalls"
    7 = "phase-07-load-balancers"
    8 = "phase-08-application-gateways"
    9 = "phase-09-vnet-peering"
    10 = "phase-10-route-tables"
    11 = "phase-11-front-door"
    12 = "phase-12-firewall-policies"
  }
  
  if (-not $phases.ContainsKey($PhaseNum)) {
    Write-Host "Phase $PhaseNum not found. Valid phases: 3-12" -ForegroundColor Red
    return
  }
  
  $phaseName = $phases[$PhaseNum]
  Write-Host "Deploying $phaseName..." -ForegroundColor Cyan
  
  Set-Location "C:\KM\2026\HSBC\Terraform\landing-zone"
  Copy-Item "terraform.tfvars" "phases/$phaseName/terraform.tfvars" -Force
  Set-Location "phases/$phaseName"
  
  Write-Host "Running terraform init..." -ForegroundColor Yellow
  C:\KM\2026\Terraform\terraform.exe init
  
  Write-Host "Running terraform plan..." -ForegroundColor Yellow
  C:\KM\2026\Terraform\terraform.exe plan
  
  Write-Host "Ready to deploy. Press Enter to apply or Ctrl+C to cancel..." -ForegroundColor Green
  Read-Host
  
  C:\KM\2026\Terraform\terraform.exe apply
  
  Write-Host "Phase $PhaseNum deployed successfully!" -ForegroundColor Green
}
