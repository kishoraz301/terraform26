# 🚀 Beginner's Guide: Deploy Azure Resources One-by-One

**Think of this like building a LEGO house - we build one piece at a time, bottom to top!**

---

## 📚 What's Happening Here? (The Simple Explanation)

Imagine you want to build something in Azure (Microsoft's cloud). Instead of clicking buttons in a website (which is boring and error-prone), we use **Terraform** to write code that describes what we want to build.

**Think of it like this:**
- 🖥️ **VS Code** = Your workspace (like a notebook)
- 📝 **Terraform Code** = Instructions you write (like a recipe)
- ☁️ **Azure** = The cloud (the place where things get built)
- 🔑 **Azure CLI** = Your magic wand (the tool that talks to Azure for you)

---

## 🎯 What Will We Build? (12 Phases, Step-by-Step)

We have 12 phases. Think of them like building a house:

| Phase | What We're Building | Time | 🔗 Depends On |
|-------|-------------------|------|--------------|
| 1️⃣ | **Folders** (Resource Groups) | 1 min | Nothing |
| 2️⃣ | **Networks** (VNets) | 2 min | Phase 1 |
| 3️⃣ | **Sub-networks** (Subnets) | 3 min | Phase 2 |
| 4️⃣ | **Security Rules** (NSGs) | 5 min | Phase 3 |
| 5️⃣ | **Public Addresses** (IPs) | 2 min | Phase 3 |
| 6️⃣ | **Firewalls** (Security walls) | 8 min | Phase 3+4+5 |
| 7️⃣ | **Load Balancer** (Traffic distributor) | 3 min | Phase 3+5 |
| 8️⃣ | **App Gateway** (Smart traffic router) | 10 min | Phase 3+5 |
| 9️⃣ | **Network Bridges** (Peering) | 1 min | Phase 2 |
| 🔟 | **Route Tables** (Traffic directions) | 3 min | Phase 2+6 |
| 1️⃣1️⃣ | **Global Router** (Front Door) | 5 min | Phase 8 |
| 1️⃣2️⃣ | **Firewall Rules** (Detailed rules) | 3 min | Phase 6 |

**Important:** Build them in order! Don't skip! ⚠️

---

## 📦 What You Need Before Starting

### 1. **Check You Have These Tools** (5 minutes)

Open VS Code and press **Ctrl + `** to open the PowerShell terminal.

Then, copy-paste each command one by one and press Enter:

```powershell
# Check PowerShell version (should be 5.0+)
$PSVersionTable.PSVersion

# Check Terraform is installed
terraform --version

# Check Azure CLI is installed
az --version
```

**What should you see?**
- Numbers like "5.1" or "7.0" for PowerShell ✅
- Something like "Terraform v1.5.0" ✅
- Something like "azure-cli 2.45.0" ✅

If you don't see these, you need to install them first. Ask for help!

### 2. **Login to Azure** (2 minutes)

This tells Azure "Hi, it's me, let's build stuff!"

```powershell
az login
```

**What happens:**
1. Your browser opens automatically
2. You log in with your Microsoft account
3. It says "You have logged in" ✅
4. Come back to VS Code

---

## 🔑 Configuration File Setup (3 minutes)

Think of this like filling out a form before you start building.

**Step 1: Copy the Template**

```powershell
# Go to the landing-zone folder
Set-Location "c:\KM\2026\HSBC\Terraform\landing-zone"

# Copy the example file
Copy-Item terraform.tfvars.example terraform.tfvars
```

**Step 2: Edit the File**

```powershell
# Open it in VS Code
code terraform.tfvars
```

**Step 3: Fill These Two Things** (very important!)

Find these lines and replace them with YOUR subscription IDs:

```hcl
primary_subscription_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
secondary_subscription_id = "yyyyyyyy-yyyy-yyyy-yyyy-yyyyyyyyyyyy"
```

**Where do I find my subscription ID?**

```powershell
# Run this command in PowerShell
az account list --output table
```

You'll see a table. Copy the `SubscriptionId` column (it looks like: `12345678-1234-1234-1234-123456789012`)

**Save the file** (Ctrl + S)

---

## 🚀 Now The Fun Part: Deploy Everything!

### **Phase 01: Create Resource Groups** (The Folders)

Think of this as creating 2 folders in Azure:
- 📁 One for Western Europe
- 📁 One for Northern Europe

```powershell
# Step 1: Go to Phase 1 folder
Set-Location "c:\KM\2026\HSBC\Terraform\landing-zone\phases\phase-01-resource-groups"

# Step 2: Initialize (download tools needed for this phase)
terraform init
```

**Wait for it to finish** (you'll see ✅ at the end)

```powershell
# Step 3: Check the plan (what will we build?)
terraform plan
```

**Read the output** - you should see:
```
Plan: 2 to add, 0 to change, 0 to destroy.
```

This means: "I will create 2 folders" ✅

```powershell
# Step 4: Actually build it!
terraform apply
```

**It will ask:** `Do you want to perform these actions?`

Type: `yes` and press Enter

**Wait 1 minute** ⏳

**Success? You should see:** ✅
```
Apply complete! Resources: 2 added, 0 changed, 0 destroyed.
```

🎉 **You just built 2 Azure Resource Groups!**

---

### **Phase 02: Create Networks** (The Roads)

Now we build the networks where everything will live.

```powershell
# Step 1: Go to Phase 2
Set-Location ../phase-02-virtual-networks

# Step 2: Initialize
terraform init

# Step 3: See the plan
terraform plan
```

You should see:
```
Plan: 4 to add, 0 to change, 0 to destroy.
```

This means: "I will create 4 networks" ✅

```powershell
# Step 4: Build it!
terraform apply

# Type: yes
```

**Wait 2 minutes** ⏳

**Success? You should see:** ✅
```
Apply complete! Resources: 4 added, 0 changed, 0 destroyed.
```

🎉 **You just built 4 Azure Networks!**

---

### **Phase 03: Create Subnets** (The Neighborhoods)

Subnets are like neighborhoods inside the networks.

```powershell
Set-Location ../phase-03-subnets
terraform init
terraform plan
```

You should see:
```
Plan: 14 to add, 0 to change, 0 to destroy.
```

```powershell
terraform apply
# Type: yes
```

**Wait 3 minutes** ⏳

🎉 **You just built 14 Azure Subnets!**

---

### **Phase 04: Create Security Rules** (The Doors & Locks)

These are rules that decide who can go where.

```powershell
Set-Location ../phase-04-network-security-groups
terraform init
terraform plan
```

You should see:
```
Plan: 10 to add, 30 to change, 0 to destroy.
```

```powershell
terraform apply
# Type: yes
```

**Wait 5 minutes** ⏳

🎉 **You just built 10 Security Groups with Rules!**

---

### **Phase 05: Create Public IP Addresses** (The Mailboxes)

These are addresses people can use to reach your resources from the internet.

```powershell
Set-Location ../phase-05-public-ips
terraform init
terraform plan
```

You should see:
```
Plan: 8 to add, 0 to change, 0 to destroy.
```

```powershell
terraform apply
# Type: yes
```

**Wait 2 minutes** ⏳

🎉 **You just created 8 Public IP Addresses!**

---

### **Phase 06: Create Firewalls** (The Security Guards) ⏱️ SLOW PHASE

These are the most important security parts. **This takes 8-10 minutes per firewall!** Be patient!

```powershell
Set-Location ../phase-06-azure-firewalls
terraform init
terraform plan
```

You should see:
```
Plan: 4 to add, 0 to change, 0 to destroy.
```

```powershell
terraform apply
# Type: yes
```

**☕ Go get a coffee - WAIT 8-10 MINUTES** ⏳⏳⏳

Watch the screen - you'll see lines saying "Still creating resources..." That's normal!

**Success? You should see:** ✅
```
Apply complete! Resources: 4 added, 0 changed, 0 destroyed.
```

🎉 **You just built 4 Azure Firewalls!**

---

### **Phase 07: Create Load Balancer** (The Traffic Cop)

This distributes traffic so one machine doesn't get too busy.

```powershell
Set-Location ../phase-07-load-balancers
terraform init
terraform plan
terraform apply
# Type: yes
```

**Wait 3 minutes** ⏳

🎉 **You just built Load Balancers!**

---

### **Phase 08: Create Application Gateway** (The Smart Traffic Router) ⏱️ SLOW PHASE

This is like a smart bouncer that looks at your requests and sends them to the right place. **Takes 10 minutes!**

```powershell
Set-Location ../phase-08-application-gateways
terraform init
terraform plan
terraform apply
# Type: yes
```

**☕ Another coffee break - WAIT 10 MINUTES** ⏳⏳⏳

🎉 **You just built Application Gateways!**

---

### **Phase 09: Create Network Bridges** (The Connectors)

These let different networks talk to each other.

```powershell
Set-Location ../phase-09-vnet-peerings
terraform init
terraform plan
terraform apply
# Type: yes
```

**Wait 1 minute** ⏳

🎉 **You just created Network Peerings!**

---

### **Phase 10: Create Route Tables** (The Road Signs)

These tell traffic where to go.

```powershell
Set-Location ../phase-10-route-tables
terraform init
terraform plan
terraform apply
# Type: yes
```

**Wait 3 minutes** ⏳

🎉 **You just created Route Tables!**

---

### **Phase 11: Create Front Door** (The Global Router) ⏱️ MEDIUM PHASE

This makes your system work worldwide! **Takes 5 minutes.**

```powershell
Set-Location ../phase-11-front-door
terraform init
terraform plan
terraform apply
# Type: yes
```

**Wait 5 minutes** ⏳

🎉 **You just created Azure Front Door!**

---

### **Phase 12: Create Firewall Rules** (The Detailed Security Rules)

These are the detailed rules for the firewalls.

```powershell
Set-Location ../phase-12-firewall-policies
terraform init
terraform plan
terraform apply
# Type: yes
```

**Wait 3 minutes** ⏳

🎉 **You just created Firewall Policies!**

---

## 🎉 YOU'RE DONE!!!

All 12 phases are complete! You've built:
- ✅ 2 Resource Groups
- ✅ 4 Virtual Networks
- ✅ 14 Subnets
- ✅ 10 Security Groups
- ✅ 8 Public IP Addresses
- ✅ 4 Firewalls
- ✅ 2 Load Balancers
- ✅ 2 Application Gateways
- ✅ 4 Network Peerings
- ✅ 4 Route Tables
- ✅ 1 Front Door
- ✅ 2 Firewall Policies

**Total Time:** ~46 minutes (with coffee breaks ☕☕)

---

## 🔍 How to See What You Built in Azure

Open Azure Portal: https://portal.azure.com

Look for "Resource Groups" and you'll see:
- `MIP-SI-WE-RG` (West Europe)
- `MIP-SI-NE-RG` (North Europe)

Click on them to see all your resources!

---

## ⚠️ If Something Goes Wrong...

### **Problem: "Error: Resource already exists"**

Someone might have already built this. Run:

```powershell
terraform destroy
# Type: yes
```

This removes everything so you can start fresh. Then try again.

### **Problem: "Error: Subscription not found"**

You didn't copy your subscription ID correctly. Check:

```powershell
az account list --output table
```

Copy the ID and update `terraform.tfvars`

### **Problem: Something times out or fails**

Just run again:

```powershell
terraform apply
# Type: yes
```

Terraform is smart - it only builds what's missing!

---

## 📚 What Do All These Commands Do?

| Command | What It Means | What It Does |
|---------|---------------|--------------|
| `terraform init` | Initialize | Downloads the tools needed for this phase |
| `terraform plan` | Make a plan | Shows what Terraform WILL create (doesn't actually create it) |
| `terraform apply` | Apply/Build | Actually creates the resources in Azure |
| `terraform destroy` | Destroy | Deletes all resources (use with care!) |

---

## 💡 Pro Tips for the Future

1. **Always `terraform plan` before `terraform apply`** - See what you're about to build first!
2. **Read the output carefully** - It tells you exactly what will happen
3. **Save your tfvars file** - You'll need it if you rebuild
4. **Don't delete .terraform files** - They're important (even though they're hidden)
5. **If confused, check the logs** - Run `terraform apply` again, it shows everything

---

## 🎓 Learn More (If You're Curious)

After you finish, read these to understand better:

- What is [Terraform](https://www.terraform.io/)? (Your deployment tool)
- What is [Azure](https://azure.microsoft.com/)? (The cloud)
- What is [Terraform State](https://www.terraform.io/language/state) (How Terraform remembers what it built)

---

## ✅ Checklist - Did You Do It All?

- [ ] Installed PowerShell 5.0+
- [ ] Installed Terraform
- [ ] Installed Azure CLI
- [ ] Logged in with `az login`
- [ ] Copied and filled `terraform.tfvars`
- [ ] Phase 01 done ✅
- [ ] Phase 02 done ✅
- [ ] Phase 03 done ✅
- [ ] Phase 04 done ✅
- [ ] Phase 05 done ✅
- [ ] Phase 06 done ✅ (took 10 min)
- [ ] Phase 07 done ✅
- [ ] Phase 08 done ✅ (took 10 min)
- [ ] Phase 09 done ✅
- [ ] Phase 10 done ✅
- [ ] Phase 11 done ✅
- [ ] Phase 12 done ✅

---

## 🚀 Next Steps After Deployment

1. **Go to Azure Portal** and explore what you built
2. **Read the main README.md** to understand the architecture
3. **Try to destroy Phase 12 and rebuild it** to practice:
   ```powershell
   Set-Location ../phase-12-firewall-policies
   terraform destroy  # Type: yes
   terraform apply    # Type: yes
   ```
4. **Share what you learned** with your team!

---

**Good luck! You've got this! 🎉**

If you get stuck, read the error message carefully. Terraform is very helpful and tells you exactly what's wrong!
