#Requires -Version 7.0
#Requires -Modules Az.Compute, Az.Network, Az.Resources

<#
.SYNOPSIS
    Clone 9 Proxy VMs from snapshots with marketplace plan support (FINAL BULLETPROOF VERSION)

.DESCRIPTION
    Production-grade cloning with complete marketplace plan handling.
    4 NE (North Europe) + 5 WE (West Europe) VMs with correct sequencing.

.PARAMETER SubscriptionId
    Azure subscription ID

.EXAMPLE
    .\Clone-9-Proxy-VMs-FINAL.ps1 -SubscriptionId "b3179146-e675-480d-aa38-23ec90529400"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId
)

$ErrorActionPreference = "Stop"
$WarningPreference = "SilentlyContinue"

$Config = @{
    VMSize          = "Standard_D2s_v3"
    DiskType        = "StandardSSD_LRS"
    SourceRG        = "mip-si-proxy-source-rg"
    
    ProxyVMs = @(
        # North Europe (4 VMs)
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-56"
            TargetRG        = "si-dmz-proxy-ne-01-rg"
            TargetVNetName  = "vnet-mip-si-ne-01"
            TargetSubnet    = "snet-mip-si-ne-01-dmz"
            TargetPrivateIP = "10.200.12.35"
            Location        = "North Europe"
            VNetRG          = "MIP-SI-NE-RG"
        },
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-57"
            TargetRG        = "si-dmz-proxy-ne-01-rg"
            TargetVNetName  = "vnet-mip-si-ne-01"
            TargetSubnet    = "snet-mip-si-ne-01-dmz"
            TargetPrivateIP = "10.200.12.36"
            Location        = "North Europe"
            VNetRG          = "MIP-SI-NE-RG"
        },
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-58"
            TargetRG        = "si-dmz-proxy-ne-01-rg"
            TargetVNetName  = "vnet-mip-si-ne-01"
            TargetSubnet    = "snet-mip-si-ne-01-dmz"
            TargetPrivateIP = "10.200.12.43"
            Location        = "North Europe"
            VNetRG          = "MIP-SI-NE-RG"
        },
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-59"
            TargetRG        = "si-dmz-proxy-ne-01-rg"
            TargetVNetName  = "vnet-mip-si-ne-01"
            TargetSubnet    = "snet-mip-si-ne-01-dmz"
            TargetPrivateIP = "10.200.12.44"
            Location        = "North Europe"
            VNetRG          = "MIP-SI-NE-RG"
        },
        # West Europe (5 VMs)
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-06"
            TargetRG        = "si-dmz-proxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.35"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        },
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-07"
            TargetRG        = "si-dmz-proxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.36"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        },
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-08"
            TargetRG        = "si-dmz-proxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.43"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        },
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-09"
            TargetRG        = "si-dmz-proxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.44"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        },
        @{
            SourceVMName    = "proxy-vm-01"
            TargetVMName    = "si-proxy-vm-10"
            TargetRG        = "si-dmz-proxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.45"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        }
    )
}

# ============================================================================
# LOGGING
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO", "SUCCESS", "ERROR", "WARNING")]
        [string]$Level = "INFO",
        [switch]$NoTimestamp
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $prefix = "[$timestamp]"
    
    $colors = @{
        "INFO"    = "Cyan"
        "SUCCESS" = "Green"
        "ERROR"   = "Red"
        "WARNING" = "Yellow"
    }
    
    if ($NoTimestamp) {
        Write-Host $Message -ForegroundColor $colors[$Level]
    }
    else {
        Write-Host "$prefix[$Level] $Message" -ForegroundColor $colors[$Level]
    }
}

# ============================================================================
# MARKETPLACE PLAN HANDLING
# ============================================================================

function Get-SourceVMPlanInfo {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceVMName,
        
        [Parameter(Mandatory = $true)]
        [string]$SourceResourceGroup
    )
    
    try {
        $sourceVM = Get-AzVM -Name $SourceVMName -ResourceGroupName $SourceResourceGroup -ErrorAction Stop
        
        if ($null -eq $sourceVM.Plan) {
            return [PSCustomObject]@{
                HasPlan   = $false
                Publisher = $null
                Product   = $null
                Name      = $null
                PlanId    = $null
                IsValid   = $true
            }
        }
        
        $publisher = $sourceVM.Plan.Publisher
        $product = $sourceVM.Plan.Product
        $planName = $sourceVM.Plan.Name
        
        $pubExists = -not [string]::IsNullOrWhiteSpace($publisher)
        $prodExists = -not [string]::IsNullOrWhiteSpace($product)
        $nameExists = -not [string]::IsNullOrWhiteSpace($planName)
        
        if (($pubExists -or $prodExists -or $nameExists) -and 
            -not ($pubExists -and $prodExists -and $nameExists)) {
            throw "Malformed plan: Incomplete components detected"
        }
        
        return [PSCustomObject]@{
            HasPlan   = $pubExists
            Publisher = if ($pubExists) { $publisher } else { $null }
            Product   = if ($prodExists) { $product } else { $null }
            Name      = if ($nameExists) { $planName } else { $null }
            PlanId    = $sourceVM.Plan.PromotionCode
            IsValid   = $true
        }
    }
    catch {
        Write-Log "ERROR extracting plan: $_" "ERROR"
        return [PSCustomObject]@{
            HasPlan   = $false
            Publisher = $null
            Product   = $null
            Name      = $null
            PlanId    = $null
            IsValid   = $false
            Error     = $_.Exception.Message
        }
    }
}

# ============================================================================
# VM CREATION WITH CORRECT SEQUENCE
# ============================================================================

function New-ClonedVMWithPlan {
    param(
        [Parameter(Mandatory = $true)]
        [string]$VMName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location,
        
        [Parameter(Mandatory = $true)]
        [string]$OsDiskId,
        
        [Parameter(Mandatory = $true)]
        [string]$NicId,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet("Linux", "Windows")]
        [string]$OSType,
        
        [Parameter(Mandatory = $true)]
        [string]$VMSize,
        
        [Parameter(Mandatory = $false)]
        [string]$Publisher,
        
        [Parameter(Mandatory = $false)]
        [string]$Product,
        
        [Parameter(Mandatory = $false)]
        [string]$PlanName
    )
    
    try {
        Write-Log "Creating VM: $VMName"
        
        $vmConfig = New-AzVMConfig -VMName $VMName -VMSize $VMSize -ErrorAction Stop
        
        if ($Publisher -and $Product -and $PlanName) {
            Write-Log "Applying marketplace plan: $Publisher/$Product/$PlanName"
            
            if ([string]::IsNullOrWhiteSpace($Publisher) -or 
                [string]::IsNullOrWhiteSpace($Product) -or 
                [string]::IsNullOrWhiteSpace($PlanName)) {
                throw "Plan information incomplete"
            }
            
            $vmConfig = Set-AzVMPlan `
                -VM $vmConfig `
                -Publisher $Publisher `
                -Product $Product `
                -Name $PlanName `
                -ErrorAction Stop
            
            Write-Log "Plan applied successfully" "SUCCESS"
        }
        
        Write-Log "Attaching OS disk"
        
        $diskParams = @{
            VM            = $vmConfig
            ManagedDiskId = $OsDiskId
            CreateOption  = "Attach"
            ErrorAction   = "Stop"
        }
        
        if ($OSType -eq "Windows") {
            $diskParams["Windows"] = $true
        }
        else {
            $diskParams["Linux"] = $true
        }
        
        $vmConfig = Set-AzVMOSDisk @diskParams
        
        Write-Log "Attaching network interface"
        $vmConfig = Add-AzVMNetworkInterface `
            -VM $vmConfig `
            -Id $NicId `
            -Primary `
            -ErrorAction Stop
        
        Write-Log "Creating VM in Azure..."
        $vm = New-AzVM `
            -ResourceGroupName $TargetResourceGroup `
            -Location $Location `
            -VM $vmConfig `
            -ErrorAction Stop
        
        Write-Log "VM created: $($vm.Name)" "SUCCESS"
        
        $verifyVM = Get-AzVM -Name $VMName -ResourceGroupName $TargetResourceGroup -ErrorAction Stop
        if ($verifyVM) {
            Write-Log "VM verified in resource group" "SUCCESS"
            return $verifyVM
        }
        else {
            throw "VM creation reported success but verification failed"
        }
    }
    catch {
        Write-Log "ERROR creating VM: $_" "ERROR"
        throw
    }
}

# ============================================================================
# SNAPSHOT AND DISK CREATION
# ============================================================================

function New-VMSnapshot {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceOsDiskId,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetVMName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    try {
        $existingSnapshots = Get-AzSnapshot -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue | 
            Where-Object { $_.Name -like "$TargetVMName-snap-*" }
        
        foreach ($snap in $existingSnapshots) {
            Write-Log "Removing existing snapshot: $($snap.Name)"
            Remove-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $snap.Name -Force -ErrorAction SilentlyContinue
        }
        
        $snapshotName = "$TargetVMName-snap-$(Get-Date -Format 'yyyyMMddHHmmss')"
        Write-Log "Creating snapshot: $snapshotName"
        
        $snapshotConfig = New-AzSnapshotConfig `
            -SourceResourceId $SourceOsDiskId `
            -Location $Location `
            -CreateOption Copy `
            -ErrorAction Stop
        
        $snapshot = New-AzSnapshot `
            -ResourceGroupName $TargetResourceGroup `
            -SnapshotName $snapshotName `
            -Snapshot $snapshotConfig `
            -ErrorAction Stop
        
        Write-Log "Snapshot created" "SUCCESS"
        return $snapshot
    }
    catch {
        Write-Log "ERROR creating snapshot: $_" "ERROR"
        throw
    }
}

function New-VMDiskFromSnapshot {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SnapshotId,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetVMName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location,
        
        [Parameter(Mandatory = $true)]
        [string]$DiskType
    )
    
    try {
        $diskName = "$TargetVMName-osdisk"
        Write-Log "Creating disk: $diskName"
        
        $diskConfig = New-AzDiskConfig `
            -SourceResourceId $SnapshotId `
            -Location $Location `
            -CreateOption Copy `
            -SkuName $DiskType `
            -ErrorAction Stop
        
        $disk = New-AzDisk `
            -ResourceGroupName $TargetResourceGroup `
            -DiskName $diskName `
            -Disk $diskConfig `
            -ErrorAction Stop
        
        for ($i = 0; $i -lt 15; $i++) {
            $checkDisk = Get-AzDisk -Name $diskName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($checkDisk) {
                Write-Log "Disk available" "SUCCESS"
                return $checkDisk
            }
            Start-Sleep -Seconds 2
        }
        
        throw "Disk not available after 30 seconds"
    }
    catch {
        Write-Log "ERROR creating disk: $_" "ERROR"
        throw
    }
}

# ============================================================================
# NETWORK INTERFACE CREATION
# ============================================================================

function New-VMNetworkInterface {
    param(
        [Parameter(Mandatory = $true)]
        [string]$NicName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location,
        
        [Parameter(Mandatory = $true)]
        [string]$VNetName,
        
        [Parameter(Mandatory = $true)]
        [string]$SubnetName,
        
        [Parameter(Mandatory = $true)]
        [string]$PrivateIP,
        
        [Parameter(Mandatory = $true)]
        [string]$VNetResourceGroup
    )
    
    try {
        Write-Log "Creating NIC: $NicName with IP $PrivateIP"
        
        $vnet = Get-AzVirtualNetwork -Name $VNetName -ResourceGroupName $VNetResourceGroup -ErrorAction Stop
        $subnet = Get-AzVirtualNetworkSubnetConfig -Name $SubnetName -VirtualNetwork $vnet -ErrorAction Stop
        
        $ipConfig = New-AzNetworkInterfaceIpConfig `
            -Name "ipconfig1" `
            -PrivateIpAddress $PrivateIP `
            -Subnet $subnet `
            -Primary `
            -ErrorAction Stop
        
        $nic = New-AzNetworkInterface `
            -Name $NicName `
            -ResourceGroupName $TargetResourceGroup `
            -Location $Location `
            -IpConfiguration $ipConfig `
            -ErrorAction Stop
        
        for ($i = 0; $i -lt 10; $i++) {
            $checkNic = Get-AzNetworkInterface -Name $NicName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($checkNic) {
                Write-Log "NIC created and available" "SUCCESS"
                return $checkNic
            }
            Start-Sleep -Seconds 1
        }
        
        throw "NIC not available after 10 seconds"
    }
    catch {
        Write-Log "ERROR creating NIC: $_" "ERROR"
        throw
    }
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

function Main {
    try {
        Write-Log "========== PROXY VM CLONE BATCH (FINAL) ==========" "INFO" -NoTimestamp
        Write-Log "Subscription: $SubscriptionId"
        
        $context = Get-AzContext
        if (-not $context -or $context.Subscription.Id -ne $SubscriptionId) {
            Write-Log "Connecting to subscription..."
            $null = Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop
        }
        
        Write-Log "Extracting marketplace plan from source VM..."
        $planInfo = Get-SourceVMPlanInfo -SourceVMName $Config.ProxyVMs[0].SourceVMName -SourceResourceGroup $Config.SourceRG
        
        if (-not $planInfo.IsValid) {
            throw "Failed to extract plan information from source VM"
        }
        
        if ($planInfo.HasPlan) {
            Write-Log "Using marketplace plan: $($planInfo.Publisher)/$($planInfo.Product)/$($planInfo.Name)" "INFO"
        }
        else {
            Write-Log "Source is custom image (no marketplace plan)" "INFO"
        }
        
        $cloneCount = 0
        $regionStats = @{
            "North Europe" = 0
            "West Europe"  = 0
        }
        
        foreach ($vm in $Config.ProxyVMs) {
            try {
                Write-Log ""
                Write-Log "========== CLONING $($vm.TargetVMName) ==========" "INFO" -NoTimestamp
                
                $sourceVM = Get-AzVM -Name $vm.SourceVMName -ResourceGroupName $Config.SourceRG -ErrorAction Stop
                $osDiskId = $sourceVM.StorageProfile.OsDisk.ManagedDisk.Id
                $osType = $sourceVM.StorageProfile.OsDisk.OsType
                
                $snapshot = New-VMSnapshot `
                    -SourceOsDiskId $osDiskId `
                    -TargetVMName $vm.TargetVMName `
                    -TargetResourceGroup $vm.TargetRG `
                    -Location $vm.Location
                
                $disk = New-VMDiskFromSnapshot `
                    -SnapshotId $snapshot.Id `
                    -TargetVMName $vm.TargetVMName `
                    -TargetResourceGroup $vm.TargetRG `
                    -Location $vm.Location `
                    -DiskType $Config.DiskType
                
                $nicName = "$($vm.TargetVMName)-nic"
                $nic = New-VMNetworkInterface `
                    -NicName $nicName `
                    -TargetResourceGroup $vm.TargetRG `
                    -Location $vm.Location `
                    -VNetName $vm.TargetVNetName `
                    -SubnetName $vm.TargetSubnet `
                    -PrivateIP $vm.TargetPrivateIP `
                    -VNetResourceGroup $vm.VNetRG
                
                $vmParams = @{
                    VMName              = $vm.TargetVMName
                    TargetResourceGroup = $vm.TargetRG
                    Location            = $vm.Location
                    OsDiskId            = $disk.Id
                    NicId               = $nic.Id
                    OSType              = $osType
                    VMSize              = $Config.VMSize
                    ErrorAction         = "Stop"
                }
                
                if ($planInfo.HasPlan) {
                    $vmParams["Publisher"] = $planInfo.Publisher
                    $vmParams["Product"] = $planInfo.Product
                    $vmParams["PlanName"] = $planInfo.Name
                }
                
                $clonedVM = New-ClonedVMWithPlan @vmParams
                $cloneCount++
                $regionStats[$vm.Location]++
                
                Write-Log "$($vm.TargetVMName) cloned successfully" "SUCCESS"
            }
            catch {
                Write-Log "FAILED to clone $($vm.TargetVMName): $_" "ERROR"
                Write-Log "Continuing with next VM..." "WARNING"
            }
        }
        
        Write-Log ""
        Write-Log "========== BATCH CLONE COMPLETE ==========" "INFO" -NoTimestamp
        Write-Log "Successfully cloned: $cloneCount / $($Config.ProxyVMs.Count) VMs" "SUCCESS"
        Write-Log "North Europe: $($regionStats['North Europe']) VMs | West Europe: $($regionStats['West Europe']) VMs" "SUCCESS"
        
        if ($cloneCount -eq $Config.ProxyVMs.Count) {
            Write-Log "All VMs cloned successfully!" "SUCCESS"
            exit 0
        }
        else {
            Write-Log "Partial success - some VMs may have failed" "WARNING"
            exit 1
        }
    }
    catch {
        Write-Log "BATCH EXECUTION FAILED: $_" "ERROR"
        Write-Log $_.ScriptStackTrace "ERROR"
        exit 1
    }
}

Main
