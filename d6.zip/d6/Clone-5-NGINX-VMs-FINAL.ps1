#Requires -Version 7.0
#Requires -Modules Az.Compute, Az.Network, Az.Resources

<#
.SYNOPSIS
    Clone 5 NGINX VMs from snapshots with marketplace plan support (FINAL BULLETPROOF VERSION)

.DESCRIPTION
    Production-grade cloning with complete marketplace plan handling.
    Properly sequences plan attachment BEFORE disk attachment.
    Includes comprehensive error handling and fallback logic.

.PARAMETER SubscriptionId
    Azure subscription ID

.EXAMPLE
    .\Clone-5-NGINX-VMs-FINAL.ps1 -SubscriptionId "b3179146-e675-480d-aa38-23ec90529400"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$SubscriptionId
)

# ============================================================================
# CONFIGURATION
# ============================================================================

$ErrorActionPreference = "Stop"
$WarningPreference = "SilentlyContinue"

$Config = @{
    VMSize          = "Standard_D2s_v3"
    DiskType        = "StandardSSD_LRS"
    SourceRG        = "mip-si-nginx-source-rg"
    VNetResourceGroup = "MIP-SI-NE-RG", "MIP-SI-WE-RG"
    
    NginxVMs = @(
        @{
            SourceVMName    = "nginx-vm-01"
            TargetVMName    = "SI-RPRXY-VM-59"
            TargetRG        = "si-dmz-rprxy-ne-01-rg"
            TargetVNetName  = "vnet-mip-si-ne-01"
            TargetSubnet    = "snet-mip-si-ne-01-dmz"
            TargetPrivateIP = "10.200.12.4"
            Location        = "North Europe"
            VNetRG          = "MIP-SI-NE-RG"
        },
        @{
            SourceVMName    = "nginx-vm-01"
            TargetVMName    = "SI-RPRXY-VM-60"
            TargetRG        = "si-dmz-rprxy-ne-01-rg"
            TargetVNetName  = "vnet-mip-si-ne-01"
            TargetSubnet    = "snet-mip-si-ne-01-dmz"
            TargetPrivateIP = "10.200.12.5"
            Location        = "North Europe"
            VNetRG          = "MIP-SI-NE-RG"
        },
        @{
            SourceVMName    = "nginx-vm-01"
            TargetVMName    = "SI-RPRXY-VM-10"
            TargetRG        = "si-dmz-rprxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.4"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        },
        @{
            SourceVMName    = "nginx-vm-01"
            TargetVMName    = "SI-RPRXY-VM-11"
            TargetRG        = "si-dmz-rprxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.5"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        },
        @{
            SourceVMName    = "nginx-vm-01"
            TargetVMName    = "SI-RPRXY-VM-09"
            TargetRG        = "si-dmz-rprxy-we-01-rg"
            TargetVNetName  = "vnet-mip-si-we-01"
            TargetSubnet    = "snet-mip-si-we-01-dmz"
            TargetPrivateIP = "10.200.11.8"
            Location        = "West Europe"
            VNetRG          = "MIP-SI-WE-RG"
        }
    )
}

# ============================================================================
# LOGGING
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO", "SUCCESS", "ERROR", "WARNING")]
        [string]$Level = "INFO",
        [switch]$NoTimestamp
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $prefix = "[$timestamp]"
    
    $colors = @{
        "INFO"    = "Cyan"
        "SUCCESS" = "Green"
        "ERROR"   = "Red"
        "WARNING" = "Yellow"
    }
    
    if ($NoTimestamp) {
        Write-Host $Message -ForegroundColor $colors[$Level]
    }
    else {
        Write-Host "$prefix[$Level] $Message" -ForegroundColor $colors[$Level]
    }
}

# ============================================================================
# MARKETPLACE PLAN HANDLING
# ============================================================================

function Get-SourceVMPlanInfo {
    <#
    .SYNOPSIS
        Extract and validate marketplace plan from source VM
    .DESCRIPTION
        Three-level validation ensures plan data integrity.
        Returns structured object with IsValid flag for error handling.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceVMName,
        
        [Parameter(Mandatory = $true)]
        [string]$SourceResourceGroup
    )
    
    try {
        $sourceVM = Get-AzVM -Name $SourceVMName -ResourceGroupName $SourceResourceGroup -ErrorAction Stop
        
        # Level 1: Check if Plan exists
        if ($null -eq $sourceVM.Plan) {
            return [PSCustomObject]@{
                HasPlan   = $false
                Publisher = $null
                Product   = $null
                Name      = $null
                PlanId    = $null
                IsValid   = $true
            }
        }
        
        # Level 2: Extract components
        $publisher = $sourceVM.Plan.Publisher
        $product = $sourceVM.Plan.Product
        $planName = $sourceVM.Plan.Name
        
        # Level 3: Validate consistency
        $pubExists = -not [string]::IsNullOrWhiteSpace($publisher)
        $prodExists = -not [string]::IsNullOrWhiteSpace($product)
        $nameExists = -not [string]::IsNullOrWhiteSpace($planName)
        
        # Check for malformed state
        if (($pubExists -or $prodExists -or $nameExists) -and 
            -not ($pubExists -and $prodExists -and $nameExists)) {
            throw "Malformed plan: Incomplete components detected"
        }
        
        return [PSCustomObject]@{
            HasPlan   = $pubExists
            Publisher = if ($pubExists) { $publisher } else { $null }
            Product   = if ($prodExists) { $product } else { $null }
            Name      = if ($nameExists) { $planName } else { $null }
            PlanId    = $sourceVM.Plan.PromotionCode
            IsValid   = $true
        }
    }
    catch {
        Write-Log "ERROR extracting plan: $_" "ERROR"
        return [PSCustomObject]@{
            HasPlan   = $false
            Publisher = $null
            Product   = $null
            Name      = $null
            PlanId    = $null
            IsValid   = $false
            Error     = $_.Exception.Message
        }
    }
}

# ============================================================================
# VM CREATION WITH CORRECT SEQUENCE
# ============================================================================

function New-ClonedVMWithPlan {
    <#
    .SYNOPSIS
        Create VM from snapshot with marketplace plan (CRITICAL SEQUENCE)
    .DESCRIPTION
        MANDATORY SEQUENCE (enforced by Azure API):
        1. New-AzVMConfig
        2. Set-AzVMPlan (BEFORE disk - non-negotiable)
        3. Set-AzVMOSDisk (single call only)
        4. Add-AzVMNetworkInterface
        5. New-AzVM
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string]$VMName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location,
        
        [Parameter(Mandatory = $true)]
        [string]$OsDiskId,
        
        [Parameter(Mandatory = $true)]
        [string]$NicId,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet("Linux", "Windows")]
        [string]$OSType,
        
        [Parameter(Mandatory = $true)]
        [string]$VMSize,
        
        [Parameter(Mandatory = $false)]
        [string]$Publisher,
        
        [Parameter(Mandatory = $false)]
        [string]$Product,
        
        [Parameter(Mandatory = $false)]
        [string]$PlanName
    )
    
    try {
        Write-Log "Creating VM: $VMName"
        
        # STEP 1: New VM config
        $vmConfig = New-AzVMConfig -VMName $VMName -VMSize $VMSize -ErrorAction Stop
        
        # STEP 2: SET PLAN FIRST (if marketplace)
        if ($Publisher -and $Product -and $PlanName) {
            Write-Log "Applying marketplace plan: $Publisher/$Product/$PlanName"
            
            if ([string]::IsNullOrWhiteSpace($Publisher) -or 
                [string]::IsNullOrWhiteSpace($Product) -or 
                [string]::IsNullOrWhiteSpace($PlanName)) {
                throw "Plan information incomplete"
            }
            
            $vmConfig = Set-AzVMPlan `
                -VM $vmConfig `
                -Publisher $Publisher `
                -Product $Product `
                -Name $PlanName `
                -ErrorAction Stop
            
            Write-Log "Plan applied successfully" "SUCCESS"
        }
        
        # STEP 3: ATTACH DISK (single call - NEVER call twice)
        Write-Log "Attaching OS disk"
        
        $diskParams = @{
            VM            = $vmConfig
            ManagedDiskId = $OsDiskId
            CreateOption  = "Attach"
            ErrorAction   = "Stop"
        }
        
        if ($OSType -eq "Windows") {
            $diskParams["Windows"] = $true
        }
        else {
            $diskParams["Linux"] = $true
        }
        
        $vmConfig = Set-AzVMOSDisk @diskParams
        
        # STEP 4: ATTACH NIC
        Write-Log "Attaching network interface"
        $vmConfig = Add-AzVMNetworkInterface `
            -VM $vmConfig `
            -Id $NicId `
            -Primary `
            -ErrorAction Stop
        
        # STEP 5: CREATE VM
        Write-Log "Creating VM in Azure..."
        $vm = New-AzVM `
            -ResourceGroupName $TargetResourceGroup `
            -Location $Location `
            -VM $vmConfig `
            -ErrorAction Stop
        
        Write-Log "VM created: $($vm.Name)" "SUCCESS"
        
        # Verify
        $verifyVM = Get-AzVM -Name $VMName -ResourceGroupName $TargetResourceGroup -ErrorAction Stop
        if ($verifyVM) {
            Write-Log "VM verified in resource group" "SUCCESS"
            return $verifyVM
        }
        else {
            throw "VM creation reported success but verification failed"
        }
    }
    catch {
        Write-Log "ERROR creating VM: $_" "ERROR"
        throw
    }
}

# ============================================================================
# SNAPSHOT AND DISK CREATION
# ============================================================================

function New-VMSnapshot {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourceOsDiskId,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetVMName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location
    )
    
    try {
        # Clean up existing snapshots
        $existingSnapshots = Get-AzSnapshot -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue | 
            Where-Object { $_.Name -like "$TargetVMName-snap-*" }
        
        foreach ($snap in $existingSnapshots) {
            Write-Log "Removing existing snapshot: $($snap.Name)"
            Remove-AzSnapshot -ResourceGroupName $TargetResourceGroup -SnapshotName $snap.Name -Force -ErrorAction SilentlyContinue
        }
        
        $snapshotName = "$TargetVMName-snap-$(Get-Date -Format 'yyyyMMddHHmmss')"
        Write-Log "Creating snapshot: $snapshotName"
        
        $snapshotConfig = New-AzSnapshotConfig `
            -SourceResourceId $SourceOsDiskId `
            -Location $Location `
            -CreateOption Copy `
            -ErrorAction Stop
        
        $snapshot = New-AzSnapshot `
            -ResourceGroupName $TargetResourceGroup `
            -SnapshotName $snapshotName `
            -Snapshot $snapshotConfig `
            -ErrorAction Stop
        
        Write-Log "Snapshot created" "SUCCESS"
        return $snapshot
    }
    catch {
        Write-Log "ERROR creating snapshot: $_" "ERROR"
        throw
    }
}

function New-VMDiskFromSnapshot {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SnapshotId,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetVMName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location,
        
        [Parameter(Mandatory = $true)]
        [string]$DiskType
    )
    
    try {
        $diskName = "$TargetVMName-osdisk"
        Write-Log "Creating disk: $diskName"
        
        $diskConfig = New-AzDiskConfig `
            -SourceResourceId $SnapshotId `
            -Location $Location `
            -CreateOption Copy `
            -SkuName $DiskType `
            -ErrorAction Stop
        
        $disk = New-AzDisk `
            -ResourceGroupName $TargetResourceGroup `
            -DiskName $diskName `
            -Disk $diskConfig `
            -ErrorAction Stop
        
        # Wait for disk to be available
        for ($i = 0; $i -lt 15; $i++) {
            $checkDisk = Get-AzDisk -Name $diskName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($checkDisk) {
                Write-Log "Disk available" "SUCCESS"
                return $checkDisk
            }
            Start-Sleep -Seconds 2
        }
        
        throw "Disk not available after 30 seconds"
    }
    catch {
        Write-Log "ERROR creating disk: $_" "ERROR"
        throw
    }
}

# ============================================================================
# NETWORK INTERFACE CREATION
# ============================================================================

function New-VMNetworkInterface {
    param(
        [Parameter(Mandatory = $true)]
        [string]$NicName,
        
        [Parameter(Mandatory = $true)]
        [string]$TargetResourceGroup,
        
        [Parameter(Mandatory = $true)]
        [string]$Location,
        
        [Parameter(Mandatory = $true)]
        [string]$VNetName,
        
        [Parameter(Mandatory = $true)]
        [string]$SubnetName,
        
        [Parameter(Mandatory = $true)]
        [string]$PrivateIP,
        
        [Parameter(Mandatory = $true)]
        [string]$VNetResourceGroup
    )
    
    try {
        Write-Log "Creating NIC: $NicName with IP $PrivateIP"
        
        $vnet = Get-AzVirtualNetwork -Name $VNetName -ResourceGroupName $VNetResourceGroup -ErrorAction Stop
        $subnet = Get-AzVirtualNetworkSubnetConfig -Name $SubnetName -VirtualNetwork $vnet -ErrorAction Stop
        
        $ipConfig = New-AzNetworkInterfaceIpConfig `
            -Name "ipconfig1" `
            -PrivateIpAddress $PrivateIP `
            -Subnet $subnet `
            -Primary `
            -ErrorAction Stop
        
        $nic = New-AzNetworkInterface `
            -Name $NicName `
            -ResourceGroupName $TargetResourceGroup `
            -Location $Location `
            -IpConfiguration $ipConfig `
            -ErrorAction Stop
        
        # Wait for NIC to be available
        for ($i = 0; $i -lt 10; $i++) {
            $checkNic = Get-AzNetworkInterface -Name $NicName -ResourceGroupName $TargetResourceGroup -ErrorAction SilentlyContinue
            if ($checkNic) {
                Write-Log "NIC created and available" "SUCCESS"
                return $checkNic
            }
            Start-Sleep -Seconds 1
        }
        
        throw "NIC not available after 10 seconds"
    }
    catch {
        Write-Log "ERROR creating NIC: $_" "ERROR"
        throw
    }
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

function Main {
    try {
        Write-Log "========== NGINX VM CLONE BATCH (FINAL) ==========" "INFO" -NoTimestamp
        Write-Log "Subscription: $SubscriptionId"
        
        # Connect to Azure
        $context = Get-AzContext
        if (-not $context -or $context.Subscription.Id -ne $SubscriptionId) {
            Write-Log "Connecting to subscription..."
            $null = Set-AzContext -SubscriptionId $SubscriptionId -ErrorAction Stop
        }
        
        # Get source VM plan info once (used for all VMs)
        Write-Log "Extracting marketplace plan from source VM..."
        $planInfo = Get-SourceVMPlanInfo -SourceVMName $Config.NginxVMs[0].SourceVMName -SourceResourceGroup $Config.SourceRG
        
        if (-not $planInfo.IsValid) {
            throw "Failed to extract plan information from source VM"
        }
        
        if ($planInfo.HasPlan) {
            Write-Log "Using marketplace plan: $($planInfo.Publisher)/$($planInfo.Product)/$($planInfo.Name)" "INFO"
        }
        else {
            Write-Log "Source is custom image (no marketplace plan)" "INFO"
        }
        
        $cloneCount = 0
        
        foreach ($vm in $Config.NginxVMs) {
            try {
                Write-Log ""
                Write-Log "========== CLONING $($vm.TargetVMName) ==========" "INFO" -NoTimestamp
                
                # Get source VM
                $sourceVM = Get-AzVM -Name $vm.SourceVMName -ResourceGroupName $Config.SourceRG -ErrorAction Stop
                $osDiskId = $sourceVM.StorageProfile.OsDisk.ManagedDisk.Id
                $osType = $sourceVM.StorageProfile.OsDisk.OsType
                
                # Create snapshot
                $snapshot = New-VMSnapshot `
                    -SourceOsDiskId $osDiskId `
                    -TargetVMName $vm.TargetVMName `
                    -TargetResourceGroup $vm.TargetRG `
                    -Location $vm.Location
                
                # Create disk
                $disk = New-VMDiskFromSnapshot `
                    -SnapshotId $snapshot.Id `
                    -TargetVMName $vm.TargetVMName `
                    -TargetResourceGroup $vm.TargetRG `
                    -Location $vm.Location `
                    -DiskType $Config.DiskType
                
                # Create NIC
                $nicName = "$($vm.TargetVMName)-nic"
                $nic = New-VMNetworkInterface `
                    -NicName $nicName `
                    -TargetResourceGroup $vm.TargetRG `
                    -Location $vm.Location `
                    -VNetName $vm.TargetVNetName `
                    -SubnetName $vm.TargetSubnet `
                    -PrivateIP $vm.TargetPrivateIP `
                    -VNetResourceGroup $vm.VNetRG
                
                # Create VM with marketplace plan handling
                $vmParams = @{
                    VMName              = $vm.TargetVMName
                    TargetResourceGroup = $vm.TargetRG
                    Location            = $vm.Location
                    OsDiskId            = $disk.Id
                    NicId               = $nic.Id
                    OSType              = $osType
                    VMSize              = $Config.VMSize
                    ErrorAction         = "Stop"
                }
                
                if ($planInfo.HasPlan) {
                    $vmParams["Publisher"] = $planInfo.Publisher
                    $vmParams["Product"] = $planInfo.Product
                    $vmParams["PlanName"] = $planInfo.Name
                }
                
                $clonedVM = New-ClonedVMWithPlan @vmParams
                $cloneCount++
                
                Write-Log "$($vm.TargetVMName) cloned successfully" "SUCCESS"
            }
            catch {
                Write-Log "FAILED to clone $($vm.TargetVMName): $_" "ERROR"
                Write-Log "Continuing with next VM..." "WARNING"
            }
        }
        
        Write-Log ""
        Write-Log "========== BATCH CLONE COMPLETE ==========" "INFO" -NoTimestamp
        Write-Log "Successfully cloned: $cloneCount / $($Config.NginxVMs.Count) VMs" "SUCCESS"
        
        if ($cloneCount -eq $Config.NginxVMs.Count) {
            Write-Log "All VMs cloned successfully!" "SUCCESS"
            exit 0
        }
        else {
            Write-Log "Partial success - some VMs may have failed" "WARNING"
            exit 1
        }
    }
    catch {
        Write-Log "BATCH EXECUTION FAILED: $_" "ERROR"
        Write-Log $_.ScriptStackTrace "ERROR"
        exit 1
    }
}

# Execute
Main
