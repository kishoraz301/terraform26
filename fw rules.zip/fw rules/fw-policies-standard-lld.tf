# Standard Firewall Policies - LLD Compliant Structure (CI DMZ)
# WE = West Europe, NE = North Europe
# Shared policy: SI-CIDMZ-FWPLCY-SHARED

# ============================================================================
# DATA SOURCES
# ============================================================================

data "azurerm_resource_group" "cidmz_we" {
  name = "MIP-SI-WE-RG"
}

data "azurerm_resource_group" "cidmz_ne" {
  name = "MIP-SI-NE-RG"
}

# ============================================================================
# STANDARD FIREWALL POLICIES
# ============================================================================

resource "azurerm_firewall_policy" "std_shared_policy" {
  name                = "SI-CIDMZ-FWPLCY-SHARED"
  location            = data.azurerm_resource_group.cidmz_we.location
  resource_group_name = data.azurerm_resource_group.cidmz_we.name
  sku                 = "Standard"
}

# ============================================================================
# WEST EUROPE - PRIORITY 21000: INBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_we_rcg_inbound" {
  name               = "RCG-CI-WE-IN-NET-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_shared_policy.id
  priority           = 21000

  network_rule_collection {
    name     = "RC-CI-WE-IN-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "IN-CE2CI-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.50.0/26"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-INTERNAL2CI-NONPROXY"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.100.0.0/16"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-ILB-HEALTH-PROBES"
      protocols             = ["TCP"]
      source_addresses      = ["168.63.129.16/32"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["65200-65535"]
    }

    rule {
      name                  = "IN-DNS-FROM-INFRA"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.0.0/16", "10.100.0.0/16"]
      destination_addresses = ["10.200.11.0/24"]
      destination_ports     = ["53"]
    }

    rule {
      name                  = "IN-MGMT-JIT-ADMIN"
      protocols             = ["TCP"]
      source_ip_groups      = [azurerm_ip_group.ipg_uk_vpn.id, azurerm_ip_group.ipg_ind_vpn.id, azurerm_ip_group.ipg_hk_vpn.id]
      destination_addresses = ["10.200.11.96/26"]
      destination_ports     = ["22", "3389"]
    }
  }

  network_rule_collection {
    name     = "RC-CI-WE-IN-DENY-ALL"
    priority = 4096
    action   = "Deny"

    rule {
      name                  = "IN-DENY-ALL"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["*"]
      destination_addresses = ["*"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# WEST EUROPE - PRIORITY 21100: OUTBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_we_rcg_out_net" {
  name               = "RCG-CI-WE-OUT-NET-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_shared_policy.id
  priority           = 21100

  network_rule_collection {
    name     = "RC-CI-WE-OUT-NET-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "OUT-INTERNAL-TO-CE-FW"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.100.0.0/16"]
      destination_addresses = ["10.200.50.10"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# WEST EUROPE - PRIORITY 21200: OUTBOUND APPLICATION RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_we_rcg_out_app" {
  name               = "RCG-CI-WE-OUT-APP-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_shared_policy.id
  priority           = 21200

  application_rule_collection {
    name     = "RC-CI-WE-OUT-APP-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name              = "OUT-ENTRA-ID"
      source_addresses  = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["login.microsoftonline.com", "graph.microsoft.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-CONTROL-PLANE"
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureCloud"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-MONITOR"
      source_addresses      = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name              = "OUT-CRL-OCSP"
      source_addresses  = ["10.100.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["ocsp.digicert.com", "crl3.digicert.com", "crl4.digicert.com", "ocsp.sectigo.com", "crl.sectigo.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31000: INBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_inbound" {
  name               = "RCG-CI-NE-IN-NET-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_shared_policy.id
  priority           = 31000

  network_rule_collection {
    name     = "RC-CI-NE-IN-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "IN-CE2CI-NONPROXY-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.60.0/26"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-INTERNAL2CI-NONPROXY-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.150.0.0/16"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["1-65535"]
    }

    rule {
      name                  = "IN-ILB-HEALTH-PROBES-NE"
      protocols             = ["TCP"]
      source_addresses      = ["168.63.129.16/32"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["65200-65535"]
    }

    rule {
      name                  = "IN-DNS-FROM-INFRA-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.200.0.0/16", "10.150.0.0/16"]
      destination_addresses = ["10.200.12.0/24"]
      destination_ports     = ["53"]
    }

    rule {
      name                  = "IN-MGMT-JIT-ADMIN-NE"
      protocols             = ["TCP"]
      source_ip_groups      = [azurerm_ip_group.ipg_uk_vpn.id, azurerm_ip_group.ipg_ind_vpn.id, azurerm_ip_group.ipg_hk_vpn.id]
      destination_addresses = ["10.200.12.96/26"]
      destination_ports     = ["22", "3389"]
    }
  }

  network_rule_collection {
    name     = "RC-CI-NE-IN-DENY-ALL"
    priority = 4096
    action   = "Deny"

    rule {
      name                  = "IN-DENY-ALL"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["*"]
      destination_addresses = ["*"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31100: OUTBOUND NETWORK RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_out_net" {
  name               = "RCG-CI-NE-OUT-NET-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_shared_policy.id
  priority           = 31100

  network_rule_collection {
    name     = "RC-CI-NE-OUT-NET-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name                  = "OUT-INTERNAL-TO-CE-FW-NE"
      protocols             = ["TCP", "UDP"]
      source_addresses      = ["10.150.0.0/16"]
      destination_addresses = ["10.200.60.10"]
      destination_ports     = ["1-65535"]
    }
  }
}

# ============================================================================
# NORTH EUROPE - PRIORITY 31200: OUTBOUND APPLICATION RULES (CI DMZ)
# ============================================================================

resource "azurerm_firewall_policy_rule_collection_group" "std_ne_rcg_out_app" {
  name               = "RCG-CI-NE-OUT-APP-ALLOW"
  firewall_policy_id = azurerm_firewall_policy.std_shared_policy.id
  priority           = 31200

  application_rule_collection {
    name     = "RC-CI-NE-OUT-APP-ALLOW"
    priority = 100
    action   = "Allow"

    rule {
      name              = "OUT-ENTRA-ID"
      source_addresses  = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["login.microsoftonline.com", "graph.microsoft.com"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-CONTROL-PLANE"
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureCloud"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name                  = "OUT-AZURE-MONITOR"
      source_addresses      = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdn_tags = ["AzureMonitor"]

      protocols {
        type = "Https"
        port = 443
      }
    }

    rule {
      name              = "OUT-CRL-OCSP"
      source_addresses  = ["10.150.0.0/16", "10.201.0.0/16", "10.204.0.0/16", "10.205.0.0/16", "10.206.0.0/16", "10.207.0.0/16", "10.208.0.0/16", "10.213.0.0/16", "10.215.0.0/16"]
      destination_fqdns = ["ocsp.digicert.com", "crl3.digicert.com", "crl4.digicert.com", "ocsp.sectigo.com", "crl.sectigo.com"]

      protocols {
        type = "Http"
        port = 80
      }
      protocols {
        type = "Https"
        port = 443
      }
    }
  }
}
